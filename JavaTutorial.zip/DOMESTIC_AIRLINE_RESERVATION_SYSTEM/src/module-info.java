module DOMESTIC_AIRLINE_RESERVATION_SYSTEM {
	requires java.sql;
}