package ArrayList;

public class Sample1 {
						/*
						 *jAVA fRAMEWORKS
Collection of classes & Interfaces 

				Iterable    <--Interface
					|
				Collection  <This Interface will implement Iterable
					|
	------------------------------------
	|				|					|
	List		  Queue				   Set		<--Data Structures/Interfaces
	
	
	
	Methods On Collection:
	1.add
	2.size
	3.remove
	4.iterate(loops)
	5.addAll
	6.removeAll
	7.clear.
	
	
	
	Types of Interface:
	1.List Interface
									  List
									  	/\
										|
						------------------------------------
						|				|					|
					ArrayList		Linkedlist			Vector
														   /\	
															|
														  Stack
	Vector class will be almost similar to linkedlist but they'll be thread safe (helps
	in multithreading) this comes in advance java
	
	2.Queue Interface (FIFO)  first in first out
		
									  QUEUE
										/\
										|
						------------------------------------
						|				|					|
				PriorityQueue      LinkeList			 Deque->Double ended queue 
														   /\	operations can be done from
															|   both sides. 
														Arraydeque
														
Linkedlist folloes FIFO		

	3.Set Interface	
	Set is a group of objects in which all the objects are unique.				
										Set
										/\
										|
						------------------------------------
						|				|					|
					Hashset			LinkedHashSet		Sortedset
															/\
															 | 
														TreeSet
	Hashset set has elements in the set but they're not connected.
	LinkedHashSet has elements in the set in which one element is connected to other.
	
	if a given set can be sorted either in ascending or descending order, it becomes
	treeSet
														
	Both Set & Map Interface are very important.	
	
	4.Map Interface
	Map interface will map our key Nd Value. eg. Car number plate(key) & Owner(Value)
	
	 							Map
	 						    /\
								|
		-----------------------------------------------------
		|				|				|					|
	HashMap		 LinkedHashMap		SortedMap			Hashtable
										/\
										 |
									TreeMap<-- According to key everything will be sorted
									
 Internally map will be implemented by using set.
 
 Hashmap-->Key and values are stored without any order.
 LinkedHashMap--> will have an order on storing the values which came first
 TreeMap-->According to key everything will be sorted.
*/
	
						
}
