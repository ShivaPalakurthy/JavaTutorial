package ArrayList;
/*
 * Array stores memory in continous form and data is fixed
 * 			In arrays we can store primitive data types nd objects.
 * Arraylist overcomes this limitation as data is variable &  they are stored in memory in
 *  non-continous (random) form.
 *  		In arraylist we'll only store objects. 
 *  		All the arrayLists are created under the heap memory.
 *  
 *  Operations in ArrayList
 *     1.ADD-->Adding an element in an Arraylist
 *     2.Get-->how to get an added element.
 *     3.Modify-->Add in between or set an added value 
 *     4.Delete/Remove-->Removing a particular element.
 *     5.Iterate/Operations
 *     
 * TO implement java we have to import a package called
 *  			import java.util.ArrayList;
 */

import java.util.ArrayList;
import java.util.Collections;
public class Sample {
	public static void main(String args[]) {
		/*
		 * Since ArrayList stores only objects , if we want to store integer values then
		 * we have to use Integer class, and respective class for the respective datatype
		 * value
		 * 
		 * for 		   	int 	|	 float		|	 string		|	boolean -->variable
		 * 
		 * use clases  Integer	|	 Float		|	 String		|	Boolean
		 */
		ArrayList<Integer> list=new ArrayList<Integer>();
		/* we can also write as ArrayList<Integer> list=new ArrayList<>();
		 * 
		 * 
		Examples of ArrayList
		ArrayList<String> list1=new ArrayList<String>();
		ArrayList<Boolean> list2=new ArrayList<Boolean>(); */
		
		//add Elements. 
		list.add(0);
		list.add(2);
		list.add(5);
		
		System.out.println(list);
		
		//get Elements
		
		list.get(1); //we'll give the index value at which we want to know number
		System.out.println(list.get(2)); //list.get(int indx)
		
		
		//add element in between
		list.add(1, 6);  //list.add(int indx,integer element)
		 
		System.out.println(list);
		
		//set element -->replacing the element which is already there with new element
		list.set(0, 9); //list.set(int indx,integer element)
		System.out.println(list);
		
		//del elemeent
		list.remove(3); //list.remove(int indx)
		System.out.println(list);
		
		
		//Counting the number of elements in an ArrayList i.e gives size of ArrayList 	
		System.out.println(list.size());
		System.out.println();
		
		
		//forming loops on ArrayList
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
		
		
		//sorting
		Collections.sort(list); /*Collections is a class in which sort function exists
		to use this Collections.sort , we have to import a package called
				import java.util.Collections;
				
		Collections.sort(list); --> this will sort the code in ascending order
		*/
		System.out.println(list);
		}
	}


