package ArrayList;
import java.util.*;
public class ArrayListTest {
public static void main(String args[]) {
	List<String> arraylist	=new ArrayList<String>();
	arraylist.add("a");
	arraylist.add("b");
	ListIterator<String> listIterator=arraylist.listIterator();
	while (listIterator.hasNext()) {
		System.out.println(listIterator.next());
		listIterator.previous();
	}
}
}
