package CoreJavaByAtos;

public class Emp {
	/*this() - it is used to call default const. 
	this(int,String) - it is used to call para const. */
		int  empId;
		String empName;
		String empEmail;
		Emp(){ 										//default constructor
		System.out.println("Default Const Called");
		}
		Emp(int eId){
		this(); 	
		this.empId=eId;									
		System.out.println("one arg para Const Called");
		}
		Emp(int eId,String eName){ 
		this(eId);	
		this.empId=eId;	
		this.empName=eName;								 
		System.out.println("two arg para Const Called");
		}
		Emp(int eId,String eName,String eEmail){ 
		this(eId,eName);	
		this.empId=eId;	
		this.empName=eName;
		this.empEmail=eEmail;								 
		System.out.println("three arg para Const Called");
		}
		void displayInfo(){
		System.out.println(empId+"/"+empName+"/"+empEmail);	
		}
		public static void main(String args[]){
		Emp obj = new Emp(1003,"Atos","Atos@mail.com");
	}}
 
