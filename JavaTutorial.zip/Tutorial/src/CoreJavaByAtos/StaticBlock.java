package CoreJavaByAtos;

public class StaticBlock {
	 

		StaticBlock(){ //constructor
			System.out.println("Default Constructor called");
		}
		static{
			System.out.println("static block called");
		}
		public static void main(String args[]){
			StaticBlock obj1=new StaticBlock();
			StaticBlock obj2=new StaticBlock();
			StaticBlock obj3=new StaticBlock();
		}
		/* 

	//GIves error as Cannot make a static reference to the non-static field a
	int a=20;
	static int b=30;
	StaticBlock(){
		System.out.println("Default Constructor called");
	}
	static{
		a++; //Cannot make a static reference to the non-static field a
		b++;
		System.out.println("static block called");
	}
	public static void main(String args[]){
		StaticBlock obj1=new StaticBlock();
		StaticBlock obj2=new StaticBlock();
		StaticBlock obj3=new StaticBlock();
	}
 */ 
}
