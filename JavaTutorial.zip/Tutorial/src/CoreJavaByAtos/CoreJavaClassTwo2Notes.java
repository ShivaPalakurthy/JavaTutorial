package CoreJavaByAtos;

public class CoreJavaClassTwo2Notes {
/*
 * 				//primitive and reference ; stack and heap area
 * 
 * JVM has two areas 1. Stack Area 2. Heap Area 
 * 
 * 	 	class Hello{
	 		String color;
	 		int cost;
	 		
	 		void show(){
	 			System.out.println(color+"/"+cost);
	 		}
	 		
	 		public static void main(String args[]){
	 			int x;
	 			System.out.println("Local Variable value"+x);
	 			
	 			Hello obj=new Hello();
	 			obj.show();
	 		}
	 	
	 	}
	 	
	 	
 * 		int a=10;-->primitive datatype
 * 		Hello obj=new Hello();
 * 			here Hello obj-->reference variable 
 * 					new Hello();-->Object
 * 
 * 
 * Data is always stored in hexadecimal address
 * 
 * ALl primitive variables are always created in stack area
 * 
 * Hello obj=new Hello();
 * Any variable that is created on classtype is called reference variable.
 *    Hello is a user defined class & for this class we've created a reference variable
 *    with name obj. 
 *    
 *    Reference variable is always represented/created in the stack area.
 *    
 *    new-->this keyword is used to allocate resource from the heap
 *    new Hello()--> will allocate resource from the heap
 *    
 *    so we can say primitive variable & class reference is always created in the stack
 *    Object always allocate resource from the heap area.
 *    
 *    The moment when we write Hello obj=new Hello(); the reference variable obj of
 *    classType Hello will be pointing out to the new Hello() object from the heap
 *    
 *    
 *    				//Data Types

				byte -  1 byte-8bits
				short - 2 byte			1byte=8bits
				int - 4 byte
				long - 8 byte
				float - 4 byte
				double - 8 byte
				char - 2 byte
				boolean - 1 bit
				
				- arithmetic operations between two byte is always int.
				- by default x.0 is a double in java.
				
			 
				
			Case-1		
				byte b = 4;
				byte c = 5;
				byte e = (b + c);  
				     		
				System.out.println("e="+ e);
				
				we'll get this error
	DataTypeCase1.java:9: error: incompatible types: possible lossy conversion from int to byte
                                byte e =  (b + c); //explicit casting
                                             ^
1 error
		soll:
						byte b = 4;
				byte c = 5;
				byte e = (byte)(b + c);//explicit casting 
				// byte(1)  int(4) i.e big container is comming into small contatiner 		
				System.out.println("e="+ e);

				
				
				case-2
				
				float  f1 =  5.0; 
				float  f2 = 6.0;
				float  f3 = f1 + f2 ;
				System.out.println(f3);
				
				
				we'll get errors as follows
		DataTypeCase2.java:3: error: incompatible types: possible lossy conversion from double to float
                        float f1=5.0;
                                 ^
DataTypeCase2.java:4: error: incompatible types: possible lossy conversion from double to float
                        float f2=6.0;
                                 ^
2 errors

		Sol:	float  f1 =  5.0f; 
				//   float(4)		 double(8)
				float  f2 = 6.0f;
				float  f3 = f1 + f2 ;
				System.out.println(f3);
				
				
				
				
			case-3;	
			short   s1 = 20;
			short   s2 = 30;
			short   s3 = s1*s2;
			System.out.println(s3);	
			
		we get the following error
DataTypeCase3.java:5: error: incompatible types: possible lossy conversion from int to short
                        short   s3 = s1*s2;
                                       ^
1 error

sol:		short   s1 = 20;
			short   s2 = 30;
			short   s3 = (short)(s1*s2); //explicit casting 
				// short(2)	int(4) 
			System.out.println(s3);	
			
			
					case-4
				float   s1 =  5.0f;
				float   s2 =  7.0f;
				double  d  = s1 + s1 ; //implicit conversion
				  double(8)  float(4)
				System.out.println(d);
				
				//won't give error as small container(float) is going into big container 

				
			//Wrapper Class -->search java 8 api doc in goggle for more info
			 * 
			 * The primitive datatypes are by default stored in lang package. of java
					- for each datatype we have wrapper class.
					- object representation of primitive datatypes is called Wrapper class.

				byte -  1 byte          Byte
				short - 2 byte          Short
				int - 4 byte			Integer
				long - 8 byte			Long
				float - 4 byte			Float
				double - 8 byte			Double
				char - 2 byte			Char
				boolean - 1 bit			Boolean 
		It is recommended that while exchanging any information between two servers /two
		devices,we should always exchange the message in object format.
		Then only OOPS concept & data hiding can be acheived
		
		
		

			java 1.4      
					primitive  => object

				int   a = 10 ;
				Integer  obj = new Integer(a);

				        object => primitive

				int b = obj.intValue();
				System.out.println(b);

			java 1.5
				       primitive  => object

				int   a = 10 ;
				Integer  obj = a ;  // autoboxing-->automatically boxed in an object

				        object => primitive

				int b = obj      // auto-unboxing
				System.out.println(b);
				
		
		Hands On : 2
			1. Think about an Object.
			2. Find 2 attribute and one action.
			3. Create Class.
			4. Attribute should be instance variable and action should be method.
			5. Create an object and print the attribute value.


			Constructor - its name is same as the class name.
				    - it is used to initialize object attribute.
				    - JVM by default provide default const inside a class.
				    - two types of constructor
						A. default constructor
						B. parameterized constructor
				    - if we have parameterized constructor inside a class then 
				      we should manually provide default constructor in the class.

			this  -  it is a keywork in java.
			      -  this is used to point current object attribute.

			this() - it is used to call default const. 
			this(int,String) - it is used to call para const.
			
			
			
			class   Employee{

				int  empId;
				String empName;
				String empEmail;

				Employee(){
					System.out.println("Default Const Called");
				}

				Employee(int eId,String eName){   //parameterised constructor
					this.empId = eId;
					this.empName = eName;
					System.out.println("para Const Called");
				}
				
				void displayInfo(){
					System.out.println(empid+"/"+empName+"/"+empEmail);
				}

				public static void main(String args[]){
					Employee obj = new Employee();//empId=0 , empName=null , empEmail=null
					obj.displayInfo();

					Employee obj1=new Employee(1002,"Max");
					obj1.displayInfo();
					
					Employee obj2=new Employee(1003,"Srini");
					obj2.displayInfo();
				}
			} 

		example for this()
			package CoreJavaByAtos;

public class Emp {
	 
		int  empId;
		String empName;
		String empEmail;
		Emp(){ 										//default constructor
		System.out.println("Default Const Called");
		}
		Emp(int eId){
		this(); 	
		this.empId=eId;									
		System.out.println("one arg para Const Called");
		}
		Emp(int eId,String eName){ 
		this(eId);	
		this.empId=eId;	
		this.empName=eName;								
		System.out.println("two arg para Const Called");
		}
		Emp(int eId,String eName,String eEmail){ 
		this(eId,eName);	
		this.empId=eId;	
		this.empName=eName;
		this.empEmail=eEmail;								
		System.out.println("three arg para Const Called");
		}
		void displayInfo(){
		System.out.println(empId+"/"+empName+"/"+empEmail);	
		}
		public static void main(String args[]){
		Emp obj = new Emp(1003,"Atos","Atos@mail.com");
	}}
 

		//Find Possible objects in the problem Domain
ABC produces an online catalog of clothing every three months & emails it to subscribers
Each Shirt in the catalog has an item identifier(ID),one or more colors(each with a 
color code), one or more sizes, a description, & a price.
ABC accepts all credit cards.Customers can call ABC Inc to order directly from a 
customer service representative  (CSR), or customers can complete an online order form 
on the ABC's Shopping website.

SOl: possible Attributes & Operations for Objects in the case study

1. Order:--> Attributes=>OrderId,data,Shirts,total price,form of payment,csr status
			Action=>Calculate order ID, calculate the total price, add shirt to order,
			remove shirt from order,submit the order.
2.Shirt--> Attributes=>Shirt Id,price,description,size,color code.
			Action=>Calculate shirt Id, display shirt Information.
3.Customer-->Attributes=>Customer Id, name ,address,phone number,email address,order
			Action=>assign a customer ID
			
			
Hands On-3
	CLASS NAME :   Clothing
	Attribute  :   int id;  int size;  double price; color char 
		 	- Constructor
	Method Name :   - display()
	Inside main Method :            
		Create one object using Parameterized Constructor,
 		Print each attribute value with display().
 		
 		
 		//static 
                       - it is a keyword in java.
		       - static datamember and method can be called using class name.
		       - if main method is in the same class,
			then we can call static datamembers and method without using the class name.
		       - static variable value can be shared by multiple object.
    
    
    we always call method and variable creating an object of the class.
        Can we call method and var without creating an object of the class ?
				Answer :  YES, by keeping static data member.
		
			  example:
			  
			class   Dept{
				 int deptId = 20;
			 void display(){
					System.out.println("deptId:"+deptId);
				}
				
			
				public static void main(String args[]){
					Dept  obj = new Dept();
					obj.display();
					System.out.println(obj.deptId);
				}

			}
  	without creating object of the class we can call the variables & methods of the
  	class by using static keyword. 
  	And if main method is in the same class,then we can call static datamembers 
  	and method without using the class name.
  	 
  	 
			class   Dept{
				static int deptId = 20;
				static void display(){
					System.out.println("deptId:"+deptId);
				}
				
			 
				public static void main(String args[]){
					//Dept  obj = new Dept();
					//obj.display();
					//System.out.println(obj.deptId);
					 System.out.println(deptId);
					display()
	 			}

			}
  	
But if main method is in another class,then we should call static datamembers 
  	and method by using the class name.
  		
			class   Dept{
				static int deptId = 20;
				static void display(){
					System.out.println("deptId:"+deptId);
				}
				
			}
			class  DeptDemo{
				public static void main(String args[]){
					//Dept  obj = new Dept();
					//obj.display();
					//System.out.println(obj.deptId);
					System.out.println(Dept.deptId);
					Dept.display();
				}

			}
  	
  	
  	
  	
  	
  	 - static variable value can be shared by multiple object.This important property of 
  	 the static helps us to create automatic number generation, automatic incresing product
  	 id.
  	class  AA{
				int  a = 5 ; // instance var
				static int b = 6; //static var
					
				AA(){
					a++;
					b++;
					System.out.println("a="+a+"b="+b);
				}
				public static void main(String args[]){
					AA obj = new AA();  a=6   b=7 
					AA obj1 = new AA(); a=6   b=8
					AA obj2 = new AA(); a=6   b=9
				}
			}

  An instance method can access the static member but static method cannot access the
  non static member/value
  
  	OBJECT ATTRIBUTE INITIALIZATION : It can be done by 2 ways  
				- constructor
				- static block 

		static block :
			- It is used to initialize object static attribute.
			- if we create multiple object then constructor is called multiple time
			 but the static block is called only one time.
			- first static block executed then constructor executed.
			-static block only deals with static datamember where as constructor deals
			with both static & non-static data memeber


			class   Product{

				Product(){
					System.out.println("Default Constructor called");
				}
				static{
					System.out.println("static block called");
				}
				public static void main(String args[]){
					Product obj1=new Product();
					Product obj2=new Product();
					Product obj3=new Product();
				}
			}




=>static block only deals with static datamember where as constructor deals	
with both static & non-static data memeber
 

public class StaticBlock {

	//GIves error as Cannot make a static reference to the non-static field a
	int a=20;
	static int b=30;
	StaticBlock(){
		System.out.println("Default Constructor called");
	}
	static{
		a++; //Cannot make a static reference to the non-static field a
		b++;
		System.out.println("static block called");
	}
	public static void main(String args[]){
		StaticBlock obj1=new StaticBlock();
		StaticBlock obj2=new StaticBlock();
		StaticBlock obj3=new StaticBlock();
	}
 
}

Already constructor is initialiing the object attribute,then what is the necessary to 
use static block? 
		Answer. If we have 100 objects , then constructor is called 100 times, but static
		block is called only one time  though static variable intialisation can be done 100 times but
		the static block is called only one time & this is the advantage of using static block.
		So by using static block we can reduce compiler time.
example.
package CoreJavaByAtos;

public class StaticBlockUsage {
	int a=20;
	static int b=10;
	StaticBlockUsage(){ //constructor
		a++;
		System.out.println("Default Constructor called");
		System.out.println(a);
	}
	static{
		b++;
		System.out.println("static block called");
		System.out.println(b);
	}
	public static void main(String args[]){
		StaticBlockUsage obj1=new StaticBlockUsage();
		StaticBlockUsage obj2=new StaticBlockUsage();
		StaticBlockUsage obj3=new StaticBlockUsage();
	}
}
 
 Result:static block called
11
Default Constructor called
21
Default Constructor called
21
Default Constructor called
21
				
 */
}
