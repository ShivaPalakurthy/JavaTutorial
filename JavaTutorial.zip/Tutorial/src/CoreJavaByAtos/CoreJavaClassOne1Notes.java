package CoreJavaByAtos;

public class CoreJavaClassOne1Notes {
/*
 * 	//Discovery and Version

		1990  -   sun  -  project  -  consumer electronics
					   			   -  7  members team(James Gosling-team lead) -->R&D
		1991  -   OAK  Language
						    				JDK        Oracle JDK        Open JDK
		1995  -   OAK  + Web Features =>  Java 1.0
						                  Java 2.0
						  				  java 3.0
						  				  java 4.0  //  Java 2 (till java 4.0 version we define them as java 2)
						  				  java 5.0  //  Java 5 (Tiger Edition)
					          			  java 6.0  //  Java 6             Java 6
							    	  				//  Java 7
							    	  				//  Java 8 (commonly used)
							    	  				//  java 10
							    	  				//  java 11
							    	  				//  java 12
							    	  				//  Java 13
							          				//  Java 14
							    	  				//  Java 15
							    	  				//  java 16
							          				//  Java 17
							          				//	java 18        		 Java 18
	Oracle JDk from java 11 version comes with licesnce issue i.e you have to pay money
	 where as Open JDK is free/open source java platform& Open JDK started from
	  Java6 version.
	  
	  //Flavour -->how you'll this language is flavour
	   *  SE->Standard Edition
	   *  EE->Enterprise Edition
	   *  ME->Micro Edition
			
				JAVA SE            JAVA  EE            	    		  JAVA ME
				CORE JAVA   	   Web Application           		Mobile App
				- UI Project       frameworks- Spring , ADF
				 Applet/Swing	   , JSF,OAF , Struts etc
				 
		//BuzzWords
				- Object Oriented
				- Distributed
				- Secure
				- Platform Independent
				- Multi Threaded

		//Object Oriented Programming Language


		OBJECT - Anything that we find in the real life can be defined as  Object.
		       - Anything that have attribute and action
		       -  Two types of Object
					- Tangible (pen)
					- NON-Tangible (order)

				OBJECT			Attribute                  Action
				penObj			color , cost , brand       write
				mobileObj       brand , cost , storage     calling
				laptopObj		brand , cost , storage     play game



				Running  - NO
				Order -  YES  
				Nice - NO		
				Account - YES
	
	Advantage Of OOps:
	1.Object Oriented: OOp differs from procedural programming, becuase procedural 
	programming stresses the sequence of coding steps required to solve a problem,whereas
	OOP stresses the creation & Interaction of Objects.
	2.Modularity: The source code for an object can be written & maintained Independently
	of the source code for other objects.After it is created, an object can be easily
	passed around inside the system.
	
	 eg.Lets say ATos office has a code, HR object has HR related Code, Support object 
	 has support related code, IT team object has It related code etc
	3.Information-hiding: By interaction only with an object's methods,the details of its
	internal implementation remain hidden from the outside world
	4.Code re-use: If an object already exists(perhaps written by another software developer)
	you can use that object in your program.This allows specialists to implement,test,
	and debug complex,task-specific objects,which you can then trust to run in your own
	code
	
	
	


	Web Application using Java:
	
		UI									SERVER
	----------------- 			-------------------------------------------
	|				|			|-----------------		----------------- |
	|	HTML		|			||	Web-server	 |		| App-Server	 ||					EIS
	|	CSS			|			||				 |		|				 ||				-------------
	|	Java Script	|			|| 	ex.tomcat	 |		|ex.jBoss		 ||				|			|
	|	Bootstrap	|			||	web component|		|				 ||				|	DB		|
	|	Angular		|			||	 -servlet,	 |		|App Component	 ||				|	ERP		|
	|	Extjs		|			||	 jsp,bean	 |		|	ejb,adfbs,	 ||				|	CRM		|
	|				|			||				 |		|	springbc	 ||				|	JMS		|
	|				|			||				 |		|				 ||				|			|
	|				|			||				 |		|				 ||				|			|
	|				|			||				 |		|				 ||				-------------
	|				|			|-----------------		----------------- |
	-----------------		     ------------------------------------------
	BL-Java script								BL-Java										BL-PLSQL
	
	EIS-Enterprise Information System--> Its going to point out the database
	UI-USer Interface
	Bl-Business Logic
	ejb->enterprise java bean
	adfbc->application development framework business component
	bc4j->business component for java
	Webcomponent & Application components are used to write business logic to web server
	& Application server respectively
	
	
		Web Component						vs			APP  Component
	A.Servlet,Jsp,Beam								A. ejb,adfbc,springbc,bc4j
	B.Used for small application with			B.Used for Enterprise level Application
	   less data base intercation				i.e running on multiple servers through out the world ex. banking application, insurance application etc,
	C.Single Web App							C.Enterprise level Application
		--single Host									--Multiple host
		--Less db interaction							--more db interaction
														--distributed
														--persistance
														--Transaction
														--multi threaded
														--Location transparency.
														
						//DISTRIBUTED
			- It is a feature of Enterprise Level Application
			- remotely call function.
			- calling function from one JVM to Another JVM			
			
														
			   EJB	   getAirIndiaFlightDetails()	 ADFBC
			[server1]         ----------           [server2]
			  JVM                                     JVM
		      www.makemytrip.com                      www.airindia.com



		  //Secure
				A. JDK ,  JVM Provide Security.
				B. No pointer concept , use the concept of reference



		 //Platform/OS Independent 
			JAva is platform independent where as JDK is platform dependent
			
			javac Hello.java-->javac compiler will compiles java source code to byte code-->compilation
			
			Hello.class--> this is the byte code & this byte code can run on any server
			
			So we can say , compiled once it can run anywhere is the concept of java which 
			makes it platform/OS independent
			
			consider two modules A & B one in windows & other is in Linux respectively
			
				Project Module A				Project Module B
						.war			<=>				.war
						.jar			<=>				.jar
						
		we'll excahnge the module from Ato B & B to A as .war /.jar not as .class file
		just for understanding purpose we'll say it as .class file
		
		
		 //Multi Threaded
		  * Multiple threads can share the resources so automatically its of less cost
		  * most of the servers uses thread implementation.
		  * 
The Java Programming language supports multithreading.This allows several tasks to run
concurrently (at same time), such as querying a database,performing long-running & complex
calculations, & displaying a user interface.
Multithreading allows a java technology program to be very efficient in its use of systen
resources.The image illustrates how the java programming language is multi-threaded.


				-----------------------------------------------------
			   |	   	[ code]			[code2]			[code 3]	 |
		       |  [Thread]  |      [thread] |	[thread]	|		 |
			   |  			|				|				|		 |
			   -------------------------------------------------------
				  			|				|				|
				  		database		Printer		Graphicl Useer Interface
				  		
				  		

		// JAVA   Setup :
			s-1  download load JDK.(java 8)
			s-2  set path=C:\Program Files\Java\jdk1.8.0_321\bin
			
			
			
			exact steps according to your laptop:
			1. Download JDK (you have java 18)
			2.cd C:\Users\a861892\Documents\Core Java Problems --> to open the folder in which you want to code
			3.Now set path of java 16.
			
				C:\Users\a861892\Documents\Core Java Problems>set path=C:\Program Files\Java\jdk-18.0.1.1\bin;
				
			4. To check whether the version is setuped or not
				C:\Users\a861892\Documents\Core Java Problems>java -version
			
			5. Ideally you'll get result as follows
			java version "18.0.1.1" 2022-04-22
Java(TM) SE Runtime Environment (build 18.0.1.1+2-6)
Java HotSpot(TM) 64-Bit Server VM (build 18.0.1.1+2-6, mixed mode, sharing)

		Basic java program
			class Hello{
				public static void main(String args[]){
					System.out.println("Hello!!!");
				}
			}
			s-3   /> javac Hello.java	-->compilation
			      /> java Hello			-->run


    // Till java 8 version we've to write main method inside the java class
 
  
 
		Hands On : 1
		Write a program that accept five string as command line arg.
		and generate the output in a specific way as
			ABC  GLOBAL   Ltd , Bangalore , India.




		command line arg = argument during runtime

		/> javac CommandLineDemo.java
		/> java CommandLineDemo   
					  0     1       2      3         4

		class CommandLineDemo{
				public static void main(String args[]){
					String s1= args[0];
					String s2= args[1];
					String s3= args[2];
					String s4= args[3];
					String s5= args[4];
					System.out.println(s1+" "+s2+" "+s3+","+s4+","+s5x+".");
				}
		}
 
 
 
 				//JVM,JRE and JDK
 JDK is OS/Platform dependent
 JDK has 1.JRE
		2.Documentation
 JRE->Java Runtime Environment
  		-->3 major section
  				1.JAva Virtual Machine-->comes into picture while running the code
  				2.J2se package like java.util.*
  									java.sql.*
  									java.io.*
  				3.Compiler like java,javc,rmic
 JVM-->JAva Virtual Machine-->it is used to run the byte code.
 						  --> It is used to load the .class  file & convert it to native/machine code
 						  -->It is specification
 BEA system developed its own JVM =>JRocket
 Oracle developed its own JVM=>Hotspot
 
 JVM has 3 layers
 		1.Class Loader-->USed to load the .class file
 		2.Byte Code Verifier-->used to verify the byte code that i
 		3.Execution unit-->Execute the byte code
 A.ClassLoader can be of any type like Bootstrap class loader,Extension class loader,
 application class loader.It provides security for the .class file & JVm
 									
 									
 									JDK
 	---------------------------------------------------------------------------------
 	|													JRE							|
 	|							  ------------------------------------------------	|
 	|							 |---------------------JVM----------------------- | |
 	|							 ||	---------	----------		-----------		| | |
 	| 							 ||	|		|	|		  | 	|			|	| | |
 	|	---------------------	 ||	|		|	| Byte	  |		|Execution	|	| | |
 	|	|				 	|	 ||	|class	|	| code	  |		|unit		|	| | |
 	| 	| Documentation		|	 ||	|loader	|	| Verifier|		|			|	| | | 
 	|	|					|	 ||	|		|	|		  |		|			|	| |	|
 	|	---------------------	 ||	--------	-----------		------------	| |	|
 	| 							 |----------------------------------------------- |	|
 	|							 |												  |	|
 	|							 | ---------------------------------------------- |	| 
 	|							 ||		J2SE PACKAGE							| |	|		 
 	|							 ||			java.util.*							| |	|
 	|							 ||			java.sql.*							| |	|
 	|							 ||			java.io.*							| |	|
  	|							 | ---------------------------------------------  |	|
 	|							 |												  |	|
 	|							 | ---------------------------------------------  |	|
 	|							 | |	compiler								| |	|
 	|							 | |	java,javac,rmic							| |	|
 	|							 | |											| |	|
 	|							 |  --------------------------------------------  |	|
 	| 							 -------------------------------------------------	|
 	---------------------------------------------------------------------------------
 
 	
			//CLASS & OBJECT

		OBJECT - Anything that we find in the real life can be defined as  Object.
		       - Anything that have attribute and action
		       - Two types of Object
					- Tangible (pen)
					- NON-Tangible (order)

				OBJECT			Attribute                  Action
				penObj			color , cost , brand       write
				mobileObj       brand , cost , storage     calling
				laptopObj		brand , cost , storage     play game

	Class-->It is called as blueprint of an object
			Object attribute is defined as an instance variable of the class
			Object action is defined as a method inside the class
			
			
			eg. class Pen{
				String color;			//instance variable
				String cost;
				String inkCOlor;		//object attribute
				
				void wirte(){			//object action
					int a=10;			//local variable
				}
			}
			
			instance varibale				vs  	local variable
	1.Defined inside a class outside			1.Defined inside a method
		method.
	2.Instance variable scope is 				2.Local variable scope is inside
		 complete class								the method
	3.Instance variables are by default			3.Local varibale needs to be manually
	 initialised								initialise else we cannot use it.
	 
	 
	 eg. Try this code to see how instance & local variables are initialised
	 
	 	class Hello{
	 		String color;
	 		int cost;
	 		
	 		void show(){
	 			System.out.println(color+"/"+cost);
	 		}
	 		
	 		public static void main(String args[]){
	 			int x;
	 			System.out.println("Local Variable value"+x);
	 			
	 			Hello obj=new Hello();
	 			obj.show();
	 		}
	 	
	 	}
	 	
	 	execute with out int x & with int x
	 	
	 	
String args[]--> The purpose of String args[] is to take command line arguments during
run time
 * 		  	
 */
}
