	package CoreJavaByAtos;

 

public class CoreJavaClassThree3Notes {
/*
 * 
		//OOPS - data hiding -Bean Class

  
		constructor - used to initialize object(static or non-static) attribute.
		static block - used to initialize object(static) attribute.

		Bean Class:
			- Any class that have instance variable and its getters
			 and setters is called a bean class. 
			- used to initialize objects private attribute
				and get the private artribute value outside the class.
			-used to implement data hiding. 
Bean class has many names such as POJO-plane old java object /To -transfer object6x
			
			class  Dept{
			int deptId;
			String deptName;

			public int getDeptId(){   // getters
				return deptId;
			}		
			public void setDeptId(int  did){ //setters
				deptId = did;
			}
			public String getDeptName(){   // getters
				return deptName;
			}		
			public void setDeptName(String dname){ //setters
				deptName = dname;
			}
			public static void main(String args[]){
				Dept  obj = new Dept();//deptId=0 , deptName = null
				obj.setDeptId(200);//deptId=200 , deptName = null
				obj.setDeptName("Max");//deptId=200 , deptName = Max
				System.out.println(obj.getDeptId()+"/"+obj.getDeptName());
			}
		}
Both getters & setters have one of the instance variable name in it
getters->used to return the instance variable value
setters->used to initialise any instance variable value


Access Specifier in JAva:
		1.public
		2.private
		3.protected
		4.default
		
		
		1.default:If we not assign /declare any access specifier then by default it isknown
		as default access specifier.It is nothing in java.
		Any class with default access specifier cannot be accessed outside the package.
		2.Public:can be defined before class name/variable name/method name.If something is
		public means it is avaialable every where in the same package as well as in 
		different package also.it is available in same package different class & different
		package different class.
		3.Private:In java there is no concept of private class,private access specifier can
		be defined to variable /method name only in java. private datamembers & private
		methods are not accessible outside a class
		4.Protected: we cannot write protected class in java , we can write to datamember & methods
		in java. datamembers-->instance variables.If we define protected for a particular
		variable & method, that will be available to the package & all subclass
		
									Access Modifiers
		MOdifier			Class			Package			Subclass		World
		Public				Yes				Yes				Yes				Yes
		Protected			Yes				Yes				Yes				No
		No modifier			Yes				Yes				NO				No
		Private				yes				NO				No				NO
		
		
		
		//OOPS - Data Hiding:
				- Hide  data member and method inside a object.
				- Data Hiding can be done using two different approach.
						A. using private data members.
						B. using private method.
						
		//Private Access Specifier:
		 example 1: 
 			 class    Product{
				private  int prodId=1001;
				private String prodName="Card";
				private void display(){
					System.out.println(prodId+"/"+prodName);
				}
			}

			class ProdDemo{
				public static void main(String args[]){
					Product  obj = new Product();
					System.out.println(obj.prodId);
					System.out.println(obj.prodName);
					obj.display();
				}
			}
			
			sol:you'll get error so to access private method write code as below
			
			 	class    Product{
				private int prodId=1001;	 
				private String prodName="Card";
				private void display(){
					System.out.println(prodId+"/"+prodName);
				}
				void show(){
					display();
				}
			}

			class ProdDemo1{
				public static void main(String args[]){
					Product  obj = new Product();
					obj.show();
				}
				
			}
			
 It is recommended to decalare any instance variable as private in java
 Using getters you can access private data values & using setters you can intitalise 
 private data values
 
 			package CoreJavaByAtos;
class Product1{
	private int prodID;
	private String prodName;
	public int getProdID() {
		return prodID;
	}
	public void setProdID(int prodID) {
		this.prodID = prodID;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
 
}
public class ProductDemo {
		public static void main(String args[]) {
			Product1 obj=new Product1();
	//		System.out.println(obj.prodId);
	//		System.out.println(obj.prodName);  //The field Product1.prodName is not visible
	
	//Goto source-->Generate Getters & Setters
			//using getters
			System.out.println(obj.getProdID());
			System.out.println(obj.getProdName());
			
			obj.setProdID(1101);
			obj.setProdName("Shiva");
			System.out.println(obj.getProdID());
			System.out.println(obj.getProdName());
		}
}


		//Object Relationship:
			- Two Types Of Object Relationship:
				A. HAS  A  - one object contain another object
				B. IS  A  - one object inherit another object.

				Product Object  have  Item Object
				Dept Object  have     Emp Object
				Order Object  have    OrderItem Object
				Saving Acc   IS A   Account Object
				Bike    IS  A   Car
				
				
				We shouldn't create forcefull relationship eg.
				mobile objct		Bike object -->cann't create relationship
				Cup Object			laptop Object
				
				
				Class Employee{		|			Class Dept{
									|
									|
				}					|			}
									|
								Dept have Employee
			Relationship name:have
			cardinality   1:M 	M:1		M:N		1:1
			1:M->one department have many employess
			M:1->many department have one employess
			M:N->many department have many employess
			1:1->one department have one employee
			
				IS a=Inheritence
				
				[Account]                        class Account{
					/\								}
					||IS a relationship			class SavingAccount extends Account{
					||								}
				[Saving Account]
				
				
	when one contained object cannot exist without the container object,then that kind
	of relationship is called composition
	
	Java doesn't support multiple inheritence using the concept of class, where as
	python supports the concept of multiple inheritence using class.Java supports the
	concept of multiple inheritence using Interface
	
	
                     OOPs - INHERITANCE
			  - It is defined as  IS A Relationship
			  - Inherit base class property inside derived class.
			  - re-usability.
			  
			  
			  

		    //Single Inheritance: between two class

			class  Shape { //base class
				String h1 = "hello";
			}
			class   Circle  extends Shape{ // derived class

			}
			class SingleDemo{
				public static void main(String args[]){
					
				Circle  c = new Circle();
				System.out.println(c.h1);

				}
			}
			
			
		   //Multilevel Inheritance : more than 2 class
 
			class  Shape { //base class
				String h1 = "hello";
			}
			class   Circle  extends Shape{ // derived class

			}
			class Line extends Circle { // derived class

			}
			class MultiLevelDemo{
				public static void main(String args[]){
					
				Line   l = new Line();
				System.out.println(l.h1);

				}
			}



		     //Hierarchical Inheritance : one base class and 
						more than one derived class


			class  Account{  //base class

				String accNo = "bank00012345";

			}
			class  SavingsAccount extends Account{  // derived class
				void display(){
					System.out.println("acc no inside SA"+ accNo +"SA");
				}

			}
			class CurrentAccount extends Account{
				void display(){
					System.out.println("acc no inside CA"+ accNo+"CA");
				}
			}
			class  HierarchicalDemo{
				public static void main(String args[]){
					SavingsAccount  sa=new SavingsAccount();
					sa.display();
					
					CurrentAccount  ca=new CurrentAccount();
					ca.display();					
				}
			}



		//Multiple Inheritance : more than one base class

			class  Account{  //base class
				String accNo = "bank00012345";
			}
			class SupportDemo{}
			class  SavingsAccount extends Account,SupportDemo{  // derived class
				void display(){
					System.out.println("acc no inside SA "+ accNo +"SA");
				}
			}
			
			class  MDemo{
				public static void main(String args[]){
					SavingsAccount  sa=new SavingsAccount();
					sa.display();
					
				}
			}

		- java does not support multiple inheritance.



	//super:
		- it is a keyword in java.

		- base class and derived class have same variable value.
		- creating an object of derived class will always print derived class object attribute.
		- base class instance var value is hidden.
		- when variable hiding is disease then super is cure.

		- using super we can call base class data member and method.

	    class    AA  {	

		int   a = 7; 

	     }
	 
	    class  BB  extends  AA {

		int  a = 9;

		public void show(){
			System.out.println("a="+ a);
		}
		public static void main(String args[]){
			BB obj =new BB(); 	
			 obj.show();
		}
	    }


	program used to show difference in program by using super keyword using super 
	we can call base class data member and method.
		
		class    AA  {

int   a = 7; 

} 

class  BB  extends  AA {

int  a = 9;

public void show(){
	System.out.println("a="+ a);
	System.out.println("Super.a="+ super.a); //used to print base class value.
}
public static void main(String args[]){
	BB obj =new BB();
	 obj.show();
}
}

	
	super()
		- it is used to call base class constructor.
		- re-usability
		- super() must be the first statement inside the constructor.
		
		
	//	pROGRAM  to show the use if super() function  
		class    XX {
	int a;
	int b;
	XX(){
		System.out.println("default const of XX");
	}
	XX(int x,int y){
		this.a=x;
		this.b=y;
		System.out.println("para const of XX"+a+"/"+b);
	}
}
class   YY extends XX{
	int c;
	YY(){
		System.out.println("default const of YY");
	}
	YY(int x,int y,int z){
		this.a=x;
		this.b=y;
		this.c=z;
		System.out.println("para const of YY"+a+"/"+b+"/"+c);
		
	}
	public static void main(String args[]){
		YY obj=new YY(30,40,50);
	}
}
here problem is already there is 	XX(int x,int y){
									this.a=x;
									this.b=y;} we're not reusing it and we're direactly intialising in 
					
						YY(int x,int y,int z){
							this.a=x;
							this.b=y;
							this.c=z; }
							
if base class already has some initialisation, then we should reuse that code from derived class to base class. so we
can reuse the code by using super() function.


for an instance lets say XX(int x,int y){
									this.a=x;
									this.b=y;} has 60 lines in it & if we write 
60 lines in	YY(int x,int y,int z){
							this.a=x;
							this.b=y;
							this.c=z; } then the code becomes complex, to reduce complexity
& to improve reusability we use super() function to use base class.


class    XX {
	int a;
	int b;
	XX(){
		System.out.println("default const of XX");
	}
	XX(int x,int y){
		this.a=x;
		this.b=y;
		System.out.println("para const of XX"+a+"/"+b);
	}
}
class   YY extends XX{
	int c;
	YY(){
		System.out.println("default const of YY");
	}
	YY(int x,int y,int z){
		super(x,y);
		//this.a=x;
		//this.b=y;
		this.c=z;
		System.out.println("para const of YY"+a+"/"+b+"/"+c);
		
	}
	public static void main(String args[]){
		YY obj=new YY(30,40,50);
	}
}
	
	
	
	Hands On :4
		base class : Clothing
			instance var : id , price , color , size
			constructor:
			getters and setters:

		derived class : Shirt
			instance var : fit
			constructor:
			getters and setters:

		derived class : Trouser
			instance var : fit , gender
			constructor:
			getters and setters:

		1.Create 3 Shirt object using Shirt parameterized constructor and print all the attribute.
		2.Create 3 Trousers object using Trousers parameterized constructor and print all the attribute.


 */
}
	