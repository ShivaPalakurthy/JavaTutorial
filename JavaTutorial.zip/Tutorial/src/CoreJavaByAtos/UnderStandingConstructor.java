package CoreJavaByAtos;

public class UnderStandingConstructor {
			int empId;
			String empName;
			String empEmail;
			
			
			void displayInfo() {
				System.out.println(empId+"/"+empName+"/"+empEmail);
			}
			public static void main(String args[]) {
				UnderStandingConstructor obj=new UnderStandingConstructor(); /*
				without declaring default constructor also we are able to initiale the object
				because JVM by default provides default constructor
				*/
				obj.displayInfo();
			}
			
			
}
