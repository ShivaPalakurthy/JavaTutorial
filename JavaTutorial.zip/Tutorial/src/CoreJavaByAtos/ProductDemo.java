package CoreJavaByAtos;
class Product1{
	private int prodID;
	private String prodName;
	public int getProdID() {
		return prodID;
	}
	public void setProdID(int prodID) {
		this.prodID = prodID;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
 
}
public class ProductDemo {
		public static void main(String args[]) {
			Product1 obj=new Product1();
	//		System.out.println(obj.prodId);
	//		System.out.println(obj.prodName);  //The field Product1.prodName is not visible
	
	//Goto source-->Generate Getters & Setters
			//using getters
			System.out.println(obj.getProdID());
			System.out.println(obj.getProdName());
			
			obj.setProdID(1101);
			obj.setProdName("Shiva");
			System.out.println(obj.getProdID());
			System.out.println(obj.getProdName());
		}
}
