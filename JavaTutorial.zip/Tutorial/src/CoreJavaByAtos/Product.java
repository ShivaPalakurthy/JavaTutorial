package CoreJavaByAtos;

public class Product {
	int a=20;
	static int b=10;
	Product(){
		a++;
		System.out.println("Default Constructor called");
		System.out.println(a);
	}
	static{
		b++;
		System.out.println("static block called");
		System.out.println(b);
	}
	public static void main(String args[]){
		Product obj1=new Product();
		Product obj2=new Product();
		Product obj3=new Product();
	}
}
