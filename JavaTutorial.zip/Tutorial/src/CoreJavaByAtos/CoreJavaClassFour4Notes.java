package CoreJavaByAtos;

 

public class CoreJavaClassFour4Notes {
/*
 * OOPs Polymorphism
 * Polymorphism-->same function do differenet tASK. 
 * 			   -->Two types
 * 						a. Function overload/Compile Time Polymorphism
 * 						b.Function Override/RUntime Polymorphism
 * 
 * // Function overload/Compile Time Polymorphism
 * 			-Same function with different signatures or different parameters
 *          -same function is overloaded with same argument /different type of argument
 *          with different signatures (int/flot/ext in function name) may have same /differnect
 *          access specifiers like int/float/etc is called asCompile time/ Function
 *           overlaoding ppolymorphism.
 *          -while executing function overloading polymorphism ,which function to be called
 *          is decided during compile time, that's why it is called compile-time
 *          polymorphism.
 *          -same function do different task executed in compiler
 *          -Advantage is from compiler persepective while using function overload polymorphism
 *          ->Same function can be overloaded based on number of argument/type of argument & do 
 *          different task.
 *          -doesn't depend upon fucntion overload
 *          
 *          
 * public class Calculator {

 
	public static int addition(int x, int y) {
		return x+y;
	}
	public static void addition(float x, float y) {
		System.out.println( x+y);
	}
	public static float addition(int x, float y) {
		return x+y;
	}
	public static void main(String args[]) {
	System.out.println(addition(200,400)); 
		addition(20.00f,40.00f);
		System.out.println(addition(12,30.00f)); 
	}
}



//Api example of function overload/compile time polymorphism
 *     System.out.println();
 *     say if you want to print a string,  System.out.println("Hello");
 *     say if you want to print a int,  System.out.println(20);
 *     say if you want to print a obj,  System.out.println(empobj);
 *     
 *     goto Api documentation of java 8,
 *     			System is a class that is defined in the lang package
 *     If we go into System class we'll find 3 objects PrintSTream err,InputStream in,
 *     PrintStream out.
 *     so,		out is an object of PrintSTream
 *     so Printstream is a class when we got inside Printstream we'll see
 *     different methods inside the class.
 *     PrintLn is a method & depending upon the value linke boolean, char,int ,float,
 *     object,string ,etc that specific println method gets executed. 
 *  		
 *  
 *  
 *   		//Fumction OVerride /Runtime POlymorphism
 *   Function OVerride:
 *   		--Same function signature in base class & derived class ,that function is 
 *   		  overriden in the derived class
 *   		--do differnet task
 *   		--run time polymorphism comes under the  concept of inheritence
 *   		--we override the base class method in the derived class with its own code.
 *   		--overriden method must have strong or equal access specifier
 *   
 *   
 *   
 *   
 class Shape2{	
  		void area(){			//here access specifier is default
  		
  		System.out.println("inside shape");
  	}
  }
  class Circle2 extends Shape2{
 	void area(){			//here access specifier is default
  		System.out.println("Area of circle");
  	}
  }
  
  //here same function is overridden from base class to derived class
  
  class OverrideDemo{
	  public static void main(String args[]) {
		  Shape2 sh=new Circle2(); //dmd
		  sh.area();
	}
  }
 *   //DMD-Dynamic method Dispatch
 *   	 -always super class reference will point to derived class object but the reverse
 *   is not true.
 *   		
 *   	Shape sh=new Circle() ==>	CORRECT
 *   	Circle c=new Shape()==> Not Correct
 *   
 *   //Runtime Polymorphism:
 *    Runtime Polymorphism always support DMD
 *    In runtime polymorphism we should always call derived class object using 
 *    the base class reference.
 *    Advantage is from the compiler perspective as it sees only single method.
 *    as we can seee,
 *    			 Shape2 sh=new Circle2(); uses DMD which fucntion to be called
 *    that is area() when should be called will be deicided during run time that is why
 *    it is called run time polymorphsim.
 *    
 *    
 *    //APi example of Runtime polymorphism
 *    
 *    		toString()=> method is an example of run time polymorphism
 *    ->Any class in java bydefault extends an Object class.
 *    ->this object calss is defined inside lang package =>java.lang.Object
 *    ->toString() method is a part of this OBject class (java.lang.Object)
 *    
 *    
 *    //API example of Function overridding / run-time  polymorphism
public class Employee {
	private int empId;
	private String empName;
	
	//Generate using constructor using fields
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
 
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
 public static void main(String args[]) {
	Employee obj=new Employee(100,"ATOS");
	System.out.println(obj);
	}}
	
	Result is coreJava.Employee@6e8cf4c6 --> it is the objetc adress in the heap in 
	 * hexa decimalResult is coreJava.
  As we know, Any class in java by default extends an object class. so we should 
  override object class to string method in above example.
  
  //Overriding object to STring method : source-->Override/implement methods-->toString()
   * 
   * @Override
public String toString() {
	// TODO Auto-generated method stub
	return super.toString();
	
	to make it more accurate *We'll override by following steps
	 * 		Source-->Override/Implement methods --> choose  After 'Employee(int,String)'
	 * 		at Insertion point:--> select toString() -->click ok/
	 * 
	 * by doing this we'll be placing 
	 * 			@Override
			public String toString() {
				// TODO Auto-generated method stub
					return super.toString();
	}		at line 17- 22

	 If we not print toString() method in the class, then it will print object address
	in the heap, if we overridden toStrig() inside a class with your own code , if I'm
	going to print any object, it'll call the toString() implementation and print
	the attribute value.
	s
	
so the code will be as follows

public class Employee {
	private int empId;
	private String empName;
	
	//Generate using constructor using fields
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
//17-22 line obtained by bottom procced try without this once and using this u'll 
//	find the difference 
	@Override
	public String toString() {
		// TODO Auto-generated method stub
	//	return super.toString();  -->modifying this witl the following return value
		return empId+"/"+empName;
	} 

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
 public static void main(String args[]) {
	Employee obj=new Employee(100,"ATOS");
	System.out.println(obj);
 } }
	
	
	
	HAnds On: Polymorphism
	Create a base class Fruit which has name,taste & size as its attributes.
	A method called eat() is created which describes the name of the fruit & its taste.Inherit
	the same in 2 other class Apple & orange & override the eat() method to represent
	each fruit taste.
	
	//final -it is a keyword in java
	 		-final class cannot be extended
	 		-final variable is constant
	 		-final method cannot be overriden
	 		
	 		
	 		// Program to explain Final keyword
	 		 class Laptop { 
private int lapId = 10000;

void display() {
	System.out.println(lapId);
}
}

class Order extends Laptop {

} 


final class Laptop {  --> The type Order cannot subclass the final class Laptop -->
If we define a class as final , then final class cannot be inherited or extended.

final class Laptop { 
	 private int lapId = 10000;

	void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	
}  


Using final keywords as a variable -->The final field Laptop.lapId cannot be assigned
 * 
 * If we make a particular variable as final , we cannot change that variable value	
 * throughout your complete inhertitence hierarchy

class Laptop { 
	 final int lapId = 10000;

	void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	
	void show() {
		lapId=2000;
	}
}



final keyword for a method --> result:Multiple markers at this line
								- overrides coreJava.Laptop.display
								- Cannot override the final method 
	 								from Laptop 
class Laptop {
	private int lapId = 10000;

	final void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	void display() {
		System.out.println("Overriden method");
	}
}


//Encapsulation
 
 
 	Encapsulation = Abstraction + Data Hiding
 	
 	
 											|
 				 operations allowed			|
 				 |Withdraw		|			|		  |			  |   |			  |   |			  |
 				 |deposit		|			|		  |Application|   |	Proxy	  |   |Data base  |
 	[Client-]===>|check balance	| ==>  [ATM Center]==>|server	  |==>|	Server	  |==>|server 	  |
	 debit/ 	 |change pin	|			|		  |			  |   |			  |   |			  |
	 credit care |transfer		|			|		  |			  |   |			  |   |			  |
	 										|		  
	 										|
 	Some of the functionalities are 				Some functionality is hidden from 
 	exposed to the customer							customer 
 	
 	The concept of exposing some 					Hidding some functionalities to the
 	functonalities to the customer is 				customer is called data hiding
 	called as ABstraction	
 			Abstraction										Data Hiding
 	Implemented by using Abstract class/			Implemented by private access 
 	Interfaces										specifier
 			
 		Encapsulation = 	Abstraction			 +			 Data Hiding
 						Abstract class/					private access specifier
  						Interface
  						
  //ABstraction:
   			Abstract is a keyword in java
   			Any class with abstract keyword is called an abstract class
   			Inside abstract class we have 2 types of method.
   					1.method with definition 
   					eg.void openAccount() {     //method with definition
						System.out.println("Account is Open");
						}	
   					2.method with declaration
   					eg.abstract void closeAccount();
   			if we create method with declaration then that method must be Abstract.
   			Any class extends an abstract class must have to override all the method
   			declared inside the abstract class.
   			we can not create an object of abstract class.
   			Any class that have abstract method must be abstract
   			
   			
   			
   			
	//Example on Abstract Class.
abstract class Account3 {
		void openAccount() {     //method with definition
			System.out.println("Account is Open");
		}
		abstract void closeAccount(); //method with declaration
		abstract void ActiveAccout(); //if we create method with declaration then that method must be Abstract.
}
class SavingsAccounts extends Account3{
	//	--If Any class that extends an Abstract class, must have to override all
	//	the abstract methods declared in the abstract class.
//so now we've to override all the abstract methods.After overriding the errors will be
gone.
//

	@Override
	void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Overriden closed Account");
	}

	@Override
	void ActiveAccout() {
		// TODO Auto-generated method stub
		System.out.println("Overriden Active Account");
	}
	//	--If Any class that extends an Abstract class, must have to override all
   //	 			the abstract methods declared in the abstract class.
   	//so now we've to override all the abstract methods.
   //
	
	class AbstractDemo{
		public static void main(String args[]) {
			Account3 acc = new SavingsAccounts();//super class reference is pointing towards derived class 
									//object -->run time polymorphism 
			acc.openAccount();
			acc.ActiveAccout();
			acc.closeAccount();
		}
	}
	
}

Limitations of Abstract class:
	Abstract class doesn't support the concept of multiple inheritence
	
	Using Interfaces we can achieve multiple inheritence.
	
	//Interface till java 7: It is a keyword in java
	 			 
	 			interface contain method with decleration but we cannot have 
	 			method with defination.
	 			Method in Interface/Interface method in java is by default public & ABstract
	 			Any variable/data member declared inside an Interface by default public static & final
	 		**IMp. One interface always extends another interface, where as class implements
	 				another interface
	 			ANy class implements an interface must have to override all the abstract methods declared
	 			inside the interface
	 			Interface supports multiple Inheritence
	 				
	Interface scenarios:
	
	1.[class	]		2.[Interface]			3.[Interface]			4.[class	]
	
	extends/\	   	  implements/\				extends/\           doesn't exist/\	
		   ||					||					   ||						 ||
	  [class	]		  [class	]			  [interface]			  [interface]
	  
	  
	  
	  //Example on Interface

interface Account4 {
		public static final int acc=100010101; //Any variable/data member declared inside an Interface by default public static & final
		void openAccont();// Interface method in java is by default public & ABstract
}
//Interface supports multiple inheritence
interface support{}
interface Comfort extends Account4{} //One interface always extends another interface

class savingsAccount implements Account4,support,Comfort{ //class implements another interface

	@Override
	public void openAccont() {
		// TODO Auto-generated method stub
		
	}
	
	
}
 

		Abstract Class						||				Interface
	A.	If the project is in midlle				A.If the project is starting from scratch/
		level, then it is advised to go with	 core level/start, then it is advised to go with Interface for
		Abstract class for Abstraction			Abstraction
		
		In java 8 we can Interface with both method with declaration & also with
		method with definition.
		In java 8,we can write method with definition in interface also that is called default
		method & static method
		
		
		hands On:
		     HandsOn : Interface     
        Create an interface Compartment to represent a rail coach.
        Provide an abstract function notice in this class.
        Derive FirstClass, Ladies, General, Luggage classes from the compartment class.
        Override the notice function in each of them to print notice suitable to the
         type of the compartment.
        Create a class TestCompartment to implement Runtime Polymorphism.s
 */		
}
