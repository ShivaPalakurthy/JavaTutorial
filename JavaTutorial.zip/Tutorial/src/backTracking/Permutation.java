package backTracking;

public class Permutation {
  /* BACKTRACKING- Find all the possible solutions and use the solution that you want.
   *  
   * when ever we deal with recursion if the proccess gets long then we start to analyse
   * that problem in the form of Tree. 
   * 
   * 
   * Time complexity will be n*n!--> acheived as n!--> is the total answer
   * 											 n-->n steps are required to get one answer	
   * 	
   * */
		
	
	
	
	
	public static void printPermutation(String str,String perm, int indx) {
		if(str.length()==0) {
			System.out.println(perm);
			return;
		}
		for(int i=0;i<str.length();i++) {
			char currChar=str.charAt(i);
			String newStr=str.substring(0,i)+str.substring(i+1);
			printPermutation(newStr, perm+currChar, indx+1);
		}
	}
	
	public static void main(String args[]) {
		String str="ABC";
		printPermutation(str,"", 0);
	}
}
