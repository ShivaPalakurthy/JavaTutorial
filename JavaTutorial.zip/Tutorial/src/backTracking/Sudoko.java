package backTracking;

public class Sudoko {


/*
 *  3 Rules that needs to be followed while doing Sudoko
 *  1-9 once in row,column & grid(3*3)
 *  
 *  
 *  
 	 * CODE IS WRITTEN IN TERMS OF HACKERRANKING
	 * SEE VIDEO ONCE AGAIN WHEN YOU WANT TO UNDERSTAND THIS PROGRAM.
 * */
	
	public boolean isSafe(char[][] board,int row, int col, int number) {
		
	
	//checks condition for row,then column and then grid
	/*to check whether a number exists in the grid or not we'll have to find the 
	 * starting point of every grid.
	 * To get the starting point we have two strategies
	 * 1. (r,c)
	 *  (r/3*3)		,	(c/3*3)
	 *    0					0  ----> if r/3=0 then we are in  first three horizontal grids
	 *    						and if c/3=0 then we are in the first 3 vertical grids so
	 *    						when we get 0,0 then it must be the starting grid because
	 *    						it is the only common grid between first 3 horizontal grid
	 *    						& vertical grid.
	 *    1         ,       1----> if r/3 is 1 the we are in the middle grids lines horizontally
	 *    							if c/3 is 1 tehn we are in vertical middle grids. so  1,1 give
	 *    							the exact location of centre grid
	 *    in this way we'll get the grids startig position. when we multiple this r/3 value with 3 */
	 
	   //condition for row & col
		for(int i=0; i<board.length;i++) {
			if(board[i][col]==(char)(number+'0')) {		//row condition
				return false;
			}
			if(board[row][i]==(char)(number+'0')) { //col condition
				return false;
			}
		}
		//grid condition
		int sr=(row/3)*3; 	//starting row-->sr
		int sc=(col/3)*3; //Starting column-->sc
		
		for(int i=sr;i<sr+3;i++) {			//since grid is a 3*3 matrix 
			for(int j=sc;j<sc+3;j++) {
				if(board[i][j]==(char)(number+'o')) {
					return false;
				}
			}
		}
		return true;
	}
	 public boolean helper(char[][] board, int row,int col) { //recursive function
		 if(row==board.length) {
			 return true;
		 }
		 int nrow=0;  //nrow--> new row
		 int ncol=0;				/*we declared these two variables in order to find what will be 
		 				the next row and column w.r.t the next recuursion */
	  if(ncol!=board.length-1) {
		  nrow=0;
		  ncol=col+1;
	  }else {
		  nrow=row+1;
		  ncol=0;
	  }
	  if(board[row][col] !='.') {  //checks the given position is zero or not
		  if(helper(board, nrow, ncol)) {
			  return true;
			  
		  }
	  }else
	  {
		  for(int i=1;i<=9;i++) {
			  if(isSafe(board,row,col,i)) {
				board[row][col]=(char)(i+'0'); //type casting int to char to equate the values
				if(helper(board, nrow, ncol)) {
					return true;
					
				}else {
					board[row][col]='.'; //keeping the initial value and updating the i value
				}
				
			  }
		  }
	  }
	  return false;
	 }
   public void solveSudoko(char[][] board) {
	  helper(board,0,0);  
   }
}