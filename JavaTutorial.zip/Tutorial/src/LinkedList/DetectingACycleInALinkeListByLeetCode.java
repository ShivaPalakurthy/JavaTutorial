package LinkedList;


//Very Important Problem In a LinkedList
public class DetectingACycleInALinkeListByLeetCode {
	
	/*this method of detecting the loop & deleting the loops is known as 
	 * Floyd's Algorithm of detecting loops / Hare Turtle method
	 * 
	 * 				 H
	 * 				[1]-->[2]-->[3]-->[4]---->null
	 * 					   |			|
	 * 					   |____________| -->This is loop & it should be searched & deleted
	 * or else the loop will keep on going creating a problem
	 * 
	 * Floyd's Algorithm- It states that when HAre & Turtle will be at the starting point 
	 * of the linkedList & Hare moves at 2steps where as Turtle moves at one step.i,e hare
	 * moves twice the speed of turtle. so If at any point if both turtle & Hare meets in 
	 * the linkedlist while moving, then the linked List has cycle inside it.
	 * 
	 * 	Hare distance=2*( turtle)
	 * 
	 */
	
	//CODE IS WRIITEN IN LEETCODE FORMAT MODIFY IT TO OWN CODE LATER
	class ListNode{
		int val;
		ListNode next;
		ListNode(int x){
			val=x;
			next=null;
		}
	}
	public class Solution{
		public boolean hasCycle(ListNode head) {
			if(head==null) {			// corner case
				return false;
			}
			ListNode hare=head;	//fast pointer
			ListNode turtle=head;//slow pointer
			while(hare!=null &&hare.next!=null) {
				hare=hare.next.next;
				turtle=turtle.next;
				
				if(hare==turtle){
					return true;
				}
			}
			return false;
		}
		
	}
}

/* 
 * HomeWork Problem Try code to delete the cycle in a LinkedList
 * 
 * 								  _____________________________
 * 								  |							   |
 * 								_ =	meeting point			   |
 * 								| |							   |
 * 								k |							   |
 * 								| |							   |
 * 			____________________|_|	Starting point			   |
 *  		<---------m---------->|							   |
 * 								  |							   |
 * 								  |							   |
 * 								  |				n			   |
 * 								  |____________________________|
 * 
 * Let total loop length be 'n', 
 * 	   distance from head to starting point is 'm'
 *    Meeting pint of hare & turtle is '='
 *     Distance from starting point to meeting point is 'k'
 *     
 *     Now Steps to remove the circle in linkedlist:
 *     		1.As soon as the meeting point is acheived i.e both hare & turtle meet then
 *     		start moving turtle/slow towards head & start moving hare , the next 
 *     		point at which they i,e both hare & turtle meet again, That will be our
 *     		starting point.
 *     		2.by removing that starting point we'll able to remove all the circles from 
 *     		the linkedList
 */	
