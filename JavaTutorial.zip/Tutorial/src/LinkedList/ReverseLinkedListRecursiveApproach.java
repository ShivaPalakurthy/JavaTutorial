package LinkedList;
/*
 *  Reversing a linked List
 *  
 *   H                            ==>  							H
 *  [1]-->[2]-->[3]-->[4]-->null	  null<--[1]-->[2]-->[3]-->[4]
 *  
 *  condition No extra memory to be used. i.e Space Complexity should be O(1).
 */

import LinkedList.ReverseLinkedListIterativeApproach.Node;

public class ReverseLinkedListRecursiveApproach {
/*
 * Given LinkedList is [1]-->[2]-->[3]-->[4]-->null
 *  
 *	RECURSIVE APPROACH
 *
 *
 *	Atevery level			At every level of 
 *  of recursion 			recursion 1,2,3,4
 *  Linkedlist 				will be head 
 *	will be as				respectively
 *	
 *	(-)					|	   null		|
 * 	(4)					|	  4->head	|
 * 	(3-4)				|	  3->head	| <--[4]<--H	    =>this will be return for 3
 * 	(2-3-4)				|	  2->head	| <--[3]<--[4]<--H  =>this will be return for 2
 * 	(1-2-3-4)			|	  1->head	| <--[2]<--[3]<--[4]=>this will be return for 1
 * 						----------------
 *1.st step:--
 *Condition to achieve	  		head.next.next=head. 
 *At level 2, i.e			    2.next->3.next=2
 *						 => 	   2-->3-->2
 *next step;  to cut the connection beteween 2->3
 *									head.next=null 
 *
 *By this way we'll cut the connection between 2  3-->2
 * 		return newHead;
 * 
 * 
 * 				so,			head.next.next=head;
 * 							head.next=null
 * 							return newHead
 */
	
	
	//copy ReverseLinkedListIterativeApproch code & delete reverseIterate function
	
	Node head;
	private int size; 
	private void ReverseLinkedRe() {
		  	this.size=0;
	}
	
	  
	class Node{   
		
		String data;  
		Node next;     
		 
		Node(String data){	 
			this.data=data;
			this.next=null;  
				size++;			 
		}
	}
 
	public void addFirst(String data) {
		Node newNode =new Node(data);
		if(head==null) {  
		head=newNode;	
		return;
		}
		newNode.next=head;  
		head=newNode; 
	}
 
	public void addLast(String data) {
		Node newNode=new Node(data);
		if(head==null) {
			head=newNode;
			return;
		}
		Node currNode=head;		 
		while(currNode.next!=null) {
			currNode=currNode.next;   
		}
		currNode.next=newNode;		 
	}
 	public void printList() {
		if(head==null) {
			System.out.println("The list is empty");
			return;
		}
		Node currNode=head;		 
		while(currNode !=null) {
			System.out.print(currNode.data+"->");
			currNode=currNode.next;   
		}
		System.out.println("Null");
		
	}
 	public void deleteFirst() {
		if(head==null){			//corner case
			System.out.println("This is an empty list");
			return;
		}
		size--;
		head=head.next;  
	}
 	public void deleteLast() {
		if(head==null) {  
			System.out.println("The list is empty");
			return;
		}
		size--;
		if(head.next==null) { 
			head=null;
			return;
		}
		Node secondLast=head;  
		Node lastNode=head.next;  
		while(lastNode.next!=null){  
			lastNode=lastNode.next;
			secondLast=secondLast.next;
		}
		secondLast.next=null; 	
	}
	public int getSize() {
		return size;
	}
	
	//reversing LinkedList by recursive function
	public Node reverseRecursive(Node head) {
		if(head==null||head.next==null) {  //base case
			return head;
		}
		
		Node newHead= reverseRecursive(head.next);
		head.next.next=head;
		head.next=null;
		return newHead;
	}
	 
	public static void main(String args[]) {
		ReverseLinkedListRecursiveApproach list=new ReverseLinkedListRecursiveApproach();
		list.addLast("1");
		list.addLast("2");
		list.addLast("3");
		list.addLast("4");
		list.printList();
		list.head=list.reverseRecursive(list.head);
		list.printList();
 
	}
}
