package LinkedList;
				//Performing actions of Linkedlist by using Collection FrameWorks
import java.util.*;
// Or you can use this too -->import java.util.LinkedList;
public class ActionsUsingCollectionFrameWorks {
	
	public static void main(String args[]) {
		LinkedList<String> list=new LinkedList<String>();
		
		
		//adding element from first
		list.addFirst("a");
		list.addFirst("is"); 
		list.addFirst("this");
		System.out.println(list);
		
		//adding element from last
		list.addLast("linked");
		list.add("list"); //list.add(String); -->by default it will add element in the last
		System.out.println(list);
		
		//Size
		System.out.println(list.size());
		
		//printing the list
		for(int i=0;i<list.size();i++) {
			System.out.print(list.get(i)+"->");
		}System.out.println("null");
			
		
		//Searching an element
		String value="is";
		for(int i=0;i<list.size();i++) {
			if(list.get(i)==value)
			System.out.print(list.get(i)+"->");
		}System.out.println("null");
		
		//delete first
		list.removeFirst();
		System.out.println(list);
		list.remove(); //list.remove(); -->by default it will remove the first element
		System.out.println(list);
		
		//delete last
		list.removeLast();
		System.out.println(list);
		
		//deleting element by using index
		list.remove(1); //index starts from 0,1,...
		System.out.println(list);
 
	}
}
