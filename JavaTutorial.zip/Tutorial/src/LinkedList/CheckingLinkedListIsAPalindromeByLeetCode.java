package LinkedList;

public class CheckingLinkedListIsAPalindromeByLeetCode {
	
	//Main condition is not to use extra space
/*
 * Palindromes example: BOB,POP,141,1221	
 * 
 * [1]-->[2]-->[1]-->null
 *	// check whether the given linkedlist is a palindrome or not?
 *
 * //Proceduer to check whether the given linkedlist is palindrome or not  by not using
 * additional space
 * 
 * 1.We'll divide the linked list into half and we'll reverse the second half of the 
 * linkedlist.
 * 
 * 	For even NOdes.
 * 		[1]-->[2]-->[2]-->[1]-->null
 * 					|	After reversing the second half linkelist be as folows
 * 		 H			|
 * 		[1]-->[2]-->[2]<--[1]<-nextHead/2nd half start
 * 					/
 * 				 null
 * 
 * For Odd Nodes.
 * 				[1]-->[2]-->[1]-->null
 * 						|
 * 						|
 * 				[1]-->[2]-->[1]
 *  	 					/
 * 						 null
 * 	2.Then we'll compare the nodes of linkedlist first & last elements respectively 
 * 
 * 
 * How can we reverse the half of the linkedList.
 * 			Usually when we'll reverse an entire linkedlist,we use to pass the initial
 * node as head, but if we want reversing only on the second half of the linkedList,
 * then we'll send the second half starting node as head i.e head will be middle of
 * the linkeList, thereby reversing only the second half of the linkeList
 * 
 * 					[1]-->[2]-->[3]-->[4]-->null
 * 								/
 * 							 head
 * 								||
 * 								\/
 * 					[1]-->[2]-->[3]<--[4]<=node as newHead
 * 								/
 * 							  null
 * 
 * SO the 3point Strategy is 
 * 			1.take the middle of the linkedList
 * 			2.Reverse the second half of the linkedlist
 * 			3.Check First half & second half
 */		
	//CODE IS WRIITEN IN LEETCODE FORMAT MODIFY IT TO OWN CODE LATER
	
	public class ListNode{
		int val; // 5
		ListNode next;
		ListNode(){
			
		}
		ListNode(int val){
			this.val=val;
		}
		ListNode(int val,ListNode next){
			this.val=val;
			this.next=next;
		}	
	}
	class Solution{
		
		//reverse function
		public ListNode reverse(ListNode head) {
			ListNode prev=null;
			ListNode curr=head;
			while(curr!=null) {
				ListNode next =curr.next;
				curr.next=prev;
				prev=curr;
				curr=next;
			}
			return prev;
		}
		
		/*
		 * FInding middle of the linkedList by using hare(rabbit) turtle approach
		 * 
		 * Hare(rabbit) is usually faster than turtle so if we take a linkedlist & keep 
		 * hare & turtle at the starting point of LinkeList , then Hare will take two steps
		 * while turtle takes one step. i.e Hare moves at a speed of 2x of turtle.
		 * 
		 * 
		 * Lets assume an even Linkedlist
		 * 
		 * Hare>Turtle in speed		Hare  \
		 * 							(ptr1)	\
		 * 							 |		  \H------------>H--------->null
		 * 							[1]-->[2]-->[3]-->[4]-->[5]-->[6]-->null
		 * 							 |
		 * 						Turtle---->T---->T
		 * 						(ptr2)			 |
		 * 										 |
		 * 										STOP--> MIDDLE
		 * 
		 * In even LinkedList there will be two middle points and the middle point
		 * at which the Turtle stops is the end point of the first half i.e	first middle
		 *  of the LinkeList
		 *  
		 *  Lets assume an Odd Linkedlist
		 *  
		 *  					Hare-------->H---------->H
		 *  					[1]-->[2]-->[3]-->[4]-->[5]-->null
		 *  				Turtle--->T---->T
		 * 									|
		 * 									|
		 * 					Turtle can't move as HAre was in end point so element [3] in the 
		 * linkeList will become as the middle of the linkedList
		 * 
		 */
		
		public ListNode findMiddle(ListNode head) {
			ListNode hare=head;
			ListNode turtle=head;
			while(hare.next!=null && hare.next.next!=null) {
				hare=hare.next.next;
				turtle=turtle.next;
			}
			return turtle;
			
		}
		public boolean isPalindrome(ListNode head) {
			if(head==null || head.next==null) {		//corner case head.next==null means single node
				return true;
			}
			ListNode middle=findMiddle(head); //1st half ka end we can rename middle as fistHalfEnd also
			ListNode SecondHalfStart=reverse(middle.next);//you'll get reversed second half with newNode as head
			
			
			//comparing first half & second Half
			ListNode firstHalfStart=head;
			while(SecondHalfStart !=null) {
				if(firstHalfStart.val!=SecondHalfStart.val) {
					return false;
				}
				firstHalfStart=firstHalfStart.next;
				SecondHalfStart=SecondHalfStart.next;
				
			}
			return true;
		}
	}
}

