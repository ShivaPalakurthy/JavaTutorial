package LinkedList;
public class DeletingNthNodefromLastByNormal {
   
			Node head;
		
			class Node{  //we represent node as class in java 
				
				int data;  
				Node next;   //next will be of type node as it stores next node data that forms link
				 
				Node(int data){	//constructor
					this.data=data;
					this.next=null; //by default/initially it'll be NUll i.e when ever we make new node,
									// its next will be null.
				}
			}
			public void addLast(int data) {
				Node newNode=new Node(data);
				if(head==null) {
					head=newNode;
					return;
				}
				Node currNode=head;		//making initial node as head
				while(currNode.next!=null) {
					currNode=currNode.next;  //traversing from head to last element
				}
				currNode.next=newNode;		/*it comes out of loop when it reaches last node
				now we are pointing this last node next to the newNode */
				
			}
			
			//Printing the Linkedlist
			public void printList() {
				if(head==null) {
					System.out.println("The list is empty");
					return;
				}
				Node currNode=head;		 
				while(currNode !=null) {
					System.out.print(currNode.data+"->");
					currNode=currNode.next;   
				}
				System.out.println("Null");
				
			}
	 
 
			
				public Node removeNthFromEnd(int n) {
					if(head.next==null) {
						return null;
					}
					//finding size of the linkedList
					int size=0;
					Node curr=head;
					while(curr.next!=null) {
						curr=curr.next;
						size++;
					}
					
					/* if we want to only search & print the lastNode 
					 * 
					 * int indexToSearch=size-n-1;
					 * ListNode curr=indexTosearch;
					 * 
					 * //we'll print curr in public static void main.
					 */
					
					
					if(n==size) {  //corner case if we have to delete sizeth node i.e head
						return head.next;
					}
					
					
					int indexToSearch=size-n;
					Node prev=head;
					int i=0;
					while(i!=indexToSearch) {
						prev=prev.next;
						i++;
						
					} 
					prev.next=prev.next.next; 
					return head; 
					
				}
			
		 
			
 	public static void main(String args[]) {
			 DeletingNthNodefromLastByNormal list=new DeletingNthNodefromLastByNormal();
			 list.addLast(1);
			 list.addLast(2);
			 list.addLast(3);
			 list.addLast(4);
			 list.addLast(5);
			 
			 int n=3;
			 list.printList();
			 list.removeNthFromEnd(n);
			 list.printList();

			 
			}
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		 