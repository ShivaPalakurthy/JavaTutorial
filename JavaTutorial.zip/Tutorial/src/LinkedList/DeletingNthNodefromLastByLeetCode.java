package LinkedList;


   //Find & delete  the nth Node from the end of the LinkedList 
	
		/*	we get size=0 from starting side but we don't get size from last point as
		 * single linkedList has no pointer in the end.
		 * 
		 * 
		 * 			 H
		 * 			[1]-->[2]-->[3]-->[4]-->[5]-->null 
		 * 										<---
													(n)
		 * 			------>	
		 * 				  (size-n+1)
		 * 
		 * 
		 * If the distance of the linkedList frm end is 'n', then from begining it will
		 * be 'size-n+1'.
		 * 
		 * lets say n=2 & here size is 5;
		 * 		distance from start (DFS) will be-->5-2+1=>4  
		 * 			 H
		 * 			[1]-->[2]-->[3]-->[4]-->[5]-->null 
		 * 							   2	 1	<-- n=2
		 * 		=>	  1	   2	 3	   4
		 * 			5-2+1=4
		 * 	 if we want to delete the 4th element we've to point the 3rd element next to
		 * 5 element, there by the 4th element will be removed from the list thereby 
		 * deleted permanently by the garbage collector.
		 * So now the size shoul be 'Size-n' which gives 3element.
		 * 
		 * DFS previous =>size-n=>5-2=>3	==> prev.next=prev.next.next
		 *  
		 */

/*CODE IS WRIITEN IN LEETCODE FORMAT MODIFY IT TO OWN CODE LATER
 * 
 * Constraints:
 * 		The number of nodes in the list is sz.		sz-->size
 * 		1<=sz<=30
 * 		0<=Node.val<=100
 * 		1<=n<=sz
 */

public class DeletingNthNodefromLastByLeetCode {
	ListNode head; // by me to remove the error
	public class ListNode{
		int val;
		ListNode next;
		ListNode() {}
		ListNode(int val){
			this.val=val;
		}
		ListNode(int val,ListNode next){
			this.val=val;
			this.next=next;
		}
	}
	class Solution{
		public ListNode removeNthFromEnd(ListNode Head,int n) {
			if(head.next==null) {
				return null;
			}
			//finding size of the linkedList
			int size=0;
			ListNode curr=head;
			while(curr.next!=null) {
				curr=curr.next;
				size++;
			}
			
			/* if we want to only search & print the lastNode 
			 * 
			 * int indexToSearch=size-n-1;
			 * ListNode curr=indexTosearch;
			 * 
			 * //we'll print curr in public static void main.
			 */
			
			
			if(n==size) {  //corner case if we have to delete sizeth node i.e head
				return head.next;
			}
			
			
			int indexToSearch=size-n;
			ListNode prev=head;
			int i=0;
			while(i!=indexToSearch) {
				prev=prev.next;
				i++;
				
			}
			prev.next=prev.next.next;
			return head;
			
		}
	}
	}
