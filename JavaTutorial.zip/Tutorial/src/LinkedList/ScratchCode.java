package LinkedList;

import coreJava.gettersNdSetters;

/*
  * Linkedlist -its a list of elements/nodes that are linked to one another.
  * 
  * Arraylist is implemented in memory with the help of dynamic array. iF we want to
  * insert an element in the arrayList, we have to move all the elements which are
  * located after that point at which we want to insert backwards.So when we want to
  * perform insertion operation in middle of an ArrayList, time complexity becomes O(n)
  * 		In Arraylist we can directly search the elemant by using index e.g arr[2],so
  * time complexity of Arraylist will be O(1)when we want to search an element.
  * 
  * In LinkedList, memory is allocated in non-contiguous form that means forming linked
  * list by joining different different parts of the memory
  * 
  * Inserting an element in LinkedList
  * 		
  * 		1-->3-->4-->null -->Initial LinkedList
  * 		  ^	
  * 		  2		<--wants to insert between 1&3;
  * 				
  * 				then 1will point towards 2 and 2 will point towards 3 and the 
  * connection between 1&3 is removed forming the updated/Inserted Linked list as follows
  * 	
  * 			1-->2-->3-->4-->null 
  * 		If we look at this insertion in Linkelist we'll get to know that to 
  * add an new element in linkedList max we're performing 2-3 operations. SO the
  * time complexity of Linkedlist for Insertion is O(1). 
  * 
  * Searching an element in Linkedlist,
  * 			if we want to search an element in linkedlist we have to got from start
  * to that element so , To do the traversing of the entire Linkedlist the time complexity
  * of Linkedlist for search operation becomes O(n).
  * 
  * 
  * 
  * Comparing 				ArrayList 			vs 			Linked List
  * 
  * Insert Operation			O(n)			>				O(1) -->So Use linkedlist for insertion operation
  * Search Operation			O(1)			<				O(n)-->So use Arraylist for search Operatn.
  * 
  * so from the above we can say that , when ever we have to perform any manipulation 
  * operations like adding use Linkedlist & when we require to do an search operation
  * its advisible to use ArrayList so that time complexity becomes optimised.
  * 
  *  
  *  Properties Of Linkedlist:
  *  1.Variable size -->we can add as many element as we want until our memory gets filled.
  *  2.Non-Contiguous Memory
  *  3. Insert in O(1)
  *  4.Search in O(n) 
  *  
  *  Basic Structure Of LinekdList:
  *  		______
  *  		|Data|-->stores elemey/value
  *  		|next|-->stores next pointer/referrence
  *  		------
  *  		NODE
  *  
  *  Nodes gets linked to another nodes forming the LinkelIst;
  *  last node will be empty node /Null node. 
  *  the formation of lnkedlist 1-->2-->3-->null is as follows
  *  
  *  		|	1|     --> here ----  is reference of one node to another data element of second node 
  *  		|next|----|2   | 
  *  				  |next|----|3	 |
  *  							|next|----|null|
  *  									  |	   |
  *  
  *  the first node /first element of the linkedlist is called HEAD.
  *  the last node/last element of the linkedList is called Tail 
  *  
  *  Types of LinekdList:					H
  *  		!.Singular LinkedList  -->		[]-->[]-->[]-->Null
  *  										H
  *  		2.Double LinkedList	   -->		[]<-->[]<-->[]<-->Null
  *  		3.Circular LinkedList  -->Last node gets connected to the first node.
  *  
  *  
  */


public class ScratchCode {
	Node head;
	private int size;//to find the size of the linkedlist
	  ScratchCode() {  //initialising constructor with size =0
		  	this.size=0;
	}
	
	  
	class Node{  //we represent node as class in java 
		
		String data;  
		Node next;   //next will be of type node as it stores next node data that forms link
		 
		Node(String data){	//constructor
			this.data=data;
			this.next=null; //by default/initially it'll be NUll i.e when ever we make new node,
				size++;			// its next will be null.
		}
	}
	//add operation--> we can add first/we can add last but usually we'll add last
	
	
	/*				adding element FROM  first side
	 * 			 H
	 * 			[2]-->[3]-->[5]-->[null] ==> if we want to add [1] then we'll point the
	 * next of [1] to the head i.e [2] & we'll make head = [1]
	 * Then the linked list will be
	 * 				 H
	 * 				[1]-->[2]-->[3]-->[5]-->[null]
	 * 			
	 */
	
	public void addFirst(String data) {
		Node newNode =new Node(data);
		if(head==null) { ///to check whether the Linked	list exist or not
		head=newNode;	
		return;
		}
		newNode.next=head; //pointing next of newNode to the initial head
		head=newNode; //making newNode as the new/updated  head.
		
	}
	
	
	/*						adding element from last side
	 * 		  H
	 * 		[is]-->[a]-->[null] ; if we want to add [list]-->node from the last side, 
	 * then we'll start traversing from the start till we reach the last node i.e[a] node
	 * from that node we'll point the next of [a] towards the new element[list] and 
	 * usually newNodes next will be pointing towards NULL so there wont be necessity 
	 * to modify the NewNode.
	 * 
	 * 		[is]-->[a]-->[list]-->Null	--> Added new element from the last side.
	 *  	
	 */
	public void addLast(String data) {
		Node newNode=new Node(data);
		if(head==null) {
			head=newNode;
			return;
		}
		Node currNode=head;		//making initial node as head
		while(currNode.next!=null) {
			currNode=currNode.next;  //traversing from head to last element
		}
		currNode.next=newNode;		/*it comes out of loop when it reaches last node
		now we are pointing this last node next to the newNode */
		
	}
	
	//Printing the Linkedlist
	public void printList() {
		if(head==null) {
			System.out.println("The list is empty");
			return;
		}
		Node currNode=head;		 
		while(currNode !=null) {
			System.out.print(currNode.data+"->");
			currNode=currNode.next;   
		}
		System.out.println("Null");
		
	}
	
	
	//delete first
	public void deleteFirst() {
		if(head==null){			//corner case
			System.out.println("This is an empty list");
			return;
		}
		size--;
		head=head.next; /* if we want to delete the first element then we'll simple 
		make the second element as head, the garbage collector will automatically delete
		the first element & the first element will be gone forever.
		*/
	}
	
	//deleting element from the last element
	public void deleteLast() {
		if(head==null) { //corner case if head is null
			System.out.println("The list is empty");
			return;
		}
		size--;
		if(head.next==null) {/*corner case here;if head.next = null check after 5lines*/
			head=null;
			return;
		}
		Node secondLast=head;  
		Node lastNode=head.next; /*if head.next=null--> lastNode= null  then 
		 		null.next !=null gives error in next line so to avoid we write 
		 		corner case.*/
		while(lastNode.next!=null){ /*we'll traverse till second last node and make 
			the second last node next value to null by this the lastNode will be 
			automatically cleared by the garbage collector */
			
			
			lastNode=lastNode.next;
			secondLast=secondLast.next;
		}
		secondLast.next=null; 	
	}
	public int getSize() {
		return size;
	}
	
	// In C++ null is "NULL" whereas in Java null is "null"
	public static void main(String args[]) {
	 ScratchCode list=new ScratchCode();
	 list.printList();
	 list.addFirst("a");
	 list.addFirst("is");
	 list.printList();
	 
	 list.addLast("list");
	 list.printList();
	 
	 list.addFirst("this");
	 list.printList();
	 
	 list.deleteFirst();
	 list.printList();
	 
	 list.deleteLast();
	 list.printList();
	 
	 
	 //print size
	 System.out.println(list.getSize());
	 
	 list.addFirst("this");
	 System.out.println(list.getSize());
	 
	 
	 
	 
	}
}
