package LinkedList;

 
/*
 *  Reversing a linked List
 *  
 *   H                            ==>  							H
 *  [1]-->[2]-->[3]-->[4]-->null	  null<--[1]-->[2]-->[3]-->[4]
 *  
 *  condition No extra memory to be used. i.e Space Complexity should be O(1).
 */

public class ReverseLinkedListIterativeApproach {
 /*
  * Solving by Iterative Approach we'll solve by using 3variables
  * 	1.Current Variable, 2. previous Variable , 3. Next Variable
  * Cuurent variable will point towards node, Previous will point towards previous node to
  * current node & next will point towards next node of the current node.
  * 							CURR
  * 				PRE			 |			NEXT
  * 							 |
  * 							\ /
  * 				<--			node		-->
  * 
  * say [4]-->[5]-->[6]-->[7]-->null
  * 	prv	  curr	 next
  * 
  * Step :1 we should make curr.next=prv
  * 			   _____		   	
  * 			  |    |
  * 			 \/	   |
  * 			[4]-->[5]	[6]
  * 			prv	  cur	 nxt
  * 
  * Step.2 Update Current,previous , next
  *  i.e
  * <--	[5]		[6]---->[7]	  
  * 	 |		 |		 |
  * 	prv		cur		next
  * 
  * now repEat the step 1
  *    			   _____		   	
  * 			  |    |
  * 			 \/	   |
  * 		<--	[5]-->[6]	[7]
  * 			prv	  cur	 nxt
  * nOW IF YOU OBSERVE THE LIST
  * 
  * 	[4]<--[5]<--[6]		[7]---
  * 
  * In this way our linkedList, 3pointers & in 3 sets they'll get reversed.If we repeate again
  * and make [4]-->     as null we'll get reversed LinkedList
  * 
  * 
  * 
  */
	
				// NOW COPY THE SCRATCHCODE & MODIFY
	Node head;
	private int size; 
	ReverseLinkedListIterativeApproach() {   
		  	this.size=0;
	}
	
	  
	class Node{   
		
		String data;  
		Node next;     
		 
		Node(String data){	 
			this.data=data;
			this.next=null;  
				size++;			 
		}
	}
 
	public void addFirst(String data) {
		Node newNode =new Node(data);
		if(head==null) {  
		head=newNode;	
		return;
		}
		newNode.next=head;  
		head=newNode; 
	}
 
	public void addLast(String data) {
		Node newNode=new Node(data);
		if(head==null) {
			head=newNode;
			return;
		}
		Node currNode=head;		 
		while(currNode.next!=null) {
			currNode=currNode.next;   
		}
		currNode.next=newNode;		 
	}
 	public void printList() {
		if(head==null) {
			System.out.println("The list is empty");
			return;
		}
		Node currNode=head;		 
		while(currNode !=null) {
			System.out.print(currNode.data+"->");
			currNode=currNode.next;   
		}
		System.out.println("Null");
		
	}
 	public void deleteFirst() {
		if(head==null){			//corner case
			System.out.println("This is an empty list");
			return;
		}
		size--;
		head=head.next;  
	}
 	public void deleteLast() {
		if(head==null) {  
			System.out.println("The list is empty");
			return;
		}
		size--;
		if(head.next==null) { 
			head=null;
			return;
		}
		Node secondLast=head;  
		Node lastNode=head.next;  
		while(lastNode.next!=null){  
			lastNode=lastNode.next;
			secondLast=secondLast.next;
		}
		secondLast.next=null; 	
	}
	public int getSize() {
		return size;
	}
	
	public void reverseIterate() {
		if(head==null || head.next==null){//corner case -->no elemnt || single element
			return;
		}
		Node prevNode=head;
		Node currNode=head.next;
		while(currNode!=null) {
			Node nextNode=currNode.next;
			currNode.next=prevNode;			//STEP-1
			
			//Update 
			prevNode=currNode;
			currNode=nextNode;
		}
		head.next=null;
		head=prevNode;  /*when we traverse , at last it'll be
											[4]-->[5]-->[6]-->[7]-->null
															  prev	curr
											so we'll make prevNode as head
		*/
		
	}
	
	public static void main(String args[]) {
		ReverseLinkedListIterativeApproach list=new ReverseLinkedListIterativeApproach();
		list.addLast("1");
		list.addLast("2");
		list.addLast("3");
		list.addLast("4");
		list.printList();
		list.reverseIterate();
		list.printList();
	}
}


