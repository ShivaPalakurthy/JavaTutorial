package CollectionFrameworks;
/*
 * Basically there will be lot of algorithms & data structures ,which is being provided
 * directly by java so that we don't have to take the work to write & we can directly 
 * implement them.The benefit of collection Frameworks is that our time is being saved &
 * also all the data structures & algorithms in it are highly optimized
 											()bracket is for interface<-(Interface)
 	 										[] bracket is for class <---[class]	
 	 										
There are Collection ,Map ,Iterator Interface.
Map interface is kept separate from the collection interface because


  											()bracket is for interface<-(Interface)
 	 										[] bracket is for class <---[class]														
 				(Collection)
 					  |
 	---------------------------------						
    |				|				|		
 (List)			  (Set)			 (Queue)					(Map)				(Iterator)
   i.[ArrayList]	i.[EnumSet]		i.[ArrayDeque]			  i.[HasMap]			i.(ListIterator)
   ii.[LinkedList]	ii.[HashSet]	ii.[LinkedList]			  ii.[TreeMap]
   iii.[Stack]		iii.[TreeSet]	iii.[PriorityQueue]		  iii.[EnumMap]
   iv.[Vector]		iv.[LinkedHashSet]						  iv.[LinkedHashMap]
   															  v.[WeakHashMap]

   															  
When you want a data structure to store things in list form /contiguous fashion we'll use
List interface.A data structure where you want to store only unique values then we'll use
Set interface.A data structure where you can set a priority for elements on how you can 
retrive them is Queue interface.
*/	

public class Sample{
	
}
