package CollectionFrameworks;

import java.util.HashSet;
import java.util.Set;

/*
 * All the three sets named as Hashset,Linkedhashset & Treeset follows the property of a Set 
 * that it wont allow any duplicate values inside the set
 */
public class LearnHashSet {
public static void main(String args[]) {
	Set<Integer> set=new HashSet<Integer>();
	
	set.add(32);
	set.add(2);
	set.add(54);
	set.add(21);
	set.add(65);
	
	System.out.println(set); //Set doesn't follow any order, it is like a bag where we'll
	//add elements .Because order is not defined in the set.You can consider the set as bag
	//in which you are continuously putting the elements but you can't keep the same elements
	//inside it.When we try to remove the element from it we don't know which element is coming
	//out first. That is why elements are printing in some random order.In this set , hashing is 
	//going since it is a hashset, which makes an hash of our every element internally & that has will
	//be putting inside the collector & it is being checked that if the hash of any element is not
	//already present inside the set.Every element has this property that there hash will be unique.
	
	
	set.remove(54);
	
	System.out.println(set);
	
	//contains keyword is used to check if there is any particular element is present inside it or not
	//so contains function returns true or false
	
	System.out.println(set.contains(100));
	
	//isempty() is used to check whether our set is empty or not at this time
	
	System.out.println(set.isEmpty());
	
	System.out.println(set.size());//size()->used to give the number of elements inside set at this time
	
	set.clear();//clear()-->used to clear the set
	
	System.out.println(set);
	
	System.out.println(set.isEmpty());
	
	//The time complexity of all the operations(clear ,find , add) in the hashset is O(1).
	//That is why hashset is very optimised
}
}
