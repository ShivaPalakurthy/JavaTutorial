package CollectionFrameworks;

import java.util.Objects;
//AFTER THIS GOTO SORTING CUSTOM CLASS
public class StudentCustomClass implements Comparable<StudentCustomClass> { //first see SortingCustomClass before implementing comparable& compare to method
		String name;
		int rollno;
		public StudentCustomClass(String name,int rollno) {
			this.name=name;
			this.rollno=rollno;
		}
		//To String method
		@Override
		public String toString() {
			return "StudentCustomClass [name=" + name + ", rollno=" + rollno + "]";
		}
		
		//equals & hashcode for ROllno
		@Override
		public int hashCode() {
			return Objects.hash(rollno);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StudentCustomClass other = (StudentCustomClass) obj;
			return rollno == other.rollno;
		}
		//first see SortingCustomClass before implementing comparable& compare to method
		@Override //Source -->Generate Override/Implement Methods
		public int compareTo(StudentCustomClass o) { 
			//compares current student with the other student & will return an integer value,if tthe value
			//is positive then current student will be considered as big & if it is 
			//negative that means object o will be considered big inside sorted order &
			//if we get zero both the students are equal
			// TODO Auto-generated method stub
			return this.rollno - o.rollno; //sorting on basis of roll no
			
			
		}
		/*Now you want  to sort on the basis on name rather than roll number So we have
		two ways either you go inside student class again & change its compare to property so before
		we were sorting it according to the roll number but now the time has come to sort according to 
		names that means this.name.compare to o.name
		*/
//		@Override
//		public int compareTo(StudentCustomClass o) { //comment this to get the programm executed to eliminate the error
//			return this.name.compareTo(o.name);
//		}
		//here if you  see we are bounded ,means either you can compare it with name or 
		//with roll number if we write compare to function for roll no. we cannot write
		//compare to fucntion for the name at same time so here comes a dynamic thing which
		//is comparator.Only one comparable method can be there with one comparable clas 
		//mean we have defined that this thing can be only compared with this parameter,
		//but if you want to change the behaviour dynamically.Like, today I'm sorting with name
		//tommorow i"ll sort according to roll number so for that we want to make comparator
		//Either you can make comparator an anonymous class or you can make it separately
		
		
		
		
}
