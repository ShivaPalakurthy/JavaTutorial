package CollectionFrameworks;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

/*
 * Tree set also implements your set property but it has a special thing that it does the things
 * in sorted form behind the scenes.so it basically does its implementation on binary search tree&
 * with that it also implements the properties of set.Means all the elements will be unique & because
 * it is inside binary search tree that is why all the elements inside it will be in sorted form.
 * 
 * In treeset all the operations occur in O(log n) because it implements binary search tree & in binary search tree
 * all the operations add,remove,find all of these run inside log n.
 * 
 */
public class LearnTreeSet {
	public static void main(String args[]) {
		Set<Integer> set=new TreeSet<>();
		
		set.add(32);
		set.add(2);
		set.add(54);
		set.add(21);
		set.add(65);
		
		System.out.println(set); 
		
		set.remove(54);
		
		System.out.println(set);
		
		
		System.out.println(set.contains(100));
		
		System.out.println(set.isEmpty());
		
		System.out.println(set.size());
		
		set.clear();
		
		System.out.println(set);
		
		System.out.println(set.isEmpty());
	}
}
