package CollectionFrameworks;

import java.util.Stack;

/*
 * Stack is basically a Last in first out data structure.
 */
public class LeranStack {
	public static void main(String args[]) {
		Stack<String> animals=new Stack<>();
		//push to add elements
		
		animals.push("Lion");
		animals.push("Dog");
		animals.push("Horse");
		animals.push("Cat");
		
		System.out.println("Stack: "+animals);
		
		//peek:to check which element is at the top or added at the last 
		System.out.println(animals.peek());
		
		//pop to remove the top element from the list
		
		animals.pop();
		
		System.out.println(animals.peek());
		System.out.println("Stack: "+animals);
		
	}
}
