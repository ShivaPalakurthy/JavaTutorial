package CollectionFrameworks;

import java.util.ArrayDeque;

/*
 * Arraydeque-->Double ended queue-->This queue means we made such a queue that we can remove 
 * the element from front as well as from the end also we can add the element from front a&
 * from the back aswell.Also we can peek from both the sides. We use Array DEque in sliding
 * window Technique.
 * As it also implements Queue so all the method in queue will be available in ArrayDeque also
 */
public class LearnArrayDeque {
		public static void main(String args[]) {
			ArrayDeque<Integer> adq=new ArrayDeque<>();
			
			adq.offer(23);
			//ArrayDeques unique functions that makes them special
			adq.offerFirst(12);	//Adds elements at the head/firts of the ArrayDeque.
			adq.offerLast(45);//Adds elements at the tail/last of the ArrayDeque.
			adq.offer(26);
			
			System.out.println(adq);
			
			
			System.out.println(adq.peek()); //Here prints the first/front /head element in the ArrayDeque
			System.out.println(adq.peekFirst());
			System.out.println(adq.peekLast());
			
			System.out.println(adq.poll());
			System.out.println("poll() " +adq);

			System.out.println(adq.pollFirst());
			System.out.println("pollFirst() " +adq);

			System.out.println(adq.pollLast());
			System.out.println("pollLast() " +adq);
			
			/*
			 * With this arryaDeque we can implement queue &if we want to implement stack we can 
			 * implement stack aswell. since it has operations from two sides(head & tail), following
			 * only tail/last  options will implement stack by following LIFO order.
			 */
		}
}
