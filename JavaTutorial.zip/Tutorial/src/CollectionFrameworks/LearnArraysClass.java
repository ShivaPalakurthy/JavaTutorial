package CollectionFrameworks;

import java.util.Arrays; //Arrays class

/*
 * This array class is used to manipulate over arrays not on arraylists
 * we can easily do binary search inside array using arrays class
 * The binary search function inside Array class will work only when our array is sorted
 * because binary search works on binary search array & it will return either true or 
 * false & it will work over binary search & it works in O(Log n)
 */
public class LearnArraysClass {
	public static void main(String args[]) {
		int[] numbers= {1,2,3,4,5,6,7,8,9,10};
		int index=Arrays.binarySearch(numbers, 4);
				
		System.out.println("The index of element 4 in the array is " +index);
		
		Integer[] num= {10,2,32,12,15,76,48,79,9};		
		Arrays.sort(num);
		for(int i:num) {
			System.out.print(i+" ");
		}
		System.out.println();
		
		//if you want  a value gets fill inside the array, for that we have arrays.fill
		Arrays.fill(numbers,12);
		for(int i:numbers) {
			System.out.print(i+" ");
		}

	}

 
}
