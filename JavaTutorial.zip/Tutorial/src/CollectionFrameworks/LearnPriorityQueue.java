package CollectionFrameworks;

import java.util.Comparator;
import java.util.PriorityQueue;

/*								PRIORITY QUEUE
 * PriorityQueue helps to implement minheap, maxheap.
 * In PriorityQueue we give priority to the elements
 *
 */
public class LearnPriorityQueue {
	public static void main(String args[]) {
		PriorityQueue<Integer> pq=new PriorityQueue<Integer>();
		//Initially the element which comes out first will be the smallest element That will be 
		//the priority element.
		pq.offer(40);
		pq.offer(12);
		pq.offer(24);
		pq.offer(36);
		
		System.out.println(pq);/* we see that the order of the elements has changed in the 
		output.Order has been changed because min heap is being implemented here.Min heap is
		basically a data structure.so In Min heap data structure the smallest element is at the
		top.If we write poll, then that will come out who has the highest priority,for now
		here the priority is highest for the smallest element.
		If we want to make minheap in any question, then we can save time by directly using 
		Priority queue.
		
		*/
		pq.poll();
		System.out.println(pq);
		
		System.out.println(pq.peek());
		
		/*Now we want the largest element to come out.It should have the highest priority
		*so basically we can pass comparator into the constructor of priority queue and
		*that comparator will tell which element has the highest Priority*/
		PriorityQueue<Integer> pqq=new PriorityQueue<Integer>(Comparator.reverseOrder());
		//Comparator.reverseOrder() This will convert our minHeap to maxHeap
		pqq.offer(40);
		pqq.offer(12);
		pqq.offer(24);
		pqq.offer(36);
		
		System.out.println(pqq);
		pqq.poll();
		System.out.println(pqq);
		
		System.out.println(pqq.peek());
		}
}
