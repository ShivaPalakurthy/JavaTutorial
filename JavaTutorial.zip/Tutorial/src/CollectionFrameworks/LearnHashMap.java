package CollectionFrameworks;

import java.util.HashMap;
import java.util.Map;

/*
 * List,Set ,Queue is used to store the value where as map is used to store key value
 * Making Maps has lot of benefits,It's benefit is we can store key value pair in it &
 * all the keys are unique & values may be unique or may not be unique but keys are always
 * unique
 */
public class LearnHashMap {
	public static void main(String args[]) {
	//	Map<Key,Value>
	Map<String, Integer> numbers =new HashMap<>();
	
	//we'll add elements in Maps by using functin called put
	numbers.put("One", 1);
	numbers.put("Two", 2);
	numbers.put("Three", 3);
	numbers.put("Four", 4);
	numbers.put("Five", 5);
	//when you try to keep the key value again then it will override the previous value of
	//the same key here to key two , value 2 got overrided to 23.To avoid this we need to 
	//write check condition
	//numbers.put("Two", 23);
	if(!numbers.containsKey("Two")) { //it will add 25 only when there is no Key with Two
		 numbers.put("Two", 25);
	}
			//or
	numbers.putIfAbsent("Two", 25);
	
	System.out.println(numbers);
	
	System.out.println(numbers.containsValue(3));
	
	System.out.println(numbers.isEmpty());
	
	//There are two ways to iterate in a map, so whatever value is present inside maps,
	//an entry os created for them.Basically an entry class is there & in that way elements
	//keep adding inside it
	
	for(Map.Entry<String, Integer> e:numbers.entrySet()) {//numbers.entrySet() will returns the
								//entry set inside it
		System.out.println(e);
		//if you want to iterate only keys,we can also remove keys from entries
		System.out.println(e.getKey());//for key value
		System.out.println(e.getValue());//for value
	}
	//if you want to hava work only with keys & not with values we can do that by numbers.keyset function
	//numbers.keyset() function returns only key's set & you can iterate inside it
	
	for(String key:numbers.keySet()) {
		System.out.println(key);
	}
	for(Integer value:numbers.values()) {
		System.out.println(value);
	}
	}
	
}
