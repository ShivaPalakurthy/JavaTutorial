 package CollectionFrameworks;

import java.util.Map;
import java.util.TreeMap;


public class LearnTreeMap {
public static void main(String args[]) {
	Map<String,Integer>  numbers=new TreeMap<>();
	
	numbers.put("One", 1);
	numbers.put("Two", 2);
	numbers.put("Three", 3);
	numbers.put("Four", 4);
	numbers.put("Five", 5);
	/*
	 * Basically Tree map put key values under the hood inside a binary search tree,it keeps 
	 * sorting these keys.When I printed numbers ,we can see it has been sorted on the basis of
	 * the keys & the keys are Strings here so they are sorted on the basis on Alphabetical
	 * order
	 * 
	 * So all the operations that occur inside it will also occur inside O(log n).
	 */
	System.out.println(numbers);
	System.out.println(numbers.containsValue(5));
	
	System.out.println(numbers.isEmpty());
	numbers.remove("Three");
	System.out.println(numbers);
}
}
