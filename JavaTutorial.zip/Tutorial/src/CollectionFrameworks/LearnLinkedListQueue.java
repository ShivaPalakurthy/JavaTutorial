package CollectionFrameworks;

import java.util.LinkedList;
import java.util.Queue;

/*
 * LinkedList is basically a class & a class can implement multiple interfaces , so it
 * has implemented both List & Queue aswell.
 * Queue is a normal data structure which has the first in first out concept.If we want
 * to implement Queue we've two ways either we can implement queue through array or we can
 * implement trough linked list as well.
 * 
 * SO Queue is an interface which can be implemented by Arraylist, Linkedlist & priority
 * queue
 */
public class LearnLinkedListQueue {
	public static void main(String args[]) {
		Queue<Integer> queue=new LinkedList<>(); //we write Linkedlist here because Linkedlist
		//is implementing Queue Interface.Now linkedlist will have all those methods which is given
		//to it by Queue interface
		
		queue.offer(12);//.offer() function is used to add elements in the queue.
		queue.offer(24);
		queue.offer(36);
		
		System.out.println(queue);
		
		//since in queue the elements which entered first comes out firts & we do it by
		//poll function
		System.out.println(queue.poll());
		
		System.out.println(queue);
		
		//peek function-->tell which element is next in line for coming out
		System.out.println(queue.peek());
		
		
	/*There are 3 another adjacent functions which has different work
	*1.In order to add an element in a queue, we can use the add() or offer() method.But 
	*the difference between add() & queue() is if the element doesn't gets added succesfully
	*it throws an exception where as queue() will return true or false.
	*2.remove()-Returns & removes the head of the queue.Throws an exception if the queue is 
	*empty.
	*3.poll()-Returns & removes the head of the queue.Returns null if the queue is empty.
	*4.element()- Returns the head of the queue.Throws an exception if the queue is empty
	*5.peek()-Returns the head of the queue. Returns null if the queue is empty.
	*/
	}
}
