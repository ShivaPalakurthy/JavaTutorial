package CollectionFrameworks;

import java.util.HashSet;
import java.util.Set;

public class StudentHashSet {
	public static void main(String args[]) {
		Set<Student> studentSet=new HashSet<>();
		//lets add some students
		studentSet.add(new Student("Anuj",2));
		studentSet.add(new Student("Ramesh",4));
		studentSet.add(new Student("Shivam",3));
		System.out.println(studentSet);//we have to apply toString() method to Student class
		//to avoid the get outputs in values or else we will get value is hashcode
		//Rohit roll number is 2 if we add this to set, set will think it as a unique element
		studentSet.add(new Student("Rohit",2));
		studentSet.add(new Student("Anuj",2));
		studentSet.add(new Student("Anuj",5));
		
		//Even though both have diferent name & same roll no, same name & different roll
		//the HashSet wont find it because we are making it by doing new Student so
		//basically it is considering them as two different objects inside java, so 
		//hash set wont understand how to compare them & differentiate them.For this there
		// is a function which isequals().Hashset uses this equals method behind the scenes 
		//to check that if the element is already present inside it or not so now we make a 
		//hashcode & equals methods with a condition that we want those people who have
		//different roll numbers are different other than that people can be present with
		//the same names in same class
		System.out.println(studentSet); 
		//After implementing hashset & equals method only anuj with roll no.2& 5 will be
		//printed while others(Rohit,2 & anuj,2) wont be printed as they have same roll number
		
		
		

		
		
	}
}
