package CollectionFrameworks;

import java.util.Objects;

/*
 * A situation can come to us when we want to make set which is not primitive datatype,You 
 * want a custom class set.Lets suppose we have a class STudent & we have multiple
 * Students which have student name & roll no.We want to make an object of this & we know that
 * no two students of same class have the same roll no.s Means two students cannot have
 * the same roll number if they are in same class & we want to achieve something like this
 * using hashset. SO now lets make hashset with class name STudentHastset. 
 */
public class Student {
	String name;
	int rollno;
	public Student(String name,int rollno) {
		this.name=name;
		this.rollno=rollno;
	}
	//To avoid printing direct hashcode/ object & to print the values we have to 
	// implement toString() method
	@Override
	public String toString() {
		return "Student [name=" + name + ", rollno=" + rollno + "]";
	}
 

	//Try without out HAshcode & equals method first then try with them afterwards to understand
	//This hashcode & equalls method is there to differentiate on basis of roll no.
	//if we want to develop other cases then generate with those cases like on studnets or on bot
	//students & roll nos also
	
/*	
	@Override
	public int hashCode() {
		return Objects.hash(rollno);
	}
	//Initially it objects were different ,it was generating different hashcodes for them.
	//but now it two people have same roll number even though objects are different, but it
	//will generate their same hashcode because now hashcode will be generated on the basis 
	//of roll number.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return rollno == other.rollno;
	}
	
	
	*/

	
}
