package CollectionFrameworks;
/*
 * ArrayList is similar to array but drawback of array's is that they can't change the size
 * dynamically.
 */

import java.util.ArrayList; //has entire collection frameworks in it
import java.util.Iterator;
import java.util.List;

public class LearnArraylist {
		public static void main(String args[]) {
	/*	String[] studentsName=new String[31];
		studentsName[0]="Rakesh";
		//
		//studentsName[1]......studentsName[29]
		//
		studentsName[30]="Harish";
		
		//New Student i.e normal array cannot extend its size dynamically to overcome
		//this error we use arraylis
		studentsName[31]="Raman";
		
		for(int i=0;i<=31;i++) {
			System.out.println(studentsName[i]);
		} */
		
		ArrayList<String> studentsName=new ArrayList<>();
		//if initially size of an Arraylist is n then when it needs additional space
		//it size will become as n+n/2+1.
		
		studentsName.add("Rakesh");
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		System.out.println(list);
		
		list.add(4);//This will add 4 at the end of the list
		System.out.println(list);
		
		//Adding an element at particular position of the Arraylist
		list.add(1,50); //list.add(index,element) This will add 50 at the index of 1
		System.out.println(list);
		
		
		//Merging two ArrayLists
		ArrayList<Integer> newlist=new ArrayList<Integer>();//Creating new ArrayList
		newlist.add(150);
		newlist.add(160);
		
		
		list.addAll(newlist);//This will add all the elements of newlist to the list 
		System.out.println(list);
		
		//Getting an element from the list
		System.out.println(list.get(1)); //list.get(int index);
		
		//set function is used to update value of a Arraylist
		list.set(2, 10000);// list.set(index,element);
		System.out.println(list); //update value at index 2 with 10000
		
		//Contains function is used to check whether an element is present in the Arraylist or not
		System.out.println(list.contains(160));
		
		//Time complexity of contain function in ARraylist is O(n)
		
		//Iterating the Arraylist
		//Method -1
		for ( int i=0;i<list.size();i++) {
			System.out.println("The element is "+list.get(i));
		}
		//Method -2
		for(Integer element:list){// for every element int list
			System.out.println("foreach element is "+element);
		}
		
		//method -3
		//Every collection framework has an Iterator
		Iterator<Integer> it=list.iterator();//list.iterator(); function gives iterator &
		//Iterator carries many functionalities with it.so that we're able to iterate inside
		//any collection easily.First of all, it has-->hasNext. It tells if there is a next element
		//in the iterator or not
		while(it.hasNext()) { //so until it has a next element in it we'll print it
			System.out.println("iterator "+it.next());//it.next()-->we can access the 
						//next element in the iterator through this function
		}
		
		list.remove(1);//This will remove the element from index 1 :-list.remove(int index);
		System.out.println(list);
		
		list.remove(Integer.valueOf(150)); //This will remove the element with the value from the list
		System.out.println(list);
		
		list.clear();//This will remove all the elements from the list
		System.out.println(list);
		}
		
		
}
//Time complexity of Adding & removing element in an ArrayList is O(n)