package CollectionFrameworks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortingCustomClass {
	public static void main(String args[]) {
		List<StudentCustomClass> list=new ArrayList<>();
		
		list.add(new StudentCustomClass("Anuj",2));
		list.add(new StudentCustomClass("Ramesh",4));
		list.add(new StudentCustomClass("Shivam",3));
		list.add(new StudentCustomClass("Rohit",1));
		/*we will get error if we dont implement comparable in StudentCustomClass &
		 * The error is saying no instance of type t exist so that student conforms to comparable
		 * That means we cannot compare this StudentCustomClass type because it has not implemented
		 * the comparable,if we compare two Students in STudentCustomClass then we will be 
		 * able to tell that this will come first or this will come last & we are not telling a metho
		 * two compare these students  So to do this we have to implement an interface to
		 * StudentCustomClass which is comparable.
		 */
		Collections.sort(list); //uses compareto function internally
		System.out.println(list);
		
		StudentCustomClass s1=new StudentCustomClass("Anuj",2);
		StudentCustomClass s2=new StudentCustomClass("Rohit", 3);
		System.out.println(s1.compareTo(s2)); //-1 goto StudentCustomClass & check compare to function
			//here s1=2,s23 i.e this (2)-o(3)=-1
		/*Now you want  to sort on the basis on name rather than roll number So we have
		two ways either you go inside student class again & change its compare to property so before
		we were sorting it according to the roll number but now the time has come to sort according to 
		names that means this.name.compare to o.name in StudentCutomClass
		*/
		//here if you  see we are bounded ,means either you can compare it with name or 
		//with roll number if we write compare to function for roll no. we cannot write
		//compare to fucntion for the name at same time so here comes a dynamic thing which
		//is comparator.Only one comparable method can be there with one comparable clas 
		//mean we have defined that this thing can be only compared with this parameter,
		//but if you want to change the behaviour dynamically.Like, today I'm sorting with name
		//tommorow i"ll sort according to roll number so for that we want to make comparator
		//Either you can make comparator an anonymous class or you can make it separately
		//Now we want to sort on basis of name
		//so we can pass a list & after that we can pass a comparator inside the collection.sort function
		
		//we can pass our own comparator inside it  which is new comparator.type of Student
		Collections.sort(list,new Comparator<StudentCustomClass>() { //passing comparator as new anonymous class
			@Override
			public int compare(StudentCustomClass o1,StudentCustomClass o2) {
				return o1.name.compareTo(o2.name);
			}
		});
		System.out.println(list);
	}
}
