package CollectionFrameworks;

import java.util.ArrayList;
import java.util.Collections; //Collection class
import java.util.Comparator;
import java.util.List;

/*
 * Collection class has all the functions that are present in Collection frameworks but
 * on the top of collection framework,you need some more properties that are found in
 * collections class like you have to tell that which is the smallest element inside this
 * collection or largest element in a collection or the frequency at which an element 
 * occured in a collection
 */
public class LearnCollectionClass {
	public static void  main(String arg[]) {
		List<Integer> list=new ArrayList<>();
		list.add(34);
		list.add(12);
		list.add(9);
		list.add(76);
		list.add(29);
		list.add(75);
		list.add(69);
		list.add(9);
		list.add(9);
		
		System.out.println(list);
		System.out.println("min element " + Collections.min(list));
		System.out.println("max element " + Collections.max(list));
		System.out.println(Collections.frequency(list, 9));
		
		//by collections.sort() we can sort  with that help you can sort all the collection
		//classes
		Collections.sort(list);
		System.out.println(list);
		//if you want descending order pass comparator in the collections.sort
		Collections.sort(list,Comparator.reverseOrder());//this will give descending order
		System.out.println(list);
		
	}
}
