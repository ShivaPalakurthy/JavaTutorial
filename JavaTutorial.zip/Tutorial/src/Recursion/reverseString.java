package Recursion;

public class reverseString {
	
	public static void revStr(String str,int indx) {
		if(indx==0) {
			System.out.print(str.charAt(indx));
			return;
		}
		System.out.print(str.charAt(indx));
		revStr(str, indx-1);
	}
		public static void main(String args[] ) {
			String str="Adapt.Improvise.Overcome.";
			revStr(str, str.length()-1);
		}
}
 //time complexity = string length=O(n) where n is string length
	 
/*if we solve this problem with iteration method then we'll
 * take index=str.length-1 and well start printing values of the string from last. */
 