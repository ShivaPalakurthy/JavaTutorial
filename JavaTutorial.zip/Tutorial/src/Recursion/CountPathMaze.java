package Recursion;

public class CountPathMaze {
 /*
  * Count total Paths in a maze to move from (0,0) to (n,m) here assume n=3,m=3
  * conditions-- we can move in right or downwards only
  * 
  * i.e,
  *    										N*M=(3,3)			
  * 	   	   -------------------------------------
  * 		  	|0,0		|0,1		|0,2		|	
  * 			|			|			|			|
  * 			|			|			|			|
  * 			|			|			|			|
  *    	    	-------------------------------------
  * 			|1,0		|			|			|
  * 			|			|			|			|
  * 			|			|			|			|
  * 			|			|			|			|
  * 			-------------------------------------
  * 			|2,0		|			|			|
  * 			|			|			|			|
  * 			|			|			|			|
  * 			|			|			|		2,2	|
  * 			-------------------------------------
  * 
  * so here movable paths form 0,0 t0 2,2 using conditions is
  * 			 -------------------------------------
  * 		  	|0,0		|0,1		|0,2		|	
  * 			|-----------|------>----|--1->----- |
  * 			||	|	|	|	|	|	|		  |	|
  * 			||	|	|	|	3	2	|		  |	|
  *    	    	-------------------------------------  total paths =6 for each cell we have two choice but for the 
  * 			|1,0	4	|	|	|	|		  |	|		corner cell we'll have one choice
  * 			||	|	|	|	|	----|---2---- |	|   choices of each cell  is.. for  (i,j)			is
  * 			||	|	----|---|---4---|-----	| |	|			    either		(i+1,j)		or	(i,j+1)	 it is applciable
  * 			||	|__5____|__	|		|	  |	| |	| till i=n-1 and j=m-1
  * 			-------------------------------------
  * 			|2,0		|  ||		|	  |	| | |
  * 			||			|  |-----3--|---3-4	2 1 |
  * 			||			|  |________|_5__ | | | |
  * 			|---------6-|-----6-----|----6-(2,2)|
  * 			-------------------------------------
  */
	public static int CountPaths(int i,int j,int n, int m) {
		if(i==n ||j==m) {
			return 0;
		}
		
		if(i==n-1 &&j==m-1 ) {
					return 1;
		}
		
		//moving downwards
		int downPaths= CountPaths(i+1, j, n, m);
		
		//moving right
		int rightPath=CountPaths(i, j+1, n, m);
		
		return downPaths+rightPath;
}
	
		public static void main(String args[]) {
			int n=3,m=3; 
			int TotalPaths=CountPaths(0, 0, n, m);
			System.out.println(TotalPaths);
		}
}
//Time complexity - O(2^(m+n))
//this problem has very big timecomplexity when we do it with the recursion method so
// we'll use dynamic programming to reduce the time complexity'