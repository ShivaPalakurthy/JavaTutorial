package Recursion;

public class invitePeopleSingleOrPairs {
  /*Find the number of ways in which you can invite n people to your party, single or
   * in pairs
   * given n=4;
   * 
   * 
   * lets assue n=1 (1 person)   => 1				(x,y)-->calling x & y separately
   * 			n=2=>(1,2);(1-2)        (x-y)--> calling x nd y in pairs
   * 			n=3=>(1,2,3);
   * 				 (1-2,3);   calling 1&2 in pair and 3 singlely
   * 				 (1-3,2);
   * 				 (1,2-3);    we can call in 4 differenet ways when we invite 3
   * 			n=4=>(1,2,3,4)--> keeping 1 as single we'll have 4 choices
   * 				 (1,2-3,4)
   * 				 (1,2,3-4)
   * 				 (1,2-3,4)
   *				 (1-2,3,4)-->keeping 1 as pair we'll have 6 choices
   *				 (1-2,3-4)
   *				 (1-3,2,4)
   *				 (1-3,2-4)
   *				 (1-4,2,3)
   *				 (1-4,2-3)
   *  so we'll have total 10 choices of inviting guests when we have n=4
   *  
   *  Recursive approch: if we had called 'n'guests we can either call them in single or
   *  			in pairs.
   *  
   *  						  guest call(n)
   *  			____________________|______________________
   *  		   |										   |
   *           |single								   pair|
   *           |										   |
   *         call(n-1)				+			(n-1)	* (n-2)
   *			 ^	 							  |			|
   * 			for next calls we'll			  |  after taking two guest we'll be 
   * 			be calling n-1 guests			  |	 calling (n-2) guests
   * 									if we take one guest then 
   * 								he will has (n-1) choices to make partner
   */
   
		 public static int callGuests(int n) {
			
			  if (n<=1) {
				  return 1;
			  }
			 //single
			 int ways1=callGuests(n-1);
			 
			 //pair
			 int ways2=(n-1)*callGuests(n-2);
			 
			 return ways1+ways2;
		}
	public static void main(String args[]) {
			int n=4;
			System.out.println(callGuests(n));
	}
}
