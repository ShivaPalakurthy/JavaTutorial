package Recursion;

public class FirstAndLastOccurance {
 /* lets say we want to know about first and last occurance of a in this string "abaacdaefaah" where index=0 is
  * first occurance and index=10 is the last occureacne of a in this string*/	
	
	public static int first=-1;   //here both are kept negative i.e wrong numbers to check the current first occurence 
	public static int last=-1;     //if we use 0 we'll get error since the first occurance wont b start from 0 
					//we use static as we dont want to alter the values for evry 
					//recursive function called.
	public static void findOcuurance(String str,int indx,char element) {
		
		if(indx==str.length()) {         //base condition
			System.out.println(first);
			System.out.println(last);
			return;
		}
		
		char currentChar=str.charAt(indx);
		if(currentChar==element)
		{
			if(first==-1) {
				first=indx;
			}
			else {
				last=indx;
			}
		}
		findOcuurance(str, indx+1, element);  //recursion condition
	}
	
	public static void main(String args[] ) {
		String str="babaacdaefaab";
		findOcuurance(str, 0,'b'); 
	}
}
  //time complexity = string length=O(n) where n is string length