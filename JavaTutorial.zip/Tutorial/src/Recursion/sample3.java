package Recursion;

public class sample3 {
	/*
	// example -1 Print x^n (with stack height = n)   
	//logic: X*X^(n-1) =X^n    X^(n-1)-->recursion function ; base comdtion- X^0=1 & X=0;  
	
	private static int calPower(int x, int n) {
		if(n==0) {		//base case1
			return 1;   
		}
		if(x==0)		//base case2
		{
			return 0;
		}
		int xPowNm1= calPower(x,n-1);  //work/recursion
		int xPow=x*xPowNm1;
		return xPow;
	}
	public static void main(String args[]) {
		int x=2, n=5;
		int ans=calPower(x, n);
		System.out.println(ans);
	}
	*/
	
	//Print x^n (with stack height = logn)
	/* X^n can be writteen as X^(n/2)*X^(n/2) when n=even
	 * X^n can be writteen as X^(n/2)*X^(n/2)*X when n=odd									Example n=4
	 * 					     X^n						=>1->2^0	alpha=0						  X^4
	 *           X^(n/2)    			  X^(n/2)       =>2->2^1	alpha=1					X^2		     X^2	
	 *    X^(n/4)  		X^(n/4)		X^(n/4)		X^(n/4)	=>4->2^2	alpha=2				X^1		X^1   X^1    X^1
	 *    
	 *    stack value goes down till  
	 *    			 n/2^alpha=1==> n = 2^alpha 
	 *    			==> log base2 n=alpha
	 **/
	private static int calPower(int x, int n) {
		if(n==0) {		//base case1
			return 1;   
		}
		if(x==0)		//base case2
		{
			return 0;
		}
		 //if n is even
		if(n%2==0) {
			return calPower(x, n/2)*calPower(x, n/2);
		}
		else { //if n is odd
			return calPower(x, n/2)*calPower(x, n/2)*x	;
		}
	}
	public static void main(String args[]) {
		int x=2, n=5;
		int ans=calPower(x, n);
		System.out.println(ans);
	}
}
