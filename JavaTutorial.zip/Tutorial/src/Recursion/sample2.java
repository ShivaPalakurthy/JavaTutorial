package Recursion;

public class sample2 {
 
	
	
	/*Print the sum of first n natural numbers.*/
	
	/*
	 * 
	 * 
	  public static void printSum(int i,int n, int sum) {
		if(i == n) {     //Base case
		sum += i;		//use to add final 'n' value to the sum.
		System.out.println(sum);
		return;
		}
		sum += i;
		printSum(i+1,n, sum);   // making Recursion 
		System.out.println(i); // to understand this see video --> it shows how stack deletes the items
		}  					// when base condition is reched and calling goes back then it prints the 'i' value
	public static void main(String args[]) {
		printSum(1,5, 0);
		}  
	 
	 */
	
	
	
	
	 
	/*Print factorial of a number n. */
	//recursion logic--> 1.(n-1)! 2.n.(n-1)!<--returning value 
	/*
	 * 
	 * 
	public static int printFactorial(int n) {
		if(n == 1||n==0) {     //Base case
			return 1;
		} 
		 int fact_Nm1=printFactorial(n-1);  // making Recursion 
		 int fact_n=n*fact_Nm1;
		 return fact_n;
		}
		public static void main(String args[]) {
			int n=5;
		int ans=printFactorial(5);
		System.out.println(ans);
		}
	   
	 */
	
	//Print the fibonacci sequence till nth term.
	public static void printFib(int a, int b, int n) {
		if(n == 0) {  //Base case
			return;
			}
		 int c=a+b;
		 System.out.println(c);
		 printFib(b,c,n-1);  // making Recursion here b-->a; c-->b; ---> becomes
	}
		public static void main(String args[]) {
		  int a=0,b=1;
		  System.out.println(a); //since we know the first two terms lets print them first
		  System.out.println(b);
		  int n=7;
		  printFib(a,b,n-2);
		}
}
