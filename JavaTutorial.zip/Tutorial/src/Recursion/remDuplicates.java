package Recursion;

public class remDuplicates {
		//Remove duplicates in a string.
	//once know about map array
	
	
	
	/* IF THE current character is true in mapping then we dont print that character in newstring
	 * but the cuurent character value is false in the mapping then we'll print the character in new stirng and
	 *  we will update the map[position] to true.
	 *  
	 *  i.e.,   		curr char---> True then new string -we'll not print
	 *  				curr char---> False then we print new char in the new string &
	 *  							we'll update map[pos] value = true*/
	public static boolean[] map =new boolean[26];
	public static void remDupl(String str, int indx, String newstr) {
		if(indx==str.length()) {
			System.out.println(newstr);   //base
			return; 
		}
			
		
		
		char currchar=str.charAt(indx);
		
		if(map[currchar-'a']==true) {  // if we write like this also if(map[currchar-'a']) by default it takes true.
			remDupl(str, indx+1, newstr);  //recursive function
		}else {
			newstr+=currchar;
			map[currchar-'a']=true;
			remDupl(str, indx+1, newstr);
		}
	}
	public static void main(String args[]) {
		String str="abbccdaefeeg";
		remDupl(str, 0,"");
	}
}


//time complexity = string length=O(n) where n is string length