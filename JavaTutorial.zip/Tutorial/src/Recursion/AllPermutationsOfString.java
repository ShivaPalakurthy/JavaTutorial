	package Recursion;

public class AllPermutationsOfString {
 /*
  * Print all the permutations of a string. --> Permutations means all possible combinations of letters
  * 											abc
  * 											 |
  * 				-------------------------------------------------------------
  * 				|			|			|			|			|			|		
  * 			   abc		   acb 		   bac  	   bca		   cab		   cba  -->All permutations of String "abc"
  * 
  * 											n
  * Mathematical formula for Permutations is 	 P  =n!
  * 											  n
  */
	public static void PrintPerm(String str,String Permutation) {
		if(str.length()==0){
			System.out.println(Permutation);
			return;	
		}
		
		for(int i=0;i<str.length();i++) {
			char currChar=str.charAt(i);
			String NewStr=str.substring(0, i)+str.substring(i+1); //"abc"-->bc;"cba"-->ba to make this weused this line
			/*Understanding NewStr concept, 
			 * lets say we have "abc" string and our currChar is "b" here a=0,b=1,c=2-->indx values
			 * in substring the last index or ending index dont get inclued ,
			 * 				i.e., str.substring(0,i) -->(0,1)-->0 if i=1
			 * 										 -->(0,3)-->0,1,2 if i=3
			 * and substring(i+1) gives values starting from i+1 index to the ending of the string
			 * so here str.substring(0,i)-->(0,1)-->0 index values so str.substring(0,i)='a'
			 * 		   str.substring(i+1)-->(2)-->so from 2 index values to end of String so str.substring(i+1)='c'
			 * so NewStr= str.substring(0, i)+str.substring(i+1)='a'+'c'='ac';
			 *  ==> NewStr="ac"; by this we'll eliminate the currChar from the string
			 */
			PrintPerm(NewStr, Permutation+currChar); 
		}
	}
	
	public static void main(String args[]) {
		String str="abc";
		PrintPerm(str, "");
		
	}
}
/* time complexity will be n for first char space, (n-1) for secong char space & (n-2) for third char space & so on
 * so time complexity becomes (n)*(n-1)*(n-2)*(n-3)*....
 * which implies time complexity=O(n!)
 * 
 * Total number of Permutations = n!. 
 * */
