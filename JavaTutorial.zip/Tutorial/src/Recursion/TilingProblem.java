package Recursion;

public class TilingProblem {
  /*
   * Place Tiles Of size 1xm in a floor of size n*m HERE N=4,M=2 
   * 		
   * here 1 n =| and 1 m=--				here tile 1*m=1*2=   -- -- 
   * 	       |                               		        |  |  | 0 		
   *  												    	 -- --
   * 												          0   1
   * floor-(n*m)     
   *    0  1            here we need to place the tile 1*M on the floor (N*M) we can place the tile either 
   *   -- --             horizontally(H) or vertiaclly(V).so the possible ways of placing the tiles on floor are 
   *  |  |  | 0   			 
   *   -- --				1.   		2.  __    __     3.  __    __   4.             5.
	  |	 |  | 1				   [  H  ]    |   | |   |      |   | |   |    [    H    ]    [    H    ] 
	   -- --				   [  H  ]    | V | | V |      | V | | V |      __    __     [    H    ]
	  |	 |  | 2				   [  H  ]     ---   --- 		---   ---     |   | |   |      __    __ 
   *   -- --				   [  H  ]    [    H    ]       ---	  ---     | V | | V |    | V | | V |	
	  |	 |  | 3				     		  [    H    ]      | V | | V |     ---   ---     |   | |   |
	   -- -- 				    				           |   | |   |    [    H    ]     ---   ---
	    (4*2)				   								---   --- 
	 
	 
	 Recursive Approach:
	 for n*m floor we can place the tile in two ways. i.e Vertical & Horizontal.
	 
	 1.Recursive function : if we place a tile vertically,then we should focus on the 
	 remaining tiles as if we place one tile vertically , then by default we have to 
	 place another tile vertically beside the tile. 
	 	
	 						M
	 				   _____________
	 				  |	---  	--- |
	 if we placed it  || V |   | V || <-- then we have to place another tile
	 	vertically	  || V |   | V ||	vertically 
	 		   		  |	---		---	|
	 		   		  |				|
	 		  	  N	  |				|
	 		   		  |	(N-M)		|				
	 		   		  |_____________|
	 	    so after placing one tile vertically, we should focus on 
	 	    placing other tiles. so the total number of ways for the remaining tiles
	 	    will be  (n-m)
	 	    
	2.Recursive funciton: lets assume we have placed a tile horizontally once ,then we 
	have to place tiles in (n-1)*m tiles on the floor
	 						M
	 				   _____________
	 				  |	-----------	|
	    			  | |	m	   ||-->1 
	 		   		  |	------------|
	 		  	  N	  |				|
	 		   		  |	(N-M)		|
	 		   		  |				|	
	 		   		  |				|
	 		   		  |				|
	 		   		  |				|			
	 		   		  |_____________|
	 		   		  
	 		   		  
	 		   		  
	 		   		  
	 		   		  
	 Base Case:
	 		if n=m, then we used to have only two(2) ways to place the tiles.
	 		if n<m, then we used to have only one(1) way to place the tile.i.e
	 				tile can come only in horizantally.
	 				
	 
	 
	 this problem also has huge timecomplexity while doing with recursion so we'll
	 use dynamic programming to have less time complexity.
	 */
	
	public static int placeTiles(int n,int m) {
		if(n==m) {						//base case1
			return 2;
		}
		if (n<m) {					//base case 2 
			return 1;
		}
		
		//for vertical placement
		int verPlacements=placeTiles(n-m, m);
		
		
		//for horizontal Placemnet
		int horPlacements=placeTiles(n-1, m);
		
		return verPlacements+horPlacements;
	}
	public static void main(String args[]) {
		int n=4,m=2;
		placeTiles(n, m);
		int Totalplaces=placeTiles(n, m);
		System.out.println(Totalplaces);
	}
}

