package Recursion;
import java.util.HashSet;

public class UniqueSubSequences {
	//also try coding on longestsubsequence.
  /*Print all unique subsequences of a string.
   * we use hashset - this data structure will take all the values &hold unique values of the set	 
   */
	
	public static void SubSeq(String str,int indx,String newString, HashSet<String> Set ) {
		if(indx==str.length()) {
			if(Set.contains(newString)) {
				return;
			}
			else {
				System.out.println(newString);
				Set.add(newString);
				return;
			}
			}
		
		
		char currchar=str.charAt(indx);
	
		
		
		
		//to be in subsequence
		SubSeq(str, indx+1, newString+currchar,Set);
		
		
		//or  not to be
		SubSeq(str, indx+1, newString,Set);
	}
	public static void main(String args[]) {
			String str="aaa";
			HashSet<String> set = new HashSet<>();
			SubSeq(str, 0,"",set);
	}
	
}
