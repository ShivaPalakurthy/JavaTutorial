package Recursion;

public class MovingELements {
 //Move all ‘x’ to the end of the string.for "abcdefxghxixjxxxk" 
	/* here we take indx to know current character value and count is taken to track how many no.of x and
	by newString we'll make another string where x values are moved to the end */
	private static void MoveAllX(String str, int indx,int count, String newString) {
		if(indx==str.length())
		{ 	
			for(int i=0;i<count;i++)
			{
				newString+='x';
			}
			System.out.println(newString);
			return;
		}
		
		char currChar=str.charAt(indx);
		if(currChar=='x') {
			count++;
			MoveAllX(str, indx+1, count, newString);
		} else {
			newString += currChar;
			MoveAllX(str, indx+1, count, newString);
		}
	}
	public static void main(String args[]) {
		String str="abcdefxghxixjxxxk"; 
		MoveAllX(str, 0, 0,"");
	}
}
/*Time complexity is O(n+count) maximum no.of count can be n so Time Complexity will be O(n+n)=O(2n) 
usually in time compllexity we ignore assymnotic expressions so we neglect constants
so time complexity is O(n)*/
