package Recursion;

public class SortingArray {
   /*Check if an array is sorted (strictly increasing). 
    * so if the array is 12345 it gives true if the array is 12234 it gives false
    */
/*	public static boolean isSorted(int arr[],int indx) {
		
		if(indx==arr.length-1) //base condition
		{
			return true;
		} 
		
		
		if(arr[indx]<arr[indx+1]) {
			//arr sorted till now
			return isSorted(arr, indx+1); //recursion we check till the current level 
					//that whether it is sorted or not in next recursion we'll be found by
					// * the next redcursion steps so we'll use return for this recursion. 
		} else {
			return false;
		}
	}
	public static void main(String args[]) {
		int arr[]= {1,3,4};
		 System.out.println(isSorted(arr, 0));  
	} */

  /*Another way to solve */
	public static boolean isSorted(int arr[],int indx) {
		
		if(indx==arr.length-1) //base condition
		{
			return true;
		} 
		
		
		if(arr[indx]>=arr[indx+1]) {
			//arr is unsorted
			return false; //recursion
		}  
		return isSorted(arr, indx+1);
		}

	public static void main(String args[]) {
		int arr[]= {1,3,4,7};
		 System.out.println(isSorted(arr, 0));  
	}

}
//time complexity = string length=O(n) where n is string length	 