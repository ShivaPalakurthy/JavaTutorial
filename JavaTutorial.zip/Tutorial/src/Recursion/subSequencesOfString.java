package Recursion;

public class subSequencesOfString {
 //Impr program	
	
	/*Print all unique subsequences of a string.
	 * 
	 * Subsequence=> Every character has a choice of coming or not coming into the subsequence string but if it comes
	 * 				it should come by the same order which follows is the main string e.g: 
	 * 
	 * 							abc=	   a(if a wants to come in subseq)	    _(if a dosn't want to come in subseq)
	 * 
	 * if b wants to come-->	  ab		       a_					_b			    	_ _
	 * 	 
	 * if c wants to come-->abc		 ab_    a_c	 	     a_ _     _ bc		_b_		_ _c		_ _ _ ==> this final 
	 * strings that come after all the choices are subsequences of given string
	 * so, the subseq of abc is => abc,ab,ac,a,bc,b,c ==>abc,ab,ac,bc,a,b,c
	 *  */
	public static void SubSeq(String str,int indx,String newString) {
		if(indx==str.length()) {
			System.out.println(newString);
			return;
			}
		
		
		char currchar=str.charAt(indx);
	
		
		
		
		//to be in subsequence
		SubSeq(str, indx+1, newString+currchar);
		
		
		//or  not to be
		SubSeq(str, indx+1, newString);
	}
	public static void main(String args[]) {
			String str="abc";
			SubSeq(str, 0,"");
	}
	
}


/* Time complexity
 *  Every time whenever a char chose to come or not come in substring there we be function called for each instance
 *  eg for above case i.e "abc"
 *  		                 [abc]
 *  	        [a]		                      [_]
 *      [ab]          [a_]		    [_b]        	[_ _]
 * [abc]   [ab_] [a_c]  [a_ _]  [_bc]  [_b_]  [_ _ c]  [_ _ _]
 * total subequences = 2^n=here 2^3=8 subsequences
 * 
 * last level nodes=2^n=2^(n-1) *2
 * second last level=2^n-1
 *     -			=2^n-2
 *     -			=2^n-3        these are function calls so when we do G.progression for these values 
 *     -			   -						g.p= a(r^n-1)/(r-1)=1(2^(n+1)-1)/(2-1)=2^(n+1) -1
 *     -			   -					2^(n+1) -1 =>	this is the time complexity of the prgrm 
 *     - 			   1			when we talk about asympnotic notations then time complexity becomes O(2^n)
 * 
 *  */ 
