package Recursion;

public class sample1 {
/*Recursion- A function which calls itself i.e f(x)=x^2 then f(f(x)) is called recursion
 * RECURSION- here outer function takes steps while the inner function will do the rest of the work
 * in other way, 
 * 			lets say , in normal case main function will call another function and that function will
 * 			give return value to main case.
 * 			But, In Recursion case, this another function is called recursion function and when the main 
 * 			function calls the recursive function then the recursive function calls itself again and again 
 * 			till certain condition is attained.Here that certain condition is called BASE conditon. When base 
 * 			condition is attained we'll start coming back from the calls i.e the recursive functions will start
 * 			returning values to its previous recursive function till first recursive function is attained, then 
 * 			the recursive function will return the value to the main function.
 * Recursion to understand refer video and goto google
 * */
	/*example to print numbers from 5 to 1 using recursion method */
	
	public static void printNumb(int n) {
		if(n==0) {			/*Base COndition/value */
			return;
		}
		System.out.println(n);
		printNumb(n-1);			/* making Recursion */
	}
	
	
	public static void printNumbers(int n) {
		if(n == 6) {
		return;
		}
		System.out.println(n);
		printNumbers(n+1);
		}
	
	public static void main(String args[]) {
		int n=5;
		printNumb(n);
		System.out.println("Print numbers from 1 to 5.");
		int m=1;
		printNumbers(m);
	}
	
}
/* when ever recursion happens function calls will be stored in the form of STACKS. when same function is called 
 * multiple times it'll be stored in the form of stacks hence, Recursion takes huge memory space as for every 
 * function it calls there will be another stack memory taken. SO, when recursion goes for infinite times or 
 * when base condition is not declared, then at one point our memory gets fulled and we encounter 
 * STACK OVER FLOW problem */
