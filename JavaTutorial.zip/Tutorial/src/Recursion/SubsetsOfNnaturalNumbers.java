package Recursion;
import java.util.*;

public class SubsetsOfNnaturalNumbers {
   /*
    * Print all the subsets of first N natural Numbers
    * n=3
    * In subset everyelement has a choice of choosing whether they want to come in subset
    * or not.
    * 							(1,2,3)
    * 
    * 				(1,2,3) (1,2) (1,3)	(2,3) (1) (2) (3) (empty subset)
    * 
    *   
    *   
    *   
    *   
    *   
    *   Time complexity of this problem is O(2^n)
    * */
	
	 public static void printSubset(ArrayList<Integer> subset ) {
		 for(int i=0;i<subset.size();i++) {
			 System.out.print(subset.get(i)+" ");
		 }System.out.println();
	}
	
	 public static void findSubsets(int n, ArrayList<Integer> subset) {
		
		 if(n==0) {
			 System.out.println(subset);
			 return;
		 }	
		  //if they want to add to the subsets
		  subset.add(n);
		  findSubsets(n-1, subset);
		  
		  
		  //if they dont want to add in the subsets
		  subset.remove(subset.size()-1);
		  findSubsets(n-1, subset);
	}
	 public static void main(String args[]) {
		int n=3;
		ArrayList<Integer> subset=new ArrayList<>();
		findSubsets(n, subset);
		
	}
}
	/*						3
	 * 				 
	 * 				3				[]  -->3 want to come and not want to come
	 * 		
	 *       32         3		[]2    [] --> 2 want to come nd not want to come
	 *       
	 *   321	32    31   3   21  2  1   [] --> 1 want to come nd not want to come
	 */
