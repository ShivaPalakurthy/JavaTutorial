package Recursion;

public class TowerOfHanoi {
	public static void toweOfHanoi(int n, String src,String helper,String dest) {
		if(n==1) {
			System.out.println("transfer disk "+ n+ " from "+src +" to " + dest); //base case
			return;
		}
		
		//recursion part down--
		toweOfHanoi (n-1,src,dest,helper);/*1st Step -> transferring n-1 disks from source to helper so we are using
											destination as helper and helper as destination */ 
		System.out.println("transfer disk "+ n+ " from "+src +" to " + dest); 
				/* 2nd Step -> transfering the remaining disk in src to destination */
		toweOfHanoi(n-1, helper, src, dest); /*3rd step ->the n-1 disks which are in the helper should be 
					transfered to destination by keeping source as a helper in this case */
	}
	
	
	public static void main(String args[]) {
		int n=3;
		toweOfHanoi(n,"S","H","D");
	}
}
/* Time Complexity of hanoi is O(2^n  -1) ~= O(2^n ) ==> it came when you see recursion function closely 
 * we'll get  to know  T(n)=2T(n-1)+1 =>substitute sub values==> T(n)=2(2T(n-2)+)+1=4(i.e 2^2)T(n-2)+2+1
 * 					T(n-1)=2T(n-2)+1				sub T(n-2) gives =42T(n-3)+1)+2+1= 8(i.e 2^3)T(n-3)+4+2+1
 * 					T(n-2)=2T(n-3)+1		  here n-1,n-2,n-3 can be treated as n-x and n=1 when n-x value becomes 1
 * 					T(n-3)=2T(n-4)+1                so n-x=1 which implies x=n-1
 * 						.						
 * 						.			so T(n)=2^(n-1)T(1)+2^(n-2)+2^(n-3)+....which make T(n)=2^(n-1)+2^(n-1)->got by 
 * 						T(1)=1					masters theorem from maths and from this we get  T(n)=(2^n)
 * 											from this we can say time complexity is O(2^n)
 * */		
 