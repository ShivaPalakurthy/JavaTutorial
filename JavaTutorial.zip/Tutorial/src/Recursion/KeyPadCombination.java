package Recursion;

public class KeyPadCombination {
   /*Print nokia mobile  keypad combination
    * ( 0 -> .;
1 -> abc
2 -> def
3 -> ghi
4 -> jkl
5 -> mno
6 -> pqrs
7 -> tu
8 -> vwx
9 -> yz
)
    * 
    */
	
	/*Explanation: This is similar to the subsequences but there the choices were two but here the choices
	 * are varying eg. 1-->abc; 6-->pqrs
	 * 
	 * for example, if we type "23" we need to check the possible outcomes
	 *      here 2-->def;   3-->ghi so for 
	 *       "23"-->  		--dg
	 *       			d-- --dh
	 *       				--di
	 *       				--eg
	 *       			e-- --eh
	 *       				--ei
	 *       				--fg
	 *       			f-- --fh
	 *       				--fi
	 *      
	 * */
	public static String[] Keypad = {".","abc","def","ghi","jkl","mno","pqrs","tu","vwx","yz"};
	
	public static void PrintComb(String str,int indx,String Combinations) {
		
		if(indx==str.length()) {
			System.out.println(Combinations);
			return;
		}
		
		char currChar= str.charAt(indx);
		String mapping= Keypad[currChar-'0'];
		
		for(int i=0;i<mapping.length();i++) {
			PrintComb(str, indx+1, Combinations+mapping.charAt(i));
		}
	}
	
	public static void main(String args[]) {
		String str="23";
		PrintComb(str, 0,"");
	}
}
//Focus on mapping and HashSet
 
/* Time complexity 
 * 0 -> .
 * 1 -> abc
 *2 -> def
*3 -> ghi
*4 -> jkl
*5 -> mno
*6 -> pqrs
*7 -> tu
*8 -> vwx
*9 -> yz
   here maximum choices for a single level can be 4 since  only "6" has large vale i.e 6-->pqrs=4; 
   so time complexity depends on the total input lenght "n" and 4 max choices
   		so time complexity == O(4^n)
   
 */