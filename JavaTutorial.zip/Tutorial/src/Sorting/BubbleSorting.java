	package Sorting;

	/*Rules for Studying Sorting
	 * 1.BubbleSort
	 * 2.SelectionSort
	 * 3.InsertionSort
	 * Later go and study Backtracking concepts and then start studying
	 * 4.QuickSort
	 * 5.MergeSort
	 * */
public class BubbleSorting {
	// we do n-1 paired comparisions in bubble sort
	
	//sorting the array elements in ascending order
	
		public static void printArray(int arr[]) {
			for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		}
		
		public static void main(String args[]) {
			int arr[]= {7,8,3,1,2};
			//bubble sort
			for(int i=0;i<arr.length-1;i++) //to count n-1 iterations
			{		
				for(int j=0;j<arr.length-i-1;j++)  //i is the counter -->this will avoid counting sorted elements in last positions
					if(arr[j]>arr[j+1]) {  //index position of array  elements is defined by j
						//swap
						int temp=arr[j];
						arr[j]=arr[j+1];
						arr[j+1]=temp;
					}
			}
			 printArray(arr);
		}
}


/* time complexity of outer loop is n-1; inner loop is n-i-1; 
 * in asynotic  notation i.e big(O) we neglect constants 
 * so total lines that runned becomes n^2 times */

// time complexity =O(n^2)  --> for sorting this is not the ideal time complexity


/* if we want to sort Ascending order of a nummber in bubble sort then bubble sort will start comparing two adjacent
 * numbers adn starts pushing the first highest value to last postion (n-1 place) and then they start comparing and
 * finds the second highest value and they push this value to the second last position(n-2 place)and process goes on
 *  e.g: given number 7,8,3,1,2
 *  1 loop run--->    7,8❌3,8❌1,8❌2,8=> 7,3,1,2,8  -->1st longest elenment to the end;  ❌-- swap between adjacent number 
 *  																				after comparing
 *  				here n❌m is comparing and swapping the element if the vlaue is greater
 *  2 loop run---> 3,7❌1,7❌2,7,8==>3,1,2,7,8
 *  
 * 3 loop run---> 1,3❌2,3,7,8 =>1,2,3,7,8
 * 4(n-1)  loop run ---> 1,2,3,7,8 						-->(n-1)pair wise comparision has beeen performed
 * 
 * from the end of each loop we start ignoring /counting or considering the last element to the next subsequent
 * loop because we'll already get the highest value in that previous loop so there is no necessity in doing it in the 
 * next loop
 * */
