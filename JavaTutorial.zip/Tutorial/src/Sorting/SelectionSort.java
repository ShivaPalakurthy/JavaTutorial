 package Sorting;

import java.util.*;

public class SelectionSort {
	
	public static void printArray(int arr[]) {
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+ " ");
	}
	public static void main(String args[]) {
		 int arr[]= {9,8,6,7,2,3,4};
		 //Selection sort
		 for(int i=0;i<arr.length-1;i++) {     
			int smallest=i;
			for(int j=i+1;j<arr.length;j++)    
			 {
				if(arr[smallest]>arr[j]) {
					smallest=j;
					} 
		 }
		 int temp=arr[smallest];
		 arr[smallest]=arr[i];
		 arr[i]=temp;
		 } printArray(arr);
	}
}


/* for every situation outer loop is going for "n" times and for the first time
 * the inner loop has run for n-1 times, for second time inner loop has run for n-2 times
 * and it goes on like n-3,n-4,so on.  when we look at the inner loops 
 * it resembles an Arthimetic Progression series (AP) in which common difference (d) is 1 
 * and the sum becomes n*(n+1)/2 from this we'll get n^2 as time complexity
 */

 // SO time complexity of Selection sorting is n^2

/*
 * Selection Sort is similar to Bubble Sort but the difference is in bubble sort well take the largest elemnt
 * and push it to the end of the array wheere as in Selection sort we'll take smallest element of the array  and push
 * it to the first position of array
 * and the other difference is in bubblesort in one loop we used to swap all the elements pairwise  where as in 
 * Selectionsort we'll run an entire loop and dont do any swap in between while runing that loop we'll just compare
 * the element and find out the element and in end of the loop only we swap it once.
 * i.e In selection sort we do, 1 swap per one iteration(loop)
 * 	 	 					0	1	2	3	4 -->Indexes of an Array
 * 	ex-						7   8   3   1   2
 * in 1st loop we start from i=0,  
 * it assumes arr[0] element as a smallest
 * so the smallest =0[7] 
 * from0[7] comparing of next array element starts --> in code this part (int j=i+1;)
 * so does 1[8]<0[7]-->No, in this case we don't do anything goes with next on
 * 		   2[3]<0[7]-->Yes, so we make 3 as the smallest
 * so the smallest =2[3]
 * from 2[3] comparing of next array element starts 
 *   	   3[1]<2[3]-->Yes, so we make 1 as the smallest
 * so the smallest =3[1]
 * from 2[3] comparing of next array element starts
 * 		   4[2]<3[1]-->No, so 3[1] will be the smallest at the end of the loop
 * so in end this smallest value is swapped with the first postion value
 * i.e., 0[7] is swapped with 3[1]
 * so the final array after the first loop is    --> 1,8,3,7,2
 * 
 * 
 * 
 * In 2nd loop we starts from i=1 since we placed the first smallest element in i=0 in the first loop
 *    new array after first loop is 
 *    
 *    								1,  8,  3,  7,  2
 *  Smallest=1[8]
 *  		2[3]<1[8]-->Yes, so we make 3 as the smallest
 *   so the smallest =2[3]
 *   		3[7]<2[3]-->No, so 2[3] is smallest
 *   		4[2]<2[3]-->Yes,so 4[2] will be the smallest at the end of the loop
 *   so in end this smallest value is swapped with the first Second  postion value 
 *    i.e., 1[8] is swapped with 4[2]
 * so the final array after the Second loop is    --> 1,2,3,7,8
 * 
 * Similarly we do it for 3rd loop, 4th loops
 * */
 