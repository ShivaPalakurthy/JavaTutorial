package Sorting;

public class MergeSort {
	/* Time complexity of Merge Sort will be nlogn
	 * 
	 * 
	 * for conquer-->O(n) & Divide-->O(log n)
	 * Merge sort is base on Divide & Conquer Technique 
	 * 			Dividing the array   
	 * 
	 * si--> Starting Index
	 * ei-->Ending Index
	 * Mid--> Middle Index
	 * 								si	   mid	 ei	
	 * 								 [6,3,9,5,2,8]		<--si=0;ei=5-->mid=2
	 * 									Dividing
	 * 
	 * 					si(0)	   mid-->ei(2)			mid+1		ei
	 *	 			 mid=1-->[6,3,9]							[5,2,8]
	 *
	 *			si(0) 	ei(1)			si=ei=2
	 * 				[6,3]				[9]			[5,2]				[8]				^
	 * 																					|
	 * 																				Divide
	 * 		[6]				[3]			[9]		[5]			[2]			[8]	  //Base Case
	 * 
	 * 
	 * 									Conquering
	 * 				[3,6]				[9]			[2,5]				[8]
	 * 	
	 * 						[3,6,9]							[2,5,8]	
	 * 
	 * 								  [2,3,5,6,8,9]
	 * 
	 * 
	 * Procedure: At every step we'll pass Starting Index and Ending Index & we'll
	 * derive Mid Index .
	 * To conquer we'll take new array and pass the individual sorted values for e.g 6,3 are 
	 * passed to get[3,6] later we'll copy values of this array to the original array.
	 */	
	
	public static void conquer(int arr[],int si,int mid, int ei) {
		int merger[]=new int[ei-si+1]; /*createing merger array, we've added +1 as ei is 
				   always less the array less (ei== arr.length-1) */
		
		int indx1=si;
		int indx2=mid+1;
		int x=0; //--> Tracks merger array
		while(indx1<=mid && indx2<=ei) {
			if(arr[indx1]<=arr[indx2]) {
				merger[x++]=arr[indx1++];/*or-> merger[x++]=arr[indx1];
												x++ ;indx++;  */
				}  
			else {
				merger[x++]= arr[indx2++];
			}
		}
		//when two arrays are sorted but 1st array still has elements to copy in merger array
		while(indx1<=mid ) {
			merger[x++]=arr[indx1++]; 
			}  
		//when two arrays are sorted but 2st array still has elements to copy in merger array
		
		while(indx2<=ei) {
			merger[x++]=arr[indx2++];
		}
		
		//Copying elements from merger array to the original array
		for(int i=0,j=si;i<merger.length;i++,j++ ) {
			arr[j]=merger[i];
			 
		}
	}
	public static void divide(int arr[],int si,int ei) {
		
			if(si>=ei) {
				return;
			}
		
		int mid=si+(ei-si)/2;  //if we use this (si+ei)/2 then sometimes we'll get 
								//space complexity issue.
		divide(arr, si, mid);
		divide(arr, mid+1, ei);
		conquer(arr,si,mid,ei);
	}
	
	public static void main(String args[]) {
		int arr[]= {6,3,9,5,2,8};
		int n=arr.length;
		divide(arr, 0, n-1);
		
		//print
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+"");
			
		}
		System.out.println();
	}
}
