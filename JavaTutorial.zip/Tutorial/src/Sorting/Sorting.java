package Sorting;

public class Sorting {
 public static void main(String args[]) {
	 int arr[]= {3,8,2,1,5,7,9,6};
	 for(int i=0;i<arr.length;i++) {
		 for (int j=i+1;j<arr.length;j++ )
		 {
			 int temp=0;
			 if(arr[j]<arr[i])  //change to arrange the order in ascending or descending order
			 {
				 temp=arr[j];
				 arr[j]=arr[i];
				 arr[i]=temp;
			 }
		 }
	 }
	 for(int i=0;i<arr.length;i++)
		 System.out.println(arr[i]);
 }
}
