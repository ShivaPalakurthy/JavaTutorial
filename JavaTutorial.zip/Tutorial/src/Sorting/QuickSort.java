package Sorting;

public class QuickSort {
 /*Pivot--> its a centre of point where things revolve, in quicksort also there will be
  * such point where we'll implement quicksort around it. That point is called pivot
  *Partition--> Process of suffliing elements around the pivot to sort them is called
  *				as partition.
  *Ways to choose Pivot: 1.Pick Random ELement
  *						 2.Take median of all elements and make them pivot.
  *						 3.MAking first element of an array as pivot
  *						 4.Making Last element of an array as pivot
  *Traditionally we'll make last element as pivot for QuickSort
  *
  *Process of Quick sort:
  *	say array is [6,3,9,5,2,8]----------------------> [2,3,5,6,8,9]
  * we'll move all the elements smaller than pivot to forward and higher elements 
  * 																	backwards		
  *									8--> As a pivot
  *
  *				[6,3,5,2]-->Smaller						[9]   -->Larger
  *  
  *  				 2--> As a pivot and we'll do recursive fucntion
  * 
  *  	[]						[6,3,5]-->Larger
  *  				
  *  								5-->As pivot
  *  				
  *  					[3]-->smaller			[6]-->larger
  *  
  *  
  *  In this way we have divided array , so now when we start to look from left to right
  *  we'll get 2 first then 3, then 5,then 6, then 8, then 9.
  *   		i.e [2,3,5,6,8,9]
  * 
  */	
	public static int partition(int arr[],int low , int high) {
		int pivot=arr[high];  // taking last array element as high.
		int i=low-1;  /*tracks the no.positions that has to be empty from the start so that
					the no.of elements that are smaller than pivots gets in them */
	   
		for(int j=low;j<high;j++) { 		//traversing the array
			if(arr[j]<pivot) {
				i++; 
				//swap
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				
			}
		}
		//To store the pivot value
		i++; //creating space to store the pivot
		int temp=arr[i];
		arr[i]=pivot;
		arr[high]=temp; 
		return i; // after partition out pivot index will be at i
		
	}
	
	public static void quickSort(int arr[], int low,int high) {
		if(low<high) {
			int pivindx=partition(arr,low,high);  //pivindx-->pivot index
			 //recursive call for sorting elements less than pivot
			quickSort(arr, low, pivindx-1);
			//recursive call for sorting elements greater than pivot.
			quickSort(arr, pivindx+1 , high);
			
			
		}
	}
	
	public static void main(String args[]) {
		int arr[]= {6,3,9,5,2,8};
		 int n= arr.length;
		 quickSort(arr,0,n-1);
		 
		 for(int i=0;i<n;i++) {
		 System.out.print(arr[i]+"");
		 }
		 System.out.println();
	}
}
/* 						IMP Topic
 * Time complexity of QuickSOrt
 *  	Worst case :O(n^2)
 *     Average case:O(nlogn)
 *     
 *     In merge sort we'll get worst case as O(nlogn) -->this is better than n^2 but,
 *     in certain cases Quick Sort is prefered 
 *     
 *     when we talk about average case of Quick sort we'll get O(nlogn) but worst case
 *     was n^2. WOrst case occurs in Quick Sort when pivot is either smallest or the
 *     largest element & this happens when the array is sorted. Even then in some cases
 *     we'll use quick sort over merge sort because we wont create another array and 
 *     take additional memory like merge sort.
 *     
 *     We should take merge sort when we have extra memory and when we are capable
 *     of creating extra array and worst case timecomplexity be nlogn.
 *     where as we'll use Quick sort when we have average cases and we have to use
 *     memory efficiently 
 */
