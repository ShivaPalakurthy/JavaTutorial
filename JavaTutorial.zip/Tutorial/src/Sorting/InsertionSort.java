package Sorting;

public class InsertionSort {
	public static void printArray(int arr[]) {
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+ " ");
	}
	
	
	// time complexity is n^2
public static void main(String args[]) {
	int arr[]= {7,2,8,6,3,1};
	for(int i=1;i<arr.length;i++)
	{
		int current=arr[i];
		int j=i-1;
		while(j>=0 && current<arr[j])  //-->j>=0 to avoid array inbounds exception & j is used to track sorted part	
		{
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=current;
	}
	printArray(arr);
}
}
/*In Insertion sort we'll divide the array into two parts 1-Sorted part ;2-Unsorted Part
 * we'll do sorting by taking every eleemnt from the unsorted path and then placing it in the sorted path at its exact
 * postion
 * 
 * ex.given array is        7,8,3,1,2
 * let's take 7 as sorted and remaining elements as unsorted elements part
 * 					   sorted  | unsorted
 * 							7  |  8  3  1  2  
 * 							   |
 * 1st we'll take an element from unsorted array and we start comparing it with the sorted elements and we'll
 * push back the elements of sorted array when the unsorted element value is less than the sorted element value and 
 * place the unsorted element in the sorted array when unsorted element value is greater than the sorted element value.
 * so,
 *In 1st loop we'll sort 8
 * 						sorted  | unsorted
 * 						  7  8  |  3  1  2 
 * 								|
 * In 2nd loop we'll sort 3
 * 						sorted  | unsorted
 * 					    3  7  8 |  1  2    -->3 PUSHES 7,8 BACKWARDS
 * 								| 
 * In 3rd loop we'll sort 1
 *  					sorted  | unsorted
 *					 1  3  7  8 |  2 	   -->1 PUSHES 3,7,8 BACKWARDS
 * 								|
 * In 4rd loop we'll sort 2
 *   					sorted  | unsorted
 *   			  1  2  3  7  8 |  		   -->2 PUSHES 3,7,8 BACKWARDS AND GETS SETELLED BEFORE 1
 *    							|
 */
 