package OopsByApniKasksha;
 /*
  * Inheritence --> Passing data from one generation to other generation i.e
  * 			passing data from one class(parent/super/base) to other class(child/sub)
  * Using Inheritence, reusability increases.
  * 
  */

/*
 class Shape{
	 String color;
	  
 } 
 class Triangle extends Shape{
	 	
 }

public class Inheritence {
     public static void main(String args[]) {
		Triangle t1=new Triangle();
		t1.color="red";
	}
}  */

/* There are 4 types of Inheritence 
 * 			1.Single level Inheritence.-->One base class to one derived calss
 * 			2.Multilevel Inheritence
 *          3.Hierarchial Inheritence--> One base class to multiple derived class
 *          4.Hybrid Inheritence--> we see above 1,2,3 types of inheritence in one placce
 *          5.Multiple Inheritence--> Java Doesn't support multiple Inheritence using
 *          						classes so we'll use Interface to acheive multiple
 *          						Inheritence. 
 */
 class Shape{
	 public void area() {
		System.out.println("dispalys area");
	}
 }
 
 class Triangle extends Shape{
	 public void area(int l,int h) {
		System.out.println(1/2*l*h);
	}
 }
 //multilevel Inheritence
 class EquilateralTriangle extends Triangle{
	 public void area(int l,int h) {
			System.out.println(1/2*l*h);		
	}
 }
 
 //Heirarcheal Inheritance
 class Circle extends Shape{ //Shape-> base class; Circle & Triangle-> derived class
	 public void area(int r) {
			System.out.println((3.4)*r*r);
		}
 }
public class Inheritence {
    public static void main(String args[]) {
		Triangle t1=new Triangle();
		t1.area(4,3);
	}
}  
/* Packages in java have relative code.
 * 				1.Build-in / Pre-defined Packages.
 * 				2.User Defined Packages.
 * 
 */
  