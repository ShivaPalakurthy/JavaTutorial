package OopsByApniKasksha;
class Pen{
	String color;   //-->data
	String Type; //ballpoint or gel
	public void write() {  //-->member or function
		System.out.println("Write Something ");
	}
	
	public void PrintColor() {
		System.out.println(this.color); /*this--> In any method, this keyword tells
		the scope which object has called / which object is trying to access it   */
	}

}
class Student{
	String name;
	int age;
	
	public void PrintInfo() {
		System.out.println(this.name);
		System.out.println(this.age);
	}
	Student(){   //default constructor
		System.out.println("default constructor is called.");
	}
	
 
}

   class Car{
	   String company;
	   int modelNo;
	   
	   Car(String carManufacturer,int modelNo){  //parameturiesed Constructor
		   this.company=carManufacturer; /*this.company-->Object name;
		   									carManufacturer-->Parameter of constructor*/
		   																
		   this.modelNo=modelNo;
	   }
	   
	   public void CarInfo() {
		   System.out.println(this.company);
		   System.out.println(this.modelNo);
	   }
	   
   }
   
   //example for copy constructor
   
   class Bike{
	   String name;
	   int number;
	   
	   public void BikeInfo() {
		   System.out.println(this.name);
		   System.out.println(this.number);
	   }
	   Bike(Bike b2){ //copy constructor
		   this.name=b2.name;
		   this.number=b2.number;
	   }
	   Bike(){} //You have to create Non-parametureised constructor since you used copy constructor
   }
public class Basic {
    public static void main(String args[]) {
		Pen P1=new Pen();//-->  creating object of a class
		P1.color="Blue";
		P1.Type="ballPoint";
		P1.write();
		
		
		System.out.println(P1.color +"  "+ P1.Type);
		
		Pen P2=new Pen();
		P2.color="Gel";
		P1.PrintColor();
		P2.PrintColor();
		
		Student s1=new Student();
		s1.name="Adapt.Improvise.Overcome.";
		s1.age=23;
		s1.PrintInfo();
		//For Parameteurised Constructor
		Car C1=new Car("MercedesBenz",2913);
		C1.CarInfo();
		
		
		
		//For CopyConstructor
		Bike b1=new Bike();
		b1.name="SHIVA";
		b1.number=19;
		
		Bike b2=new Bike(b1);
		b2.BikeInfo();
		
		

	}
}
/*
 * Whenever we use "new" keyword, in heap memory there will be a space allocated.
 * here Student() & Pen() are the special type of functions known as constructors.
 * In java, constructor work is to construct Java's objects.
 * Properties of Constructor:
 * 		1.COnstructor of an object or Constructor of a class has the same name as the
 * 		class name.
 * 		2.Constructors are methods only but they don't return any value.
 * 		3.For One object, constructor can be called only once.
 * There are 3 types of constructors 
 * 				1.Non-Parameteurised Constructors -->COnstructors who doesn't have 
 * parameters.When we see StudenT Class & Pen class we didn't created default class in
 * pen class even then the code is executed.Reason--> Actually in java, when we don't
 * create any non parameturesied constructor, then java bydefault will create the
 * constructor.
 * 				2.Parameturised Constructors-->We'll pass the parameters and then we'll 
 * assign these parameters to the object.
 * 				3.Copy Constructors-->copying one object into other object.
 * 
 * In Java Constructors are destroyed by Destructors automatically with the the help of
 * garbage collection.so we won't write destructors in java as they have garbage 
 * collectors.  	
 * */
