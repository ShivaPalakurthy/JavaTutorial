package OopsByApniKasksha;
      /*
       * Polymorphism--> Poly means Many; Morphism means Forms.
       * Polymorphism is of two type:
       *  		1.Function overloading/ Compile time Polymorphism
       *  		2.Function Overriding /Run time Polymorphism. 
       *  we'll use run time polymorphism in inheritence.
       *  
       *  
       *  1.Function overloading/ Compile time Polymorphism--> we create different
       *  functions but they all have same name.
       */

 class Student1{
	 String name;
	 int age;
	 public void printInfo(String name) {
		System.out.println(name);
	}
	 public void printInfo(int age) {
		 System.out.println(age);
	 }
	 public void printInfo(String name,int age) {  //case 3
		System.out.println(name+" "+age);
	}
 }
public class FunctionOverloading {  
	public static void main(String args[]) {
		Student1 s1=new Student1();
		s1.name="Shiva";
		s1.age=22;
		
		//Function Overloading/Compile Time Polymorphism
		s1.printInfo(s1.age);
		s1.printInfo(s1.name);
		s1.printInfo(s1.name,s1.age);
		
	}
	
	
   /*
    * Rule for function overloading
    * 		Either return type should be different or there parameters should
    * 	    be different if they have same return type or the number of arguments 
    *		 should be different (ex. case 3).
    */
}
