package OopsByApniKasksha;
/*
 * Interfaces Properties:
 * 1.All the fields in interfaces are public, static and final by default.
   2.All methods are public & abstract by default.
   3.A class that implements an interface must implement all the methods declared
    in the interface.
   4.Interfaces support the functionality of multiple inheritance.


mULTIPLE iheritence can be achieved by using Interface
 */
interface Animals{
	int eyes=2; //--> this value can't be change in horose clss or in main class as they 
				// will be static,final,public by default
	  void walk(); //public & abstract by default.
	/* we'll get errors as
	 * Interfaces cannot have constructors
	 * Animals(){
		
	} */
	/*we'll get errors as Interfaces doesn't allow non-abstract methods.
	 void eat() {
		 
	 } */
}

class Horses implements Animals{
	//we have to implement walk() function in hOrses as we have just defined it in Interface.
	public void walk(){  /*we have to write public because in classes by default access
							modifier will be default but we need public */
		System.out.println("walks on 4legs");
	}
}
public class Interfaces {
	public static void main(String args[]) {
		Horses horses =new Horses();
		horses.walk();
	}
}
