package OopsByApniKasksha;

interface Animalss{
	void walk();
}
interface Herbivores{
	
}
class animal1{
	void run() {
		System.out.println("Runns faster than walking speed");
	}
}
class Rabbit extends animal1 implements Animalss,Herbivores{ //extends keyword must come right after child class it cannot come after implements class
	public void walk() {
		System.out.println("Walks on 4 legs");
	}
}
public class MultipleInheriTance {
		public static void main(String args[]) {
			Rabbit rabbit=new Rabbit();
			rabbit.walk();
			rabbit.run();
		}
}

//A child class can extend from one base class & can also implement any number of implements