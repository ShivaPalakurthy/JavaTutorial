package OopsByApniKasksha;

/*
 * Data hiding is the process of protecting members of class from unintended changes
 * whereas,abstraction is hiding the implementation details and showing only important/
 * useful parts to the user.
 * 
 * Abstraction can be implemented in two ways.
 * 			1.By creating Abstract methods/classes.
 * 			2.By using Interfaces.
 * 
 * Properties of an Abstract Class
	1.An abstract class must be declared with an abstract keyword.
	2.It can have abstract and non-abstract methods.
	3.It cannot be instantiated.
	4.It can have constructors and static methods also.
	5.It can have final methods which will force the subclass not to change
	the body of the method.
Abstraction classes cannot be intantiated ,but they can be subclassed.i,e you cannot
initiated abstract clasess directly but you can initiate withe the help of subclases

Interfaces have Pure Abstraction. Ex. in animal class eat function is non abstract metho
even though it is in abstract class. eat fuction  got inherited to horse and chicken
class. to avoid this we'll use Interfaces to have pure Abstraction.
 */
 abstract class Animal{
	abstract public void walk(); /*Abstract methods do not specify a bodyi.e if we write 
	 					an abstract function we don't need to write its implementation.
							>abstract method */
	public void eat() {  //Non abstract method
		System.out.println("Animal Eat ");
	}
	Animal(){ //It can have constructors
		System.out.println("You are creating a new animal");
	}
}
 
class Horse extends Animal{
	public void walk() {
		System.out.println("walks on 4 legs");
	}
	Horse(){
		System.out.println("You are creating a new Horse");		
	} /* when ever u create a derived class object, then first base class constructor
	is called then followed by derived class constructor--> This process is called as
	constructor chaining.  
	*/
}

class Chicken extends Animal{
	public void walk() {
		System.out.println("walks on 2 legs");
	}
}
public class Abstraction {
	public static void main(String args[]) {
		Horse horse=new Horse();
		horse.walk();
		horse.eat();
		
		//Animal animal=new Animal(); //Cannot instantiate the type Animal because animal
		//animal.walk();//is an abstract class which is a blue print .--gives run time erorr
		
	}
}
