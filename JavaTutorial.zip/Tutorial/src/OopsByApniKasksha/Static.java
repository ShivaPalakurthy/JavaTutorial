package OopsByApniKasksha;
/*
*Static --> A keyword which is accessible for every one. 
*we can directly access ther static variable or methods without creating objects
*
*when static is created memory is given only once, when object is created memory
*is created multiple time
*/
class Students{
	String name;
	static String school;
	
	static String College;
	
	public static void chageCollege() {
		College="Sijo";
	}
}
public class Static {
	public static void main(String args[]) {
		Students.school="Shoa"; //we can directly access ther static variable or methods without creating objects
		Students S1=new Students();
		S1.name="Tin";
		System.out.println(S1.school);
	}
}
