package OopsByApniKasksha;
 /*
  * Access Modifiers are of 4 types.
  * 		1.Public
  * 		2.Private-->Can't be accessed outside the class in whihc it is written. 
  * 					to access Private memebers we'll use getters & setters.
  * 		3.Protected-->Subclass and the classes in which they are there only gets
  * 						Accessible.
  * 		4.Default-->Exists automatically, can be accessible in the same package only
  */

class Account{
	public String name;
	protected String email;
	private String password;
	
	//getters & setters
	public String  getpassword() {
		return this.password;
	}
	public void setpassword(String pass) {
		this.password=pass;
	}
}


public class ACcessModifiers {
	public static void main(String args[]) {
	 Account account1=new Account();
	 account1.name="Shiva"; //accessible inside and outside package
	 account1.email="Shiva1234@gmail.com";//-->accessible in the class & sub-class
	// account1.password="1234rt"; //-->gets error as can't be accessed outside the class\
	 account1.setpassword("1234rt");//-->Accessing private value with getter & setter
	 System.out.println(account1.getpassword()); 
	 
	 /*
	  * Encapsulation:Combining data & its functions as a single entity. 
	  *  			class is an example of encapsulation. when ever we make a class data
	  *  			(properities) & its functions() are wrapped in a single class
	  * 			Due to encapsulation, data hiding becomes possible. Data hiding
	  * 			is possible by using access modifiers.
	  */
	}
}
