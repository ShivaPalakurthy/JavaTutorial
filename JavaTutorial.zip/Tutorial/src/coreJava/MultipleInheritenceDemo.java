package coreJava;

public class MultipleInheritenceDemo {
	class  Account{  //base class
		String accNo = "bank00012345";
	}
	class SupportDemo{}
	class  SavingsAccount extends Account,SupportDemo{   // derived class
		void display(){
			System.out.println("acc no inside SA "+ accNo +"SA");
		}
	}
	
	class  MultiDemo{
		public static void main(String args[]){
			SavingsAccount  sa=new SavingsAccount();
			sa.display();
			
		}
	}

}
// Error as java doesn't support multiple inheritence. It is supported in java using the concept of Interface.'




			
