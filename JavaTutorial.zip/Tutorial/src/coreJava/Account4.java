package coreJava;
		//Example on Interface

interface Account4 {
		public static final int acc=100010101; //Any variable/data member declared inside an Interface by default public static & final
		void openAccont();// Interface method in java is by default public & ABstract
}
//Interface supports multiple inheritence
interface support{}
interface Comfort extends Account4{} //One interface always extends another interface

class savingsAccount implements Account4,support,Comfort{ //class implements another interface

	@Override
	public void openAccont() {
		// TODO Auto-generated method stub
		
	}
	
	
}
