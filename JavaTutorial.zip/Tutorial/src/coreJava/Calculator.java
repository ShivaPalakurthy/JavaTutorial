package coreJava;

//Function overloading / compile time polymorphism
public class Calculator {

 
	public static int addition(int x, int y) {
		return x+y;
	}
	public static void addition(float x, float y) {
		System.out.println( x+y);
	}
	public static float addition(int x, float y) {
		return x+y;
	}
	public static void main(String args[]) {
	System.out.println(addition(200,400)); 
		addition(20.00f,40.00f);
		System.out.println(addition(12,30.00f)); 
	}
}