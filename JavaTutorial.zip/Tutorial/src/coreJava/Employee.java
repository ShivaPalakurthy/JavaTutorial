package coreJava;


//API example of Function overridding / run-time  polymorphism
public class Employee {
	private int empId;
	private String empName;
	
	//Generate using constructor using fields
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
/*17-22 line obtained by bottom procced try without this once and using this u'll 
	find the difference */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
	//	return super.toString();  -->modifying this witl the following return value
		return empId+"/"+empName;
	} 

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
 public static void main(String args[]) {
	Employee obj=new Employee(100,"ATOS");
	System.out.println(obj);
	
	
	
	/*Result is coreJava.Employee@6e8cf4c6 --> it is the objetc adress in the heap in 
	 * hexa decimalResult is coreJava.
  As we know, Any class in java by default extends an object class. so we should 
  override object class to string method in above example.
	 */
	//Overriding object to STring method : source-->Override/implement methods-->toString()

	
	
 

 /*@Override
public String toString() {
	// TODO Auto-generated method stub
	return super.toString(); */
	
	/*to make it more accurate *We'll override by following steps
	 * 		Source-->Override/Implement methods --> choose  After 'Employee(int,String)'
	 * 		at Insertion point:--> select toString() -->click ok/
	 * 
	 * by doing this we'll be placing 
	 * 			@Override
			public String toString() {
				// TODO Auto-generated method stub
					return super.toString();
	}		at line 17- 22

	 */
	/*If we not print toString() method in the class, then it will print object address
	in the heap, if we overridden toStrig() inside a class with your own code , if I'm
	going to print any object, it'll call the toString() implementation and print
	the attribute value.*/
 
}
}
