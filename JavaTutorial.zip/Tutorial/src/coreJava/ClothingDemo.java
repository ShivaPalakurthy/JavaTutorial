package coreJava;
//CoreJavaClass3Notes last hands on problem code. start from clothing.java , shirt.java,trouser.java in this package
//this is the main class	
public class ClothingDemo {
		public static void main(String args[]) {
		
			//public Shirt(int id, double price, char color, int size, int fit)
//from shirt.java seeing the constructor parameters give the values accordingly
			Shirt sh1=new Shirt(101,200.00,'B',40,7);
			Shirt sh2=new Shirt(102,500.00,'B',40,7);
			Shirt sh3=new Shirt(103,900.00,'B',40,7);
			System.out.println("1st Shirt Object: "+ sh1.getId()+"/"+sh1.getPrice()+"/"+sh1.getColor()+"/"+
									sh1.getSize()+"/"+sh1.getFit());
			System.out.println("2nd Shirt Object: "+ sh2.getId()+"/"+sh2.getPrice()+"/"+sh2.getColor()+"/"+
									sh2.getSize()+"/"+sh2.getFit());
			System.out.println("3rd Shirt Object: "+ sh3.getId()+"/"+sh3.getPrice()+"/"+sh3.getColor()+"/"+
									sh3.getSize()+"/"+sh1.getFit());
		}
}
