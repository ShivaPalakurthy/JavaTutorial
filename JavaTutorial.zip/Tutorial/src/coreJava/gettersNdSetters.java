package coreJava;

class Product {
	private int prdId;
	private String prdName;
	public int getPrdId() {
		return prdId;
	}
	public void setPrdId(int prdId) {
		this.prdId = prdId;
	}
	public String getPrdName() {
		return prdName;
	}
	public void setPrdName(String prdName) {
		this.prdName = prdName;
	}

 }

public class gettersNdSetters {

	public static void main(String[] args) {
		Product obj = new Product();
		// using getters 
		System.out.println(obj.getPrdId());
		System.out.println(obj.getPrdName());
		
		//using setters
		obj.setPrdId(1001);
		obj.setPrdName("Improvise");
		
		System.out.println(obj.getPrdId());
		System.out.println(obj.getPrdName());
		
	}

}
