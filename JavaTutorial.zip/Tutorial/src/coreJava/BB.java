package coreJava;
 
class    AA  {

int   a = 7; 

} 

class  BB  extends  AA {

int  a = 9;

public void show(){
	System.out.println("a="+ a);
}
public static void main(String args[]){
	BB obj =new BB();
	 obj.show();
}
}  

//program used to show difference in program by using super keyword
/*class    AA  {

int   a = 7; 

} 

class  BB  extends  AA {

int  a = 9;

public void show(){
	System.out.println("a="+ a);
	System.out.println("Super.a="+ super.a); //used to print base class value.
}
public static void main(String args[]){
	BB obj =new BB();
	 obj.show();
}
}  */