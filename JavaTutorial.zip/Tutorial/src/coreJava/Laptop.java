package coreJava;
// Program to explain Final keyword

/*	class Laptop { 
private int lapId = 10000;

void display() {
	System.out.println(lapId);
}
}

class Order extends Laptop {

}  */

/* final class Laptop {  --> The type Order cannot subclass the final class Laptop -->
If we define a class as final , then final class cannot be inherited or extended.

final class Laptop { 
	 private int lapId = 10000;

	void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	
}   */

/*Using final keywords as a variable -->The final field Laptop.lapId cannot be assigned
 * 
 * If we make a particular variable as final , we cannot change that variable value	
 * throughout your complete inhertitence hierarchy

class Laptop { 
	 final int lapId = 10000;

	void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	
	void show() {
		lapId=2000;
	}
} */

/*final keyword for a method --> result:Multiple markers at this line
								- overrides coreJava.Laptop.display
								- Cannot override the final method 
	 								from Laptop*/
class Laptop {
	private int lapId = 10000;

	final void display() {
		System.out.println(lapId);
	}
}

class Order extends Laptop {
	void display() {
		System.out.println("Overriden method");
	}
}
