package coreJava;


//Example on Abstract Class.
abstract class Account3 {
		void openAccount() {     //method with definition
			System.out.println("Account is Open");
		}
		abstract void closeAccount(); //method with declaration
		abstract void ActiveAccout(); //if we create method with declaration then that method must be Abstract.
}
class SavingsAccounts extends Account3{
	/*	--If Any class that extends an Abstract class, must have to override all
		the abstract methods declared in the abstract class.
so now we've to override all the abstract methods.After overriding the errors will be
gone.
*/

	@Override
	void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Overriden closed Account");
	}

	@Override
	void ActiveAccout() {
		// TODO Auto-generated method stub
		System.out.println("Overriden Active Account");
	}
	/*	--If Any class that extends an Abstract class, must have to override all
   	 			the abstract methods declared in the abstract class.
   	so now we've to override all the abstract methods.
   */
	
	class AbstractDemo{
		public static void main(String args[]) {
			Account3 acc = new SavingsAccounts();/*super class reference is pointing towards derived class 
									object -->run time polymorphism */
			acc.openAccount();
			acc.ActiveAccout();
			acc.closeAccount();
		}
	}
	
}

