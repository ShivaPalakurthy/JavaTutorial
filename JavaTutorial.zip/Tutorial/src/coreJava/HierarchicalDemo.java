package coreJava;


class  Account{  //base class

	String accNo = "bank00012345";

}
class  SavingsAccount1 extends Account{  // derived class
	void display(){
		System.out.println("acc no inside SA"+ accNo +"SA");
	}

}
class CurrentAccount1 extends Account{
	void display(){
		System.out.println("acc no inside CA"+ accNo+"CA");
	}
}
class  HierarchicalDemo{
	public static void main(String args[]){
		SavingsAccount1  sa=new SavingsAccount1();
		sa.display();
		
		CurrentAccount1  ca=new CurrentAccount1();
		ca.display();					
	}
}