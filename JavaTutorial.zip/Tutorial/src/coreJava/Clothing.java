package coreJava;

public class Clothing {
//	CoreJavaClass3Notes last hands on problem code.
	private int id;
	private double price;
	private char color;
	private int size;
	
	//getters & setters : source--> Generate Getters & Setters
	public int getId() {
		return id;
	} 
	public void setId(int id) {
		this.id = id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public char getColor() {
		return color;
	}
	public void setColor(char color) {
		this.color = color;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	//Creating constructors
	//Creating default constructor : source-->Generate constructor using fields-->Deselect all -->Generate.
	public Clothing() {
		super();
	}
	// Creating Parameturised Constructor   :source-->Generate constructor using fields-->select all -->Generate.
	public Clothing(int id, double price, char color, int size) {
		super();
		this.id = id;
		this.price = price;
		this.color = color;
		this.size = size;
	}
	


	
}
