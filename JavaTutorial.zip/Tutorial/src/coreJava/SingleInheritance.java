package coreJava;

class  Shape { //base class
	String h1 = "hello";
}
class   Circle  extends Shape{ // derived class

}
class SingleInheritance{
	public static void main(String args[]){
		
	Circle  c = new Circle();
	System.out.println(c.h1);

	}
}
