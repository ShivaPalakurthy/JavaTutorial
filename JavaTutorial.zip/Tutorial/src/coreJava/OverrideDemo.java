package coreJava;

 class Shape2{	
  		void area(){			//here access specifier is default
  		
  		System.out.println("inside shape");
  	}
  }
  class Circle2 extends Shape2{
 	void area(){			//here access specifier is default
  		System.out.println("Area of circle");
  	}
  }
  
  //here same function is overridden from base class to derived class
  
  class OverrideDemo{
	  public static void main(String args[]) {
		  Shape2 sh=new Circle2();
		  sh.area();
	}
  }