package coreJava;

 class  Shape1 { //base class
	String h1 = "hello";
}
class   Circle1  extends Shape1{ // derived class

}
class Line extends Circle1 { // derived class

}
class MultiLevelDemo{
	public static void main(String args[]){
		
	Line   l = new Line();
	System.out.println(l.h1);

	}
}	