package coreJava;

//pROGRAM  to show the use if super() function    
/*
class    XX {
	int a;
	int b;
	XX(){
		System.out.println("default const of XX");
	}
	XX(int x,int y){
		this.a=x;
		this.b=y;
		System.out.println("para const of XX"+a+"/"+b);
	}
}
class   YY extends XX{
	int c;
	YY(){
		System.out.println("default const of YY");
	}
	YY(int x,int y,int z){
		this.a=x;
		this.b=y;
		this.c=z;
		System.out.println("para const of YY"+a+"/"+b+"/"+c);
		
	}
	public static void main(String args[]){
		YY obj=new YY(30,40,50);
	}
} */

/*here problem is already there is 	XX(int x,int y){
									this.a=x;
									this.b=y;} we're not reusing it and we're direactly intialising in 
					
						YY(int x,int y,int z){
							this.a=x;
							this.b=y;
							this.c=z; }
							
if base class already has some initialisation, then we should reuse that code from derived class to base class. so we
can reuse the code by using super() function.

for an instance lets say XX(int x,int y){
									this.a=x;
									this.b=y;} has 60 lines in it & if we write 
60 lines in	YY(int x,int y,int z){
							this.a=x;
							this.b=y;
							this.c=z; } then the code becomes complex, to reduce complexity
& to improve reusability we use super() function to use base class.
*/
class    XX {
	int a;
	int b;
	XX(){
		System.out.println("default const of XX");
	}
	XX(int x,int y){
		this.a=x;
		this.b=y;
		System.out.println("para const of XX"+a+"/"+b);
	}
}
class   YY extends XX{
	int c;
	YY(){
		System.out.println("default const of YY");
	}
	YY(int x,int y,int z){
		super(x,y);
		//this.a=x;
		//this.b=y;
		this.c=z;
		System.out.println("para const of YY"+a+"/"+b+"/"+c);
		
	}
	public static void main(String args[]){
		YY obj=new YY(30,40,50);
	}
}
