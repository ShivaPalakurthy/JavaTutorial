package coreJava;

public class Shirt extends Clothing{
	//CoreJavaClass3Notes last hands on problem code. start from clothing.java in this package
	private int fit;
//Creating constructor : :source-->Generate constructor using fields--> select Clothing(int,double,char,int) from
					//top(Select super constructor to invoke)-->select all -->Generate.
	public Shirt(int id, double price, char color, int size, int fit) {
		super(id, price, color, size);
		this.fit = fit;
	}
	
	//Creating getters & Setters
	public int getFit() {
		return fit;
	}
	public void setFit(int fit) {
		this.fit = fit;
	}

	
		
}
