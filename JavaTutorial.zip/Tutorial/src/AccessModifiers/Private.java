package AccessModifiers;
/*
 * Private: The access level of a private modifier is only within the class. It cannot be accessed 
 * from outside of the class. In order to access the private parameters we use getter and setter method.*/

class Account{
	public String name;
	protected String email;
	private String password;
	
	//getter & setters
	public String getPassword()
	{
		return this.password;
	}
	public void setPassword(String pass)
	{
		this.password=pass;
	}
	public void PrintInfo(){
		System.out.println(this.name);
		System.out.println(this.email);
	}
}
public class Private {
	public static void main(String args[]) {
		Account acc1=new Account();
		acc1.name="Adapt.Improvise.Overcome.";
		acc1.email="srk.smazz@gmail.com";
		/*acc1.password="ASKEY1234"; ---> won't be working because of private declaration so to make it work
		 * we use setter and getter method.
		 */
		acc1.setPassword("ASKEY1234");
		acc1.PrintInfo();
		System.out.println(acc1.getPassword());
	}

}
