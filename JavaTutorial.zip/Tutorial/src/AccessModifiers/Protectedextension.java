package AccessModifiers;
public class Protectedextension extends Quote {
	  public static void main(String args[]) {
		Protectedextension sc=new Protectedextension();
		sc.display();
	}
} 


