package BitManipulation;
import java.util.*;
public class clearBit {
 public static void main(String args[]) {
	 
	 // for clear bit we perform ANd with NOT for bitmask i.e we should 
	 	//perform not of bitmask and then the result sholud perform AND operation with the given number
	 
	 /* Clearbit is used to keep the bit value to 0
	  * Bit Mask: 1<<i  ;
	  * Operation : AND With NOT of BitMask*/
	 int n=5;
	 int pos=2;
	 int bitMask=1<<pos;
	 int notBitMask= ~(bitMask); //Not operation--> ~
	 int newNumber= notBitMask & n;
	 System.out.println(newNumber);
}
}