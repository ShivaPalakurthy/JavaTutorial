package BitManipulation;

public class del {
	public static void main(String args[]) {
		//1,3,5,7,9
		//2,4,8,16,32
		 int a=1;
		for (int i=1; i<=10;i++){
		System.out.println(i*2-1);
		
		a=a*2;
		System.out.println(a);
		}
		
	}
}

