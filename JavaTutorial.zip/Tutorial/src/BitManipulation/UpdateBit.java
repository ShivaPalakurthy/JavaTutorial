package BitManipulation;
import java.util.*;
public class UpdateBit {
	public static void main(String args[]) {
 	// For making o -->> Bit Mask :1<<i  Operation: AND with NOT
	// For making 1 -->> Bit Mask :1<<i  Operation: OR
		int n=5; //0101
		int pos=1;
		int bitMask=1<<pos;
		
		 Scanner sc= new Scanner(System.in);
		int oper=sc.nextInt();
		//if operation is 1 then value gets update with one i.e Set bit operation is performed
		//if operation is 0 then value gets update with zero i.e clear bit operation is performed
		
		if(oper==1) {
			//i.e set operation
			int newNumber=bitMask |n;
			System.out.println(newNumber);
		}else {
			//i.e Clear Operation
			int newBitMask=~(bitMask);
			int newNumber=newBitMask &n;
			System.out.println(newNumber);
		}
}
}
//Update bit is used to change the value of the bit from o to 1 or from 1 to 0