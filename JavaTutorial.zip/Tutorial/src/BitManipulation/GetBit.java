package BitManipulation;
import java.util.*;
public class GetBit {
/*   GetBit helps to know whether the position bit is zero or one
 * Bit Mask: 1<<i  ;
 * Operation : AND*/
	public static void main(String args[]) {
		int n=5;
		int pos=3;
		int bitMask=1<<pos;
		if((bitMask&n)==0)
		{
			System.out.println("bit was Zero");
		}
		else {
			System.out.println("bit was One");
		}
	}
}