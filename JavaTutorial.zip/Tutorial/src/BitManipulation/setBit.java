package BitManipulation;

public class setBit {
 public static void main(String arg[]) {
		int n=5;
		int pos=1;
		int bitMask=1<<pos;
		int newNumber=bitMask|n;		// |--> used for OR operation
		System.out.println(newNumber);
}
}
/*Setbit is used to set the bit value to 1 if it's not 1 
 * Bit Mask: 1<<i  ;
 * Operation : OR*/
