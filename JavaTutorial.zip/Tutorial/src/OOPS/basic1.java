package OOPS;

 

/*  1st Example
   class  Pen{
	String color;
	String type;  //ballpoint or gel
	
	public void write()
	{
	System.out.println("Change.Gratitude.Breakthrough.");
	}
	
	public void printColor(){
		System.out.println(this.color); //know about this keyword while Studyin
	}
}
 
	 */
class Student{
	String name;
	int age;
	
	public void printInfo() {
		System.out.println(this.name);
		System.out.println(this.age);
	}
}


public class basic1 {
 public static void main(String args[]) {
/*	1st Example main program
 * 	Pen pen1=new Pen();
	pen1.color="blue";
	pen1.type="Gel";
	
	pen1.write();
	System.out.println();
	pen1.printColor();
	System.out.println();
	System.out.println(pen1.type); 
  */
	 
	 Student s1=new Student();  /*new--> when we use new keyword , a memory is allocated in the 
	 							heap memory and the object gets stored in that heap memory(here s1)
	 							Student()--> student with () is considered as a function and it is named
	 							as Constructors (purpose is to construct java's objects)
	 							*/	
	 /*Properties of the constructors
	  * 1.the constructor of a class or object has the same name  of the class or object respectively
	  * 2.Constructors are methods/functions but they wont return anything i.e int,string,float, void 
	  * dosen't work on the constructor 
	  *3.for one object, constructor can be called only once.
	  * */
	 s1.name="Palakurthy Shiva Rama Krishna";
	 s1.age=22;
	 s1.printInfo();
 
 } 
}

/* java Has 3 types of constructor
 * 1.Non - parameterized Constructor -->In these constructors there will be no parameters
 * 2.Parameterized Constructor-->we'll have parameters in the constructor
 * 3.Copy Constructors-->copys one object and drops it in another object  */
 