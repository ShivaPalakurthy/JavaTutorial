package OOPS;

public class Basic {

}
