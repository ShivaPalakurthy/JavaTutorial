package OOPS;

/*Polymorphism- poly-many;morphism-form
 * when we do a certain work in different times then we call it polymorphism
 * Types of Polymorphism
 * 1.function overloading-compile time polymorphism
 * 2.function overridding- run time polymorphism*/



/*This is compile time polymorphism example
* function overloading--> here we'll create different functions in a single class and they perform different
* tasks but they all have same name*/



 class  Employees{
	 String name;
	 int age;
	 public void printInfo(String name) {
		 System.out.println(name);
	}
	 public void printInfo(int age) {
		 System.out.println(age);
	}
	 public void printInfo(String name,int age) {
		 System.out.println(name + " " + age);
	}
}
public class polymorphism_function_overloading {
	public static void main(String args[]) {
		Employees s1=new Employees();
		s1.name="Shiva Rama Krihna Palakurthy";
		s1.age=22;
		
		s1.printInfo(s1.name);
		s1.printInfo(s1.name,s1.age);
		s1.printInfo(s1.age);
	
}
}

/*Rules to implement overloading
 * 1.Any two functions return type should not be same.
 * 2.if the return types are same then the parameters type should not be same.
 * 3. if both 1,2 are same then the numbers of arguments must be different.
 * */
