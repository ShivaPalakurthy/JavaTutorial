package OOPS;
/*Encapsulation helps in data hiding with the help of Access Modifiers
 * 
 */
public class Encapsulation {

}
