package OOPS;

/*inheriting one class's properties and methods to another Class is called inheritance
 * --> improves reusability property
 */

 /*  //basic example of inheritance
class shape{
	String color;
}

class triangle extends shape{
	
}
public class Inheritance {
 public static void main(String args[]) {
	triangle t1=new triangle();
	t1.color="red";
}
} */

   
class shape{
	public void area() {
		System.out.println("displays area");
	}
}
//-->single level inheritance
class triangle extends shape{
	public void area(int l,int h) {
		System.out.println(1/2*h*l);
	}
}
/*
//-->multilevel inheritance
class EquilateralTriangle extends triangle{
	public void area(int l,int h) {
		System.out.println(1/2*h*l);
	}
}
 */

//-->hierarchial inheritance--> one base class many derieved class

class circle extends shape{
	public void area(int r) {
		System.out.println((3.14)*r*r);
	}
}

public class Inheritance{
	public static void main(String args[]) {
		circle sc=new circle();
		sc.area(7);
		sc.area();
		
	}
}