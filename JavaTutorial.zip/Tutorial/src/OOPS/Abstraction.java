package OOPS;
/* Abstraction helps to show the necessary data to user and hide the unnecessary or sensitive data from the user
 * 
 * Data hiding is the process of protecting members of class from unintended changes whereas, abstraction 
 * is hiding the implementation details and showing only important/useful parts of the user.
 */
class Animal{
	public void walk() {
		
	}
}

class Horse extends Animal{
	public void walk() {
		System.out.println("Walks on 4 legs");
	}
}
class Chicken extends Animal{
	public void walk() {
		System.out.println("Walks on 2 legs");
	}
}
public class Abstraction {

}
