package OOPS;
/*
//1.Non-Parameterized Constructor
class Employee{
	 String name;
	 int age;
	 public void printInfo() {
		 System.out.println(this.name);
		 System.out.println(this.age);
	 }
	 Employee(){
		 System.out.println("Cosntructor is called");
	 }
}

public class basic2{
	 public static void main(String args[]) {
		Employee s1=new Employee();
		s1.name="PAlakurthy";
		s1.age=22;
		s1.printInfo();
	}
}

*/




/*
//2.Parameterized COnsrtructor

 class Employee{
	 String name;
	 int age;
	 public void printInfo() {
		 System.out.println(this.name);
		 System.out.println(this.age);
	 }
	 Employee(String name, int age){
		 this.name=name;
		 this.age=age;
	 }
 }
	
 
 public class basic2{
	 public static void main(String args[]) {
		Employee s1=new Employee("Shiva Rama Krishna",22);
		s1.printInfo();
	}
 }
*/


//3.Copy Constructor

class Employee{
	 String name;
	 int age;
	 public void printInfo() {
		 System.out.println(this.name);
		 System.out.println(this.age);
	 }
	 Employee(Employee s2){   //-->copy constructor
		 this.name=s2.name;
		 this.age=s2.age;
	 }
	 /*when we use copy constructor, the constructor which is being called
	 must also be declared*/
	 Employee(){
		 
	 }
	 
}

public class basic2{
	 public static void main(String args[]) {
		Employee s1=new Employee();
		s1.name="Shiva Rama Krishna Palakurthy";
		s1.age=22;
		Employee s2=new Employee(s1);
		s2.printInfo();
	 }
	 
}