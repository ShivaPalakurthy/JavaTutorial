package DELETELATER;

//package com.flight;

import java.util.LinkedList;

public class FlightDAOCollectionImpl implements FlightDAO {

	LinkedList<Flights> flightList = new LinkedList<Flights>();

	@Override
	public boolean create(Flights F) {
		flightList.add(F);
		return true;
	}

	@Override
	public boolean delete(int id) {
		for (Flights f : flightList) {
			if (f.getFlightId() == id)
				return flightList.remove(f);
		}
		return false;
	}

	@Override
	public boolean update(Flights F) {
		for (Flights f : flightList) {
			if (f.getFlightId() == F.getFlightId()) {
				flightList.set(flightList.indexOf(f), F);
				return true;
			}
		}

		return false;
	}

	@Override
	public Flights get(int id) {
		for (Flights f : flightList) {
			if (f.getFlightId() == id)
				return f;
		}
		return null;
	}

	@Override
	public LinkedList<Flights> getAllList() {
		// TODO Auto-generated method stub
		return flightList;
	}

}
