package DELETELATER;

//package com.flight;

import java.sql.Timestamp;
import java.util.*;

public class FlightAdminJDBC {

	public static void main(String[] args) {
		int flightId,busiClsCount,ecoClsCount,firstClsCount,option;
		String name,takeOff,landing;
		Timestamp takeOffTime, landingTime;
		float busiCls, ecoCls,firstCls;
		FlightDAOJBCimpl ft = new FlightDAOJBCimpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println(
					"1. Add new flight\n 2. Update Flight\n 3. Get flight\n 4. Remove flight\n 5. Display all flights \n 6. Exit \n Enter your option");
			option = sc.nextInt();

			switch (option) {
			case 1: // create flight
				System.out.println("enter the id");
				flightId = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the name");
				name = sc.nextLine();
				System.out.println("Enter the Take off city");
				takeOff = sc.nextLine();
				System.out.println("Enter the landing city");
				landing = sc.nextLine();
				
				System.out.println("Enter Business class count");
				busiClsCount = sc.nextInt();
				System.out.println("Enter the price of business class");
				busiCls = sc.nextFloat();
				
				System.out.println("Enter economic class count");
				ecoClsCount = sc.nextInt();
				System.out.println("Enter the price of economic class");
				ecoCls = sc.nextFloat();
				
				System.out.println("Enter first class count");
				firstClsCount = sc.nextInt();
				System.out.println("Enter the price of first class");
				firstCls = sc.nextFloat();
				

				System.out.println("Enter the Take off HH");
				int thh = sc.nextInt();
				System.out.println("Enter the Take off MM");
				int tmm = sc.nextInt();
				takeOffTime = new Timestamp(0, 0,0, thh, tmm, 0, 0);
				System.out.println("Enter the landing HH");
				int lhh = sc.nextInt();
				System.out.println("Enter the landing MM");
				int lmm = sc.nextInt();
				landingTime = new Timestamp(0, 0,0, lhh, lmm, 0, 0);
//				ft.create(new Flights(id, capacity, name, takeOffCity, landingCity, LocalTime.of(thh, tmm, 0),
//						LocalTime.of(lhh, lmm, 0)));
				ft.create(new Flights(flightId, busiClsCount, ecoClsCount, firstClsCount, name, takeOff, landing, takeOffTime, landingTime, busiCls, ecoCls, firstCls));
				break;
			
			case 2: // update flight
				System.out.println("enter the id of flight you want to update");
				flightId = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the name");
				name = sc.nextLine();
				System.out.println("Enter the Take off city");
				takeOff = sc.nextLine();
				System.out.println("Enter the landing city");
				landing = sc.nextLine();
				
				System.out.println("Enter Business class count");
				busiClsCount = sc.nextInt();
				System.out.println("Enter the price of business class");
				busiCls = sc.nextFloat();
				
				System.out.println("Enter economic class count");
				ecoClsCount = sc.nextInt();
				System.out.println("Enter the price of economic class");
				ecoCls = sc.nextFloat();
				
				System.out.println("Enter first class count");
				firstClsCount = sc.nextInt();
				System.out.println("Enter the price of first class");
				firstCls = sc.nextFloat();
				

				System.out.println("Enter the Take off HH");
				thh = sc.nextInt();
				System.out.println("Enter the Take off MM");
				tmm = sc.nextInt();
				takeOffTime = new Timestamp(0, 0,0, thh, tmm, 0, 0);
				System.out.println("Enter the landing HH");
				lhh = sc.nextInt();
				System.out.println("Enter the landing MM");
				lmm = sc.nextInt();
				landingTime = new Timestamp(0, 0,0, lhh, lmm, 0, 0);
//				ft.create(new Flights(id, capacity, name, takeOffCity, landingCity, LocalTime.of(thh, tmm, 0),
//						LocalTime.of(lhh, lmm, 0)));
				ft.update(new Flights(flightId, busiClsCount, ecoClsCount, firstClsCount, name, takeOff, landing, takeOffTime, landingTime, busiCls, ecoCls, firstCls));
				break;

			case 3: // find flight by id
				System.out.println("Enter the flight Id");
				flightId = sc.nextInt();
				Flights x = ft.get(flightId);
				if(x!=null)
					System.out.println(x);
				else
					System.out.println("Flight not found");
				break;

			case 4: // Remove flight
				System.out.println("Enter the flight Id");
				flightId= sc.nextInt();
				System.out.println(ft.delete(flightId));

			case 5: // display all
				
				LinkedList<Flights> flightlist = ft.getAllList();
				for (Flights f : flightlist) {
					System.out.println(f);
				}
				break;
			case 6: // find flights between cities
				
				
				break;
			case 7:
				
				break;

			default:
				System.out.println("invalid option");

			}
		} while (option != 6);

	}

}

