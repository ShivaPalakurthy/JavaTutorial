package DELETELATER;

//package com.flight;
import java.sql.*;

public class Flights {

	private int flightId,busiClsCount,ecoClsCount,firstClsCount;
	private String name,takeOff,landing;
	private Timestamp takeOffTime, landingTime;
	private float busiCls, ecoCls,firstCls;
	
	public Flights(int flightId, int busiClsCount, int ecoClsCount, int firstClsCount, String name, String takeOff,
			String landing, Timestamp takeOffTime, Timestamp landingTime, float busiCls, float ecoCls, float firstCls) {
		super();
		this.flightId = flightId;
		this.busiClsCount = busiClsCount;
		this.ecoClsCount = ecoClsCount;
		this.firstClsCount = firstClsCount;
		this.name = name;
		this.takeOff = takeOff;
		this.landing = landing;
		this.takeOffTime = takeOffTime;
		this.landingTime = landingTime;
		this.busiCls = busiCls;
		this.ecoCls = ecoCls;
		this.firstCls = firstCls;
	}
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public int getBusiClsCount() {
		return busiClsCount;
	}
	public void setBusiClsCount(int busiClsCount) {
		this.busiClsCount = busiClsCount;
	}
	public int getEcoClsCount() {
		return ecoClsCount;
	}
	public void setEcoClsCount(int ecoClsCount) {
		this.ecoClsCount = ecoClsCount;
	}
	public int getFirstClsCount() {
		return firstClsCount;
	}
	public void setFirstClsCount(int firstClsCount) {
		this.firstClsCount = firstClsCount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTakeOff() {
		return takeOff;
	}
	public void setTakeOff(String takeOff) {
		this.takeOff = takeOff;
	}
	public String getLanding() {
		return landing;
	}
	public void setLanding(String landing) {
		this.landing = landing;
	}
	public Timestamp getTakeOffTime() {
		return takeOffTime;
	}
	public void setTakeOffTime(Timestamp takeOffTime) {
		this.takeOffTime = takeOffTime;
	}
	public Timestamp getLandingTime() {
		return landingTime;
	}
	public void setLandingTime(Timestamp landingTime) {
		this.landingTime = landingTime;
	}
	public float getBusiCls() {
		return busiCls;
	}
	public void setBusiCls(float busiCls) {
		this.busiCls = busiCls;
	}
	public float getEcoCls() {
		return ecoCls;
	}
	public void setEcoCls(float ecoCls) {
		this.ecoCls = ecoCls;
	}
	public float getFirstCls() {
		return firstCls;
	}
	public void setFirstCls(float firstCls) {
		this.firstCls = firstCls;
	}
	@Override
	public String toString() {
		return "Flights [flightId=" + flightId + ", busiClsCount=" + busiClsCount + ", ecoClsCount=" + ecoClsCount
				+ ", firstClsCount=" + firstClsCount + ", name=" + name + ", takeOff=" + takeOff + ", landing="
				+ landing + ", takeOffTime=" + takeOffTime + ", landingTime=" + landingTime + ", busiCls=" + busiCls
				+ ", ecoCls=" + ecoCls + ", firstCls=" + firstCls + "]";
	}
	
}

