package DELETELATER;

//package com.flight;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectOracleDB {
	
	private ConnectOracleDB() {
		
	}

	public static Connection open() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dbuser", "1234");
		} catch (Exception e) {
			System.err.println(e);
			return null;
		}

	}

	public static boolean close(Connection con) {
		try {
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

}

