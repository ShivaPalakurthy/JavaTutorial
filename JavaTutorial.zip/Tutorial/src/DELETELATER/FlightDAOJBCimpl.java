package DELETELATER;
//package com.flight;

import java.sql.*;
import java.util.LinkedList;

public class FlightDAOJBCimpl implements FlightDAO {

	private Connection con;
	private Statement stmt;
	private ResultSet rs;

	@Override
	public boolean create(Flights F) {
		try {
			con = ConnectOracleDB.open();
			PreparedStatement prst = con.prepareStatement("insert into flights values(?,?,?,?,?,?,?,?,?,?,?,?)");

			prst.setInt(1, F.getFlightId());
			prst.setString(2, F.getName());
			prst.setString(3, F.getTakeOff());
			prst.setTimestamp(4, F.getTakeOffTime());
			prst.setString(5, F.getLanding());
			prst.setTimestamp(6, F.getLandingTime());
			prst.setInt(7, F.getBusiClsCount());
			prst.setFloat(8, F.getBusiCls());
			prst.setInt(9, F.getEcoClsCount());
			prst.setFloat(10, F.getEcoCls());
			prst.setInt(11, F.getFirstClsCount());
			prst.setFloat(12, F.getFirstCls());

			if (prst.executeUpdate() >= 1) {
				ConnectOracleDB.close(con);
				return true;
			}
			ConnectOracleDB.close(con);
			return false;
		} catch (Exception e) {
			ConnectOracleDB.close(con);
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		try {
			con = ConnectOracleDB.open();
			PreparedStatement prst = con.prepareStatement("delete from flights where flight_id=?");

			prst.setInt(1, id);
			if (prst.executeUpdate() >= 1) {
				ConnectOracleDB.close(con);
				return true;
			}
			ConnectOracleDB.close(con);
			return false;
		} catch (Exception e) {
			ConnectOracleDB.close(con);
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean update(Flights F) {
		try {
			con = ConnectOracleDB.open();
			PreparedStatement prst = con.prepareStatement(
					"update flights set name=?, take_off=?, take_off_time=?, landing=?,landing_time=?, busi_class=?,busi_class_price=?,eco_class=?,eco_class_price=?,first_class=?,first_class_price=? where flight_id=?");

			prst.setString(1, F.getName());
			prst.setString(2, F.getTakeOff());
			prst.setTimestamp(3, F.getTakeOffTime());
			prst.setString(4, F.getLanding());
			prst.setTimestamp(5, F.getLandingTime());
			prst.setInt(6, F.getBusiClsCount());
			prst.setFloat(7, F.getBusiCls());
			prst.setInt(8, F.getEcoClsCount());
			prst.setFloat(9, F.getEcoCls());
			prst.setInt(10, F.getFirstClsCount());
			prst.setFloat(11, F.getFirstCls());
			prst.setInt(12, F.getFlightId());
			if (prst.executeUpdate() >= 1) {
				ConnectOracleDB.close(con);
				return true;
			}
			ConnectOracleDB.close(con);
			return false;
		} catch (Exception e) {
			ConnectOracleDB.close(con);
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Flights get(int id) {
		// TODO Auto-generated method stub

		try {
			con = ConnectOracleDB.open();
			stmt = con.createStatement();
			PreparedStatement prst = con.prepareStatement("select * from flights where flight_id=?");
			prst.setInt(1, id);		
			rs = prst.executeQuery();
			if (rs.next()) {
				
				Flights f =new Flights(rs.getInt(1), rs.getInt(7), rs.getInt(9), rs.getInt(11), rs.getString(2),
						rs.getString(3), rs.getString(5), rs.getTimestamp(4), rs.getTimestamp(6), rs.getFloat(8),
						rs.getFloat(10), rs.getFloat(12));
				ConnectOracleDB.close(con);
				return f;
			}
			ConnectOracleDB.close(con);
			return null;
		} catch (Exception e) {
			ConnectOracleDB.close(con);
			e.printStackTrace();
			return null;

		}

	}

	@Override
	public LinkedList<Flights> getAllList() {
		// TODO Auto-generated method stub
		LinkedList<Flights> flightList = new LinkedList<Flights>();
		try {
			con = ConnectOracleDB.open();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from flights");
			while (rs.next()) {
				Flights fl = new Flights(rs.getInt("flight_id"), rs.getInt("busi_class"), rs.getInt("eco_class"),
						rs.getInt("first_class"), rs.getString("name"), rs.getString("take_off"),
						rs.getString("landing"), rs.getTimestamp("take_off_time"), rs.getTimestamp("landing_time"),
						rs.getFloat("busi_class_price"), rs.getFloat("eco_class_price"),
						rs.getFloat("first_class_price"));

				flightList.add(fl);

			}
			ConnectOracleDB.close(con);
			return flightList;

		} catch (Exception e) {
			ConnectOracleDB.close(con);
			e.printStackTrace();
			return null;
		}

	}

}

