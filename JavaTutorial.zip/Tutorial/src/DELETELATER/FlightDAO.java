package DELETELATER;

//package com.flight;

import java.util.LinkedList;import DomesticAirReservationSystem.FlightDetails;

public interface FlightDAO {

	boolean create(Flights F);

	boolean delete(int id);

	boolean update(Flights F);

	Flights get(int id);

	default Flights[] getAllArray() {
		return null;
	}
	default LinkedList<Flights> getAllList() {
		return null;
	}
}

