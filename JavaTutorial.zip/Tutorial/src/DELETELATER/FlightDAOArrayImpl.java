package DELETELATER;

//package com.flight;

public class FlightDAOArrayImpl implements FlightDAO {
	Flights fl[] = new Flights[5];
	int index = 0;

	@Override
	public boolean create(Flights F) {
		if (index < 5) {
			fl[index] = F;
			index++;
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean delete(int id) {

		for (int i = 0; i <= index; i++) {
			if (fl[i].getFlightId() == id) {
				fl[i]=null;
				for (int j = i; j < index-1; j++) {
					fl[j] = fl[j + 1];
					fl[j + 1] = null;
				}
				return true;
			} 
		}

		return false;
	}

	@Override
	public boolean update(Flights F) {

		for (int i = 0; i <= index; i++) {
			if (fl[i].getFlightId() == F.getFlightId()) {
				fl[i] = F;
				return true;
			}
		}
		return false;

	}

	@Override
	public Flights get(int id) {
		for (int i = 0; i <= index; i++) {
			if (fl[i].getFlightId() == id) {
				return fl[i];
			}
		}
		return null;
	}

	@Override
	public Flights[] getAllArray() {
		return fl;
	}

}
