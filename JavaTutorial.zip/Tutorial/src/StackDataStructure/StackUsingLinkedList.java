package StackDataStructure;

import OopsByApniKasksha.Static;

public class StackUsingLinkedList {
	/*
	 * There are mainly three operations in Stack:
	 * 			1.Push  0(1)
	 * 			2.Pop	0(1)
	 * 			3.Peek  0(1)
	 * 
	 * Stack DataStructure follows last in first out order i.e LIFO order
	 * 
	 * Push: Push Operation is used to push an element into the stack.It is always performed
	 * at the top of the stack.Ideal Time complexity for push Operation will be O(1).
	 * Pop :Pop operation is used to take an element from the top of the stack.It is 
	 * always performed at the top of the stack. Ideal Time complexity will be O(1).
	 * Peek:It is known a Peek operation in java whereas it is known as Top operation in
	 * C++.Peek operation is used to get the value of the element at the top of the stack.
	 * Ideal Time Complexity for the Peek Opearation will be O(1).
	 * 
	 * 1.Why we don't prefer implementation of Stacks in Arrayform:
	 * 		Usually arrays are of fixed length, but stacks can't bei.e many elemenets can 
	 * come in stack. The last index of array  is treated as top of the stack.if elements
	 * in the array are equal to n /full then we need to take an array of larger length & 
	 * we have to copy all these elements into it then we can implement the stack. This 
	 * entire process will be tideous/hectic so we don't usually prefer the implementation
	 * of stacks in Array form.
	 * 
	 * 2.We can implement Stack in both arrayList & Linkedlist as both of there sizes are
	 * variable
	 * 3.In arrayList ending element will become the top as long as we inject the elements
	 * the size of the arrayList gets increased.
	 * 4.In LinkedList, when ever we'll add a new element we'll make that element as Head by 
	 * doing this Stack will be formed. because we can only track LinkedList head, other elements
	 * in the linkedlist can't be tracked & also for ideal stack operation (pop,peek,push)
	 * we need to keep the time complexity as O(1).
	 */
	static class Node{
		int data;
		Node next;
		public Node(int data) {
			this.data=data;
			next=null;
		}
	}
	static class Stack{
		public static Node head;
		//checking whether the linkedlist/ Stack is empty or not
		public static boolean isEmpty() {
			return head==null; //returns true if it is true else returns false
		}
		//push function
		public static void push(int data) {
			
			Node newNode=new Node(data);//creating new node for our data
			if(isEmpty()) { //if stack is empty
				head=newNode;
				return;
			}
			newNode.next=head; //if stack has already elements in it
			head=newNode;
		}
		//pop function-->deletes the element & returns it
		public static int pop() {
			if(isEmpty()) {
				return -1;  //-1 ressembles that the stack is empty
			}
			int top=head.data;
			head=head.next;
			return top;
		}
		//peek operation-- checking the element at the top of the stack
		public static int peek() {
			if(isEmpty()) {
				return -1;  //-1 ressembles that the stack is empty
			}
			return head.data;
		}
	}
	public static void main(String args[]) {
		Stack s=new Stack();
		s.push(1);
		s.push(2);
		s.push(3);
		s.push(4);
		
		while(!s.isEmpty()) {
			System.out.println(s.peek());
			s.pop();
		}
	}
}
