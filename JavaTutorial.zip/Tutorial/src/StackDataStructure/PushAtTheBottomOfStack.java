package StackDataStructure;

import java.util.*;

public class PushAtTheBottomOfStack {
/*
 * Stacks are of two types 
 * 			i.Implicit Stack=> Stack that occur through system directly eg. stacks formed
 * 								during reccursion by the system/code/memory
 * 			ii.Explicit Stack=> Stacks that are formed by us.
 * 
 *  Question is to insert elemnt from bottom of stack
 *  
 *  						[5]
 * 				[		]	 /			[	4	]
 * 				[	4	]   /			[	3	]
 * 				[	3	]  /		=>	[	2	]
 * 				[	2	] /				[	1	]
 * 				[	1	]/				[	5	]
 * 					INP						output
 * 			this is an explicit stack
 * 
 * Sol: by using recursion we'll remove all the elements of the stack and make it
 * an empty stack then we'll add new element & then we'll copy all the elements back
 * into the stack.
 * 				
 * 					BC-->base case =>here it is null
 * 		  /\
 * 		  ||		[	.BC		5	]   ||	  
 * 		  ||		[	1	-->	1	]   ||
 * 		  ||		[	2	--> 2	]   ||
 * 		  ||		[	3	--> 3	] 	||
 * 		remove		[	4	--> 4	] 	\/
 * 									  push
 * 				
 * 			
 */
	public static void pushAtBottom(int data,Stack<Integer> s) {
		if(s.isEmpty()) {
			s.push(data);
			return;
		}
		
		int top=s.pop();
		pushAtBottom(data, s);
		s.push(top);
	}
	public static void main(String args[]) {
		Stack<Integer> s=new Stack<>();
		s.push(1);
		s.push(2);
		s.push(3);
		s.push(4);
 
		
		pushAtBottom(5,s);
		while(!s.isEmpty()) {
			System.out.println(s.peek());
			s.pop();
		}
	}
}
