package StackDataStructure;

public class ReverseAStack {
 
}
