 package Basic;
import java.util.*;
public class Functions {
/*
 * Functions are block of codes which will take inputs & does some operations & gives 
 * output
 * 
 * 
 * Syntax of functions
 * returnType functionName(type arg1,type arg2,...){
 *	//operations
 * }
 * 
 * functionName can be any name but it shouldn't be the name of a Keyword
 */
	
	
	//Print a given name in a function
	
	public static void prinMyName(String name) {
		System.out.println(name);
		return;
	}
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		String name=sc.next();
		prinMyName(name);  //call kiya function ko
	}
}
/*
All the functions in java gets stored in Stack Form
*/