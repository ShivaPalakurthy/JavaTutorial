package Basic;

public class Sample {
		public static void main(String args[]) {
			System.out.println("Adapt.Improvise.Overcome.");
		}
}
/*
 *To run java code, the code has to go from two steps.
 *	1.Compilation
 *	2.Execution
 *				---------------------------------
 * 				|						JDK		|
 *  			|								|
 *   			|	--------------				|
 *    			|	|		JRE	 |				|
 *     			|	|			 |	+ 			|
 *     			|	|(JVM)	+	 | Development	|
 *     			|	|Libraries	 |	Tools		|
 *  			|	--------------				|
 *   			|								|
 *   			---------------------------------
 *   JDK-->Java Development Kit
 *   JRE-->Java Runtime Environment
 *   JVM-->Java Virtual Machine
 *   
 *   Compilation process:- |source	   |-->(compiler)-->[byte code.class]
 *   					   |code.java  |		JDK
 *   													This code can run under
 *   													any operating system as long
 *   													as that operating system has
 *   													JDK.This is the reason why java
 *   													is called as portable language.
 *   ** JAva is platform independent whereas JDK is platform dependent
 *   
 *   Execution process:-[Byte code]-->(JVM)-->[native code]
 *   											The code that the computer 
 *   											can understand
 *   JVM converts byte code to native code
 *   
 *   
 *   Functions /methods in java are those parts where we want to perform some work/actions
 *   Class can be a large entity in which many functions can come.
 *   System.out.println();
 *    		here System--> is a class
 *   
 */												
