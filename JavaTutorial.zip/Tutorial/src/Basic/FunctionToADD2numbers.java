package Basic;
import java.util.*;
public class FunctionToADD2numbers {
	//Make a function to add 2 numbers & return the sum &
	//make a function to multiply 2 numbers and return the product
	public static int CalculateSum(int a,int b) {
		int sum=a+b;
		return sum;
	}
	
	public static int CalculateProduct(int a,int b) {
		return a*b;
	}
	
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		int sum=CalculateSum(a, b);
		System.out.println(sum);
		
		 System.out.println("Product of two numbers is: "+ CalculateProduct(a, b) );
		
	}
}
