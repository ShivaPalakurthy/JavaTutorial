 package Basic;
 import java.util.*;

public class Loops {
	public static void main(String[] args) {
		/*
		 * Syntax for FOR LOOP
		 * for(initialisation ;condition;updation){
		 *				|	  		|
		 *				|	counter terminating	 			
		 *				|		condition
		 *  		   \/
		 *  	counter variable
		 *  
		 * //do something/task to be performed 
		 *
		 * }
		 * 
		 */
		
		/*  //example for FOR LOOP
		for(int i=0;i<3;i++) {
			System.out.println("Adapt.Improvise.Overcome.");
		}
		*/
		
		/*
		//Print the numbers from 0-10
			
		for(int i=0;i<=10;i++)  {    //i++=i+1;
			System.out.println(i);
		}
		*/
		
		/*
		 * WHILE loop Syntax:
		 * 			while(condition){
		 * 			//do something 
		 * 				}
		 */
		
	/*
		//Example of While loop  print numbers from 0-10
		int i=0;
		while(i<11) {
			System.out.print(i+" ");
		i++; //i++=i+1;
		}
		
		*/
		
		/*
		 * Syntax for do while
		 * 				do{
		 * 				//do something
		 * 				}while(condition);
		 * 
		 * difference between while & dowhile is we check the condition while entering
		 * into the while loop where as we check the condition in dowhile loop after 
		 * executing the loopei.e we'll check the condition at the end of the loop. so
		 * whether condition is true or not in dowhile loop, the loop gets executed 
		 * at least once.
		 */
	
		/*
		//Example of DoWhile loop  print numbers from 0-10
		int i=0;
		do {
			System.out.println(i);
			i++;
		}while(i<11);
		
		*/
	/*	
		//difference between while & Dowhile loop
		int j=12;
		while(j<11) {
			System.out.println("Hello world");
		}
		do {
			System.out.println("Hello WOrlds");
		}while(j<11);
		
		//Even though condition is false, dowhile loop got executed once, that's the difference
	*/
	
		/*
		//Print the sum of n natural numbers given n=4
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int sum=0;
		for(int i=0;i<=n;i++) {
			sum+=i;
		}
		System.out.println(sum);
		*/
		
		
		//Print the table of a number input by the user  n=2
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=1;i<11;i++) {
			System.out.println(n*i);
		}
	}
}
