package Basic;
import java.util.*;
class MyClass {

}

public class SampleClass {
	public static void 	main(String args[]) {
		ClassLoader myClassLoader= SampleClass.class.getClassLoader();
		try {
			Class myClass=myClassLoader.loadClass("MyClass");
			System.out.println("myClass.getName() = "+myClass.getName());;
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}
}
