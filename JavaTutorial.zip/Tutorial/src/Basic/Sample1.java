package Basic;

public class Sample1 {
	public static void main(String args[]) {
		//Outuput
		System.out.print("Hello World with java \n This is Shiva");  //doesn't gives next line
		System.out.println("Hii");//next code line starts with new line in output
		
		//variable
		String name="Tony Stark";
		int age=48;
		double price=25.25;
		int a=25;
		int b=10; 
		//variables value can be changed while performing actions
		b=30;
		name="iron man";
		int c=a+b;
		System.out.println(c);
		int d=b-a;
		System.out.println(d);
		int mul=a*b;
		System.out.println(mul);
	}
}

/*		Java is a TypedLanguage & it has two Data Types:
 * 			1.Primitive DataTypes				2.Non-Primitive Datatypes
 * 				byte--->1byte							String
 * 				short-->								Array
 * 				char--->2byte							Class
 * 				boolean->1byte							Object
 * 				int---->4byte							Interface
 * 				long--->8byte-->These are for 64-bit processor
 * 				float-->4byte
 * 				double-->8byte	 
 * we can customised Non-primitive Datatypes
 * 1byte=8bits
 * In Java Bodmass Doesn't work ,it works on priority * / %  > +- 
 * 
 */
