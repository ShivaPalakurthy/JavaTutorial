package Basic;

public class TimeNdSpaceComplexity {
/*
 * Time complexity:
 *  Relation between Input size & Running time (Operations)
 *  
 *  Time compllexity is usually defined in 3 way:
 *  	i. Best Case-->Denoted by ohm symbol Ω
 *  	ii.Average Case-->denoted by teta θ
 *  	iii.worst Case-->denoted by O.
 *  
 *  For example, to find number 1 from 12345 find the time complexity at different cases
 *  
 *  i.Best Case:Ω(1)  
 *  		 the best case would be getting 1 at the start. So time complexity will become
 *  Ω(1).
 *  ii.Average Case:
 *  	say finding 1 in 21345 or
 *  					23415		here we'll get by 1+2+3+4+5
 *  												  ---------
 *  													 5
 * 							=n(n+1)/2n=(n+1)/2
 * so average case time complexity will be   	θ((n+1)/2)
 * 
 * iii.Worst Case:
 *  in worst case we'll get 1 at last of the numbers 54321. so we've to do 'n' times
 *  operations.
 *  so the worst case time complexity will be O(n)
 *  
 *  
 *  In general, Worst case time complexity is considered
 *  
 *  .To know more about Time complexity focus on Mastr's theorem
 *  
 *  
 *  O(n)>O(n^2)>O(n^3)--> Order in which worst case time complexity will be best.
 *  */
}
