package Basic;
import java.util.*;
public class ConditionalStatements {
/*				IF CONDITION SYNTAX
 * if(condition){
 * stat1;
 * stat2;
 * }
 * else{
 * statement3;
 * statement 4;
 * }
 * 
 *	 
 */
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		/*  //checking whether given age is >18 or not
		int age=sc.nextInt();
		if(age>18) {
			System.out.println("Adult");
		}else {
			System.out.println("Not an adult");
		}
		 */
		
		/*
		//Finding Odd & Even Number
		int x=sc.nextInt();
		
		if(x%2==0) {
			System.out.println("Even");
		}else {
			System.out.println("Odd");
		}
		*/
		
		
	/*	// take input a&b i.a=b  equal ii.a>b 	a is greater  iii.a<b 	a	is lesser
		int a=sc.nextInt();
		int b=sc.nextInt(); */
		
	/* 
		if(a==b) {
			System.out.println("Equal");
		}else {
			if(a>b) {
				System.out.println("a is greater");
			}else {
				System.out.println("a is lesser");
			}
		}
		
		 */
		 
		/* //another way	
		if(a==b) {
			System.out.println("Equal");
		}
		else if(a>b) {
				System.out.println("a is greater");
			}
		else {
				System.out.println("a is lesser");
			}
		 */
		
	/*	//Solving this problem by using SWITCH statement written below this code
	 * 	//Print the Greeting

		int button=sc.nextInt();
		if(button==1) {
			System.out.println("Hello");
		}else if(button==2) {
			System.out.println("Namaste");
		}else if(button==3){
			System.out.println("Bonjour");
		}else {
			System.out.println("Invalid button");
		}
			 */
		
		
		//By USing Switch Statement
		/*
		 * 				SYNTAX OF SWITCH STATEMENT
		 * switch(variable){
		 * case 1: Statement 1;				// case 'a': =>for characters in switch 
		 * 			break;
		 * case 2: Statement 2;
		 * 			break;
		 * case 3: Statement 3;
		 * 			break;
		 * default:statement 4;
		 * }
		 */
		
		/*
		 * If there is no break after a case ,then all the next cases will be implemented
		 * until the break is reached. so it is necessary to mention break after every
		 * case.
		 */
		int button=sc.nextInt();
		switch(button) {
		case 1:System.out.println("Hello");
		break;
		case 2:System.out.println("Namaste");
		break;
		case 3:System.out.println("Bonjour");
		break;
		default:System.out.println("Invalid Number");
		}
		
	}
}
