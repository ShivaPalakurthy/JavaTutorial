package Basic;

import java.nio.file.spi.FileSystemProvider;

public class patterns {
	public static void main(String args[]) {
		/*
		//solid rectangle
		int n=4;
		int m=5;
		//outer loop
		for(int i=1;i<=n;i++) {
				//inner loop
			for(int j=1;j<=m;j++) {
				System.out.print("* ");
			}System.out.println();
		} 
		*/
		
		/*
		
		//hollow Rectangle
		//we'll get start where i=1;j=1;i=n;j=n
		int n=4;
		int m=5;
		//outer loop 
		for(int i=1;i<=n;i++) {
			//inner loops
			for(int j=1;j<=m;j++) {
				//cell->(i,j)
				if(i==1 || j==1 ||i==n ||j==m) {
					System.out.print("* ");
				}
				else {
					System.out.print("  ");
				}
			}System.out.println();
		}
		*/
	
		
		/*
		//Half pyramid 		n=4  here row number will become total columns
		
		int n=4;
		for(int i=1;i<=n;i++) {
			//inner loop
			for(int j=1;j<=i;j++) {
			System.out.print("* ");
				}System.out.println();
		} 
		*/
		
		
		/*
		//Inverted half Pyramid
		int n=4;
		for(int i=n;i>=1;i--) {
			for(int j=1;j<=i;j++) {
				System.out.print("* ");
			}System.out.println();
		}
		*/
	/*	
		//Inverted half Pyramid rotated by 180 degree
		int n=4;
		//outer loop
		for(int i=1;i<=n;i++) {
			  //inner loop ->printing spaces n-i
			for(int j=1;j<=n-i;j++) { 
				System.out.print("  ");
			}
			 //inner loop ->printing i stars
			for(int j=1;j<=i;j++) {		
				System.out.print("* ");
			}System.out.println();
			
		  }
		  */ 
		
		/*
		 * Print the Pattern halfpyramid with numbers		where n=5
		 * 	1 
		   	1 2 
			1 2 3 
			1 2 3 4 
			1 2 3 4 5 
		
		 *
		 */
		
		/*
		int n=5;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j+" ");
			}System.out.println();
		}
		*/
		
		/*
		 * Inverted half pyramid with numbers n=5
			1 2 3 4 5 
			1 2 3 4 
			1 2 3 
			1 2 
			1 
 
		 */
		
		/*
		int n=5;
		//outer loop
		for(int i=1;i<=n;i++) {
			//inner loop 
			for(int j=1;j<=n-i+1;j++) {
				System.out.print(j+" ");
			}System.out.println();
		}
		*/
		/*
		//Floyd's Triangle			n=5 
		int n=5;
		int number=1;
		//outer loop
		for(int i=1;i<=n;i++) {
			//inner loop 
			for(int j=1;j<=i;j++) {
				System.out.print(number+" ");
				number++;		//number++=number+1;
			}System.out.println();
		}
		*/
		
		/*0-1 Triangle  		n=5
		 * Try to visualise them in matrix form and see the cell values of each number
		 * by observing i+j values of each cell you'll get to know which cell gets '0'
		 * and which cell gets '1'
		 * 
		 * if i+j=odd then we'll get 0
		 * 	  i+j=even then we'll get 1
		 */
		int n=5;
		//outer loop
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=i;j++) {
				int sum=i+j;
				if(sum%2==0) {	//even
					System.out.print("1 ");
				}
				else { 	//odd
					System.out.print("0 ");
				}
			}System.out.println();
			
		}
	}
}
