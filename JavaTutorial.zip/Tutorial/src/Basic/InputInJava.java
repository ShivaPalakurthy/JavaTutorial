package Basic;
import java.util.*;
public interface InputInJava {
		public static void main(String args[]) {
			//Input
			Scanner sc=new Scanner(System.in);
			String name=sc.next(); /*The sc object in scanner class has a function 
			 						next with this help we'll take input string value
			 						
			 						*Pass Input as GLOBAL SOLUTIONS & see output 
			 						*we will get only GLOBAL as Output because when
			 						*we use .next() function it will only take one 
			 						*tokeni.e only single word is taken by using .next()
			 						*
			 						*If we want to take input as multiple tokens/multiple
			 						*words we need to use sc.nextLine()*/
			String name1=sc.nextLine();
						//nextInt();-->to take integer type as input
						//nextFloat();-->to take float type as input
						//you can also take double long etc
		System.out.println(name);
		System.out.println(name1);
		}
}
/* From import java.util.*; package we have imported Scanner class
 * System.in-->used for taking input
 */
