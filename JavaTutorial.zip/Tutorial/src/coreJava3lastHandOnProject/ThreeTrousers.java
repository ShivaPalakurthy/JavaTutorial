package coreJava3lastHandOnProject;
//CoreJavaClass3Notes last hands on problem code. start from clothing.java , shirt.java,trouser.java in this package
//this is the main class for 3trousers
public class ThreeTrousers {
 public static void main(String args[]) {
		//public Trouser(int id, double price, char color, int size, int fit, String gender) 
//from Trouser.java seeing the constructor parameters give the values accordingly
	 Trouser tr1=new Trouser(123,243.27,'R',42,8,"Male");
	 Trouser tr2=new Trouser(127,799.28,'Y',44,9,"Female");	
	 Trouser tr3=new Trouser(131,982.29,'G',46,10,"Other");
	 System.out.println("1st Trouser Object: "+ tr1.getId()+"/"+tr1.getPrice()+"/"+tr1.getColor()+"/"+
			 tr1.getSize()+"/"+tr1.getFit()+"/" + tr1.getGender());
	 System.out.println("1st Trouser Object: "+ tr2.getId()+"/"+tr2.getPrice()+"/"+tr2.getColor()+"/"+
			 tr2.getSize()+"/"+tr2.getFit()+"/" + tr2.getGender());
	 System.out.println("1st Trouser Object: "+ tr3.getId()+"/"+tr3.getPrice()+"/"+tr3.getColor()+"/"+
			 tr3.getSize()+"/"+tr3.getFit()+"/" + tr3.getGender());
			 
}
}
