package coreJava3lastHandOnProject;


//CoreJavaClass3Notes last hands on problem code. start from clothing.java , shirt.java in this package
public class Trouser extends Clothing{
	private int fit;
	private String gender;
	
	
	//Creating constructor : :source-->Generate constructor using fields--> select Clothing(int,double,char,int) from
									//top(Select super constructor to invoke)-->select all -->Generate.
	public Trouser(int id, double price, char color, int size, int fit, String gender) {
		super(id, price, color, size);//using super constructor to call base class CLothing
		this.fit = fit;
		this.gender = gender;
	}


	public int getFit() {
		return fit;
	}


	public void setFit(int fit) {
		this.fit = fit;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}
	
}


