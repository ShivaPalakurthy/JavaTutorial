package DomesticAirReservationSystem;

import java.util.LinkedList;

public interface FlightDetailsDAO {
	boolean add(FlightDetails F);

	boolean delete(int id);

	boolean update(FlightDetails F);

	FlightDetails get(int id);

	default FlightDetails[] getAllArray() {
		return null;
	}

	default LinkedList<FlightDetails> getAllList() {
		return null;
	}
}
