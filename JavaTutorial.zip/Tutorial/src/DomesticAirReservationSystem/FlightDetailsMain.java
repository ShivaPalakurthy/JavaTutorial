package DomesticAirReservationSystem;

import java.util.Scanner;

public class FlightDetailsMain {
	public static void main(String args[]) {
		FlightDetailsMain fdm = new FlightDetailsMain();
		fdm.Choose();
	}

	public void Choose() {
		System.out.println("				Hello Admin");
		System.out.println("Choose Action on Flight Details to be performed based on Arrays or Collections");
		System.out.println("Type 1- Based on ArrayList");
		System.out.println("Type 2- Based on Collections");
		System.out.println("Type 3- Based on JDBC Connection");
		System.out.println("Type 4- Exit the Application ");
		Scanner sc = new Scanner(System.in);
		int choose = sc.nextInt();
		switch (choose) {
		case 1:
			System.out.println("			Welcome To Domestic AirLine Reservation System \n");
			System.out.println("Here Action on Flight Details will be performed by using Arrays");
			FlightDetailsArrImpl flightdetailsArrImpl = new FlightDetailsArrImpl();
			flightdetailsArrImpl.getIntoAction();
			break;
		case 2:
			System.out.println("			Welcome To Domestic AirLine Reservation System \n");
			System.out.println("Here Action on Flight Details will be performed by using Collections");
			FlightDetailsCollecImpl flightdetailsCollImpl = new FlightDetailsCollecImpl();
			flightdetailsCollImpl.getIntoAction();
			break;
		case 3:
			System.out.println("			Welcome To Domestic AirLine Reservation System \n");
			System.out.println("Here Action on Flight Details will be performed by using JDBC Connection");
			FlightDetailsDAOJDBCImpl flightdetailsDAOJDBCImpl = new FlightDetailsDAOJDBCImpl();
			flightdetailsDAOJDBCImpl.getIntoAction();
		case 4:
			System.out.println("Turning of the System...");
			System.out.println("See you again Admin,Bye...");
			break;

		default:
			System.out.println("\n" + "Invalid Choice." + "\n");
		}
	}

}
