package DomesticAirReservationSystem;

import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.Scanner;


public class FlightDetailsCollecImpl implements FlightDetailsDAO {
	LinkedList<FlightDetails> FDlist = new LinkedList<FlightDetails>();

	int Flight_Detail_ID;
	int Flight_ID;
	String Flight_Company;
	String Flight_Src;
	String Flight_Desc;
	Timestamp Travel_Date_Time;
	int Seat_Available_F;
	int Seat_Available_B;
	int Seat_Available_E;
	float Price_First;
	float Price_Economy;
	float Price_Business;
	int Dd, Dm, Dy, Th, Tm; // For Timestamp Date,month,year,hour,month
	Scanner sc = new Scanner(System.in);

	@Override
	public boolean add(FlightDetails obj) {
		FDlist.add(obj);
		return true;
	}

	@Override
	public boolean delete(int id) {
		for (FlightDetails fd : FDlist) {
			if (fd.getFlight_ID() == id)
				return FDlist.remove(fd);
		}
		return false;
	}

	@Override
	public boolean update(FlightDetails F) {
		for (FlightDetails fd : FDlist) {
			if (fd.getFlight_ID() == F.getFlight_ID()) {
				FDlist.set(FDlist.indexOf(fd), F);
				return true;
			}
		}
		return false;
	}

	@Override
	public FlightDetails get(int id) {
		for (FlightDetails fd : FDlist) {
			if (fd.getFlight_ID() == id) {
				return fd;
			}
		}
		return null;
	}

	@Override
	public LinkedList<FlightDetails> getAllList() {
		return FDlist;
	}

	public void getIntoAction() {

		System.out.println("Type 1 - Add Flight details into the server ");
		System.out.println("Type 2 - Update Flight details into the server ");
		System.out.println("Type 3 - Delete Flight schedules from the server");
		System.out.println("Type 4 - Get All the flight details from the server");
		System.out.println("Type 5 - Get Flight details by Flight_ID from the Server");
		System.out.println("Type 6 - Exit");
		System.out.println("Choice: ");

		int selection = sc.nextInt();
		switch (selection) {
		case 1:
			addFlightDetails();
			getIntoAction();
			break;
		case 2:
			updateFligtDetails();
			getIntoAction();
			break;
		case 3:
			deleteFlightSchedules();
			getIntoAction();
			break;
		case 4:
			getAllFlightDetails();
			getIntoAction();
			break;
		case 5:
			getFlightDetailByID();
			getIntoAction();
			break;
		case 6:
			System.out.println("Closing the Collection Implementation Page Admin...");
			System.out.println("Redirecting to main page...");
			FlightDetailsMain fdm = new FlightDetailsMain();
			fdm.Choose();
			break;
		default:
			System.out.println("\n" + "Invalid Choice." + "\n");
			getIntoAction();
		}
	}

	public void addFlightDetails() {
		try {
			System.out.println("Enter the Flight_Detail_ID");
			Flight_Detail_ID = sc.nextInt();
			System.out.println("Enter the Flight_ID");
			Flight_ID = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the Flight Company name");
			Flight_Company = sc.nextLine();
			System.out.println("Enter the Flight Source Name");
			Flight_Src = sc.nextLine();
			System.out.println("Enter the Flight Destination Name");
			Flight_Desc = sc.nextLine();
			System.out.println("Enter the Travel Date");
			Dd = sc.nextInt();
			System.out.println("Enter the Travel Month");
			Dm = sc.nextInt();
			System.out.println("Enter the Travel Year");
			Dy = sc.nextInt();
			System.out.println("Enter the Travel Hour");
			Th = sc.nextInt();
			System.out.println("Enter the Travel Minutes");
			Tm = sc.nextInt();
			Travel_Date_Time = new Timestamp(Dy, Dm, Dd, Th, Tm, 0, 0);
			System.out.println("Enter Seat Available in First Class");
			Seat_Available_F = sc.nextInt();
			System.out.println("Enter Seat Available in Business Class");
			Seat_Available_B = sc.nextInt();
			System.out.println("Enter Seat Available in Economy Class");
			Seat_Available_E = sc.nextInt();
			System.out.println("Enter Ticket Price in First Class");
			Price_First = sc.nextFloat();
			System.out.println("Enter Ticket Price in Economy Class");
			Price_Economy = sc.nextFloat();
			System.out.println("Enter Ticket Price in Business Class");
			Price_Business = sc.nextFloat();
			add(new FlightDetails(Flight_Detail_ID, Flight_ID, Flight_Company, Flight_Src, Flight_Desc,
					Travel_Date_Time, Seat_Available_F, Seat_Available_B, Seat_Available_E, Price_First, Price_Economy,
					Price_Business));
			System.out.println("			Flight Details Added Sucessfully");
		} catch (Exception e) {
			System.out.println("		Oops! Flight Details are not Added ");
		}

	}

	public void updateFligtDetails() {
		try {
			System.out.println("Enter the Flight_Detail_ID of the Flight which you want to update");
			Flight_Detail_ID = sc.nextInt();
			System.out.println("Enter the Flight_ID of the Flight which you want to update");
			Flight_ID = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the Flight Company name of the Flight which you want to update");
			Flight_Company = sc.nextLine();
			System.out.println("Enter the Flight Source Name of the Flight which you want to update");
			Flight_Src = sc.nextLine();
			System.out.println("Enter the Flight Destination Name of the Flight which you want to update");
			Flight_Desc = sc.nextLine();
			System.out.println("Enter the Travel Date of the Flight which you want to update");
			Dd = sc.nextInt();
			System.out.println("Enter the Travel Month of the Flight which you want to update");
			Dm = sc.nextInt();
			System.out.println("Enter the Travel Year of the Flight which you want to update");
			Dy = sc.nextInt();
			System.out.println("Enter the Travel Hour of the Flight which you want to update");
			Th = sc.nextInt();
			System.out.println("Enter the Travel Minutes of the Flight which you want to update");
			Tm = sc.nextInt();
			Travel_Date_Time = new Timestamp(Dy, Dm, Dd, Th, Tm, 0, 0);
			System.out.println("Enter Seat Available in First Class of the Flight which you want to update");
			Seat_Available_F = sc.nextInt();
			System.out.println("Enter Seat Available in Business Class of the Flight which you want to update");
			Seat_Available_B = sc.nextInt();
			System.out.println("Enter Seat Available in Economy Class of the Flight which you want to update");
			Seat_Available_E = sc.nextInt();
			System.out.println("Enter Ticket Price in First Class of the Flight which you want to update");
			Price_First = sc.nextFloat();
			System.out.println("Enter Ticket Price in Economy Class of the Flight which you want to update");
			Price_Economy = sc.nextFloat();
			System.out.println("Enter Ticket Price in Business Class of the Flight which you want to update");
			Price_Business = sc.nextFloat();
			update(new FlightDetails(Flight_Detail_ID, Flight_ID, Flight_Company, Flight_Src, Flight_Desc,
					Travel_Date_Time, Seat_Available_F, Seat_Available_B, Seat_Available_E, Price_First, Price_Economy,
					Price_Business));
			System.out.println("			Flight Details Updates Sucessfully");
		} catch (Exception e) {
			System.out.println("		Oops! Flight Details are not Updated");
		}
	}

	public void deleteFlightSchedules() {
		System.out.println("Enter the flight Id");
		Flight_ID = sc.nextInt();
		try {
			if (delete(Flight_ID)) {
				System.out.println("               Flight details are deleted Successfully");
			} else {
				System.out.println("Sorry, Flight_ID can't be deleted now or Database is empty");
			}
		} catch (Exception e) {
			System.err.println(e); // use it To print the error if needed
		}
	}

	public void getAllFlightDetails() {
		LinkedList<FlightDetails> fdl = getAllList();
		for (FlightDetails fd : fdl) {
			System.out.println(fd);
		}
	}

	public void getFlightDetailByID() {
		System.out.println("Enter the flight Id");
		Flight_ID = sc.nextInt();
		try {
			System.out.println(get(Flight_ID));
		} catch (Exception e) {
			// System.err.println(e); //use it To print the error if needed
			System.out.println("Sorry FLight_ID is not present in the Database or the Database is empty");
		}
	}

}
