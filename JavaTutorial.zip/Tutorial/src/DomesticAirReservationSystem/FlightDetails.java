package DomesticAirReservationSystem;

import java.sql.Timestamp;

public class FlightDetails {
	private int Flight_Detail_ID;
	private int Flight_ID;
	private String Flight_Company;
	private String Flight_Src;
	private String Flight_Desc;
	private Timestamp Travel_Date_Time;
	private int Seat_Available_F;
	private int Seat_Available_B;
	private int Seat_Available_E;
	private float Price_First;
	private float Price_Economy;
	private float Price_Business;

	@Override
	public String toString() {
		return "FlightDetails [Flight_Detail_ID=" + Flight_Detail_ID + ", Flight_ID=" + Flight_ID + ", Flight_Company="
				+ Flight_Company + ", Flight_Src=" + Flight_Src + ", Flight_Desc=" + Flight_Desc + ", Travel_Date_Time="
				+ Travel_Date_Time + ", Seat_Available_F=" + Seat_Available_F + ", Seat_Available_B=" + Seat_Available_B
				+ ", Seat_Available_E=" + Seat_Available_E + ", Price_First=" + Price_First + ", Price_Economy="
				+ Price_Economy + ", Price_Business=" + Price_Business + "]";
	}

	public FlightDetails(int flight_Detail_ID, int flight_ID, String flight_Company, String flight_Src,
			String flight_Desc, Timestamp travel_Date_Time, int seat_Available_F, int seat_Available_B,
			int seat_Available_E, float price_First, float price_Economy, float price_Business) {
		super();
		Flight_Detail_ID = flight_Detail_ID;
		Flight_ID = flight_ID;
		Flight_Company = flight_Company;
		Flight_Src = flight_Src;
		Flight_Desc = flight_Desc;
		Travel_Date_Time = travel_Date_Time;
		Seat_Available_F = seat_Available_F;
		Seat_Available_B = seat_Available_B;
		Seat_Available_E = seat_Available_E;
		Price_First = price_First;
		Price_Economy = price_Economy;
		Price_Business = price_Business;
	}

	public int getFlight_Detail_ID() {
		return Flight_Detail_ID;
	}

	public void setFlight_Detail_ID(int flight_Detail_ID) {
		Flight_Detail_ID = flight_Detail_ID;
	}

	public int getFlight_ID() {
		return Flight_ID;
	}

	public void setFlight_ID(int flight_ID) {
		Flight_ID = flight_ID;
	}

	public String getFlight_Company() {
		return Flight_Company;
	}

	public void setFlight_Company(String flight_Company) {
		Flight_Company = flight_Company;
	}

	public String getFlight_Src() {
		return Flight_Src;
	}

	public void setFlight_Src(String flight_Src) {
		Flight_Src = flight_Src;
	}

	public String getFlight_Desc() {
		return Flight_Desc;
	}

	public void setFlight_Desc(String flight_Desc) {
		Flight_Desc = flight_Desc;
	}

	public Timestamp getTravel_Date_Time() {
		return Travel_Date_Time;
	}

	public void setTravel_Date_Time(Timestamp travel_Date_Time) {
		Travel_Date_Time = travel_Date_Time;
	}

	public int getSeat_Available_F() {
		return Seat_Available_F;
	}

	public void setSeat_Available_F(int seat_Available_F) {
		Seat_Available_F = seat_Available_F;
	}

	public int getSeat_Available_B() {
		return Seat_Available_B;
	}

	public void setSeat_Available_B(int seat_Available_B) {
		Seat_Available_B = seat_Available_B;
	}

	public int getSeat_Available_E() {
		return Seat_Available_E;
	}

	public void setSeat_Available_E(int seat_Available_E) {
		Seat_Available_E = seat_Available_E;
	}

	public float getPrice_First() {
		return Price_First;
	}

	public void setPrice_First(float price_First) {
		Price_First = price_First;
	}

	public float getPrice_Economy() {
		return Price_Economy;
	}

	public void setPrice_Economy(float price_Economy) {
		Price_Economy = price_Economy;
	}

	public float getPrice_Business() {
		return Price_Business;
	}

	public void setPrice_Business(float price_Business) {
		Price_Business = price_Business;
	}

}
