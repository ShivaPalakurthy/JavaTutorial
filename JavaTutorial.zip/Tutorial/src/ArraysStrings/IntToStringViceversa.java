package ArraysStrings;

public class IntToStringViceversa {
public static void main(String args[]) {
	
	//ParseInt Method Of Integer Class
	String name="123456";
	int number=Integer.parseInt(name);
	System.out.println(number);
	
	//ToStringMethod of String Class
	
	int num=123;
	String value=Integer.toString(num);
	System.out.println(value);
	System.out.println(value.length());
}
}