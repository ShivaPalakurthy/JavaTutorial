package ArraysStrings;
import java.util.*;
public class Array1 {
 public static void main(String args[]) {
	 Scanner sc=new Scanner(System.in);
	 int size=sc.nextInt();
	 int numbers[]=new int[size];
	 
 
	 for(int i=0;i<size;i++)
	 {
		 numbers[i]=sc.nextInt();
	 }
	 
	 for(int i=0;i<size;i++)
		 System.out.println(numbers[i]);
 }
}


/* When we declare an array and dont initialise (not assigning the value ) , then in java automatic initialization
 * happens with null values by default where as in C++ automatic initialization happens with garbage value.
 * when ever we make a variable in memory, it'll take space in memory by that variable name and stores null value 
 * by default.By default, if the variable is object it'll store null value, for int -->0; for float-->0.0;
 * boolean-->false; string-->""(empty string); for int array-->it'll store 0 in evry int (every int variable)	
 * */ 
 