package ArraysStrings;

public class stringBuilders {
public static void main(String args[]) {
		
		StringBuilder sb=new StringBuilder("Tony");
		System.out.println(sb); 
		// Refer video 12 on how String & String Builder gets stored in memory 
		//char at index 0
		System.out.println(sb.charAt(0));
		 
		
	//	set charcter at index 0
		 sb.setCharAt(0,'P');
		 System.out.println(sb);
		 
	//insert character to make PONY to Spony
		 sb.insert(0,'S');
		 System.out.println(sb);
		 
		//insert character to make Spony to Sponny
		 sb.insert(3,'n');
		 System.out.println(sb);
		 
		 //deleting a chaaracter ex. del the extra n
		 
		 sb.delete(3, 4);  //--> ending index is non inclusive
		 System.out.println(sb); 
		 
	}

}