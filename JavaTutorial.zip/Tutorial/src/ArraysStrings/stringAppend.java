 package ArraysStrings;

public class stringAppend {

	public static void main(String args[]) {
		StringBuilder sb=new StringBuilder("H");
		sb.append("e");  /*  Append means adding element in last letter
						for strings we'll do str=str+"e"; 
						-->in this case for every statment there will
						 new string in heap memory whereas in 
						 String builder the same string will undergo 
						 changes as a result time consumptin is  less */
		
		sb.append("l");
		sb.append("l");
		sb.append("o");
		System.out.println(sb);
		System.out.println(sb.length());
	}
}