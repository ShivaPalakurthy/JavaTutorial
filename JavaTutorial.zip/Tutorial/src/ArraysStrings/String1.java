package ArraysStrings;
import java.util.*; //pronounced as java.util.all
public class String1 {
	public static void main(String args[]) {
	/*	 //String Declaration
		String Name="Tony";
		String fullName="Tony Stark";
		String Sentence=" My name is Tony Stark"; */
		
	
	/*	//Taking Input from strings
		Scanner sc= new Scanner(System.in);
		String name=sc.next(); //print single word
		System.out.println("Your name is " + name);
		String name1=sc.nextLine(); //prints full line
		System.out.println("Your name is " + name1);  */
		
		// -->concatenation- adding two strings
		
		String firstName="Shiva";
		String lastName="Palakurthy";
		String fullName =firstName+ " " +lastName;
		System.out.println(fullName);
		System.out.println(fullName.length());//gives length of string
		
		// charAt--> prints individual character in a string
		for(int i=0;i<fullName.length();i++) 
			System.out.println(fullName.charAt(i));
			
			
			//comparing Strings
			
			String name1="Tony";
			String name2="Tony";
			
			// compareTo -->keyword to compare given Strings and has 3 case
			//case1. s1>s2:+ve value;
			//case2. s1==s2:0;
			//case3. s1<s2:-ve value;
			
			if(name1.compareTo(name2)==0) {
				System.out.println("Strings are equal");
			}
			else
				System.out.println("Strings are not equal");
		
			
			
			// Reason why we use compareTo function other than equal to function to check whether strings are equal:-
			  if(new String("Tony")==new String("Tony")) { 
				System.out.println("Strings are equal");
			}
			else
				System.out.println("Strings are not equal");
		/**
		 * here we'll get Strings are not equal because in Java, Strings will be like objects, the functioning of
		 * normal primitive datatypes in memory is different from how objects function in memory */	 
			
			//Substring   substring(beg index,ending index)
			String sentence="My name isi Tony";
			String name3=sentence.substring(11,sentence.length());
			String sentence1="TonyStark";
			String name4=sentence1.substring(4); //by default goes till end if ending index is not given
			String name5=sentence1.substring(0,4);//prints value of (ending indexvalue-1) i.e here 0 to index 3 values will be printed
			System.out.println(name3);
			System.out.println(name4);
			System.out.println(name5);
		/*Strings are inmutable--->> i.e once you created a string in 
		 the memory then you can't change thhat string and 
		 if you want to modify it then we need to create another string . In order to perform modification we need
		  an optimmised string class and therefore that class is String Builder. String Builder can perform add,
		  del and any operation in string with less time. */
		
	}

}