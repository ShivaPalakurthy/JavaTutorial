package AdvancedJava;
/*
 * In SpringFrameWork we disscussed about 3 tier application but when the web development 
 * started the most popular concept which came was MVC (M-Model,V-view,C-controller). MVC run
 * the application by basically the controller is receive the request which is comming from
 * the browser then the controller will have the knowledge of where the business logic for that
 * particular request will be residing.so the controller is going to invoke the corresponding model
 * which is required to execute the business logic of the request  & the controller will
 * also have the knowledge of what response page(view) to be sent back to the user
 * The most popular implementation of MVC is provided by the Spring-Spring is the most
 * popular framework
 * 								 --2-->[Handler Mapping]
 *  							/ 				
 *  		1	  |Dispatcher |/---------3--------->|Controller|
 *  Request------>|Servelet	  |<---------M&V----4---|	       |
 * 				  |			  |\---------5----------->[view resolver]
 * 								\
 * 								 ---------6---------->[View]
 * 
 * 1.Request comes from the web browser & the spring has the very first welcome servlet
 * which is called dispatcher servlet.Any request which is coming to the spring enabled
 * web application will first hit dispatcher servelet, Once the request comes to the 
 * dispatcher servlet, the dispatcher servlet has all the knowledge of all the controllers,all the
 * view resolvers,all the views, the handler mappings
 * 2.Once the request comes to the dispatcher servlet ,it looks at the path & finds the right handler
 * for it. the way it does by using the handler mapping component or handler mapping logic
 * which is provided out of the box by spring framework.so the handler mapping logic will
 * tell the dispatcher servelet which particular controller is going to process the request
 * which is comming because every request will have a  different controller return so whatever
 * the type of request is ,whatever the path of the request is based on that,the dispatcher
 * servelet is going to find the particular controller.
 * 3.Once the controller is found, the controller will have the knowledge of right model (model is nothing but
 * the java class holding the particular business logic for this particular request ) to invoke
 * the java class get all the  business logic processed 
   4.then it is going to return a model & view object for that particular request, the view in 4 is simply 
   pointing to the UI response which we are going to send back to the user,it can be a jsp page,it can be a
   html page,it can be a any other view technology.so anything which is going to be rendered on the web application
   is view,The controller is goining to send both the model & view to the dispatcher servelet
   5.The dispatcher servelet takes the view part of it & GO TO the another component which is 
   again provided by spring which is called view resolver .The view resolver will hvae the
   knowledge to see actual jsp or template to invoke for the view value comming from the controller so based on the
   value which is returned by the controller the view resolver is going to return,the right page mapping.
   6.Once the dispatcher servelet know the mapping it is going to invoke that page by calling the view component
   
   start.pring.io-->to go to spring initialiser
   
   
   Maven is a dependency management tool which is used to download any kind of jars for your application
   Open spring initialiser
   1.choose maven as project & java as language , keep latest version for the spring boot
   you can provide group,artifact& name & also you can provide a welcome package name whatever suits you
   choose how you'll run your application whether by jar file or by war(web archive) file .Here we choose jar filein
   the packaging mode & choosed java as latest version .AFter that generate , then
   import that project as a normal project in the eclipse IDE
   
   Extract the folder from the zip file & from eclipse import it  (import-->maven-->Existing Maven Projects )
 	here it got impported with the Initial as project name
 	Initial project is a maven project & in every maven project we have pom.xml file which lists down all
 	the dependencies need to have
 	
 	In pox.xml , in the dependencies section we will see all the dependecies or all the jars which are 
 	required by the spring application to run successfully
 	First dependecy is  spring-boot-starter-thymeleaf --->thymeleaf is basically view technology similar to jsp or similar to servelets & we 
 	can you these tymeleaf templates to render web pages for our spring mvc application
   2nd dependency spring-boot-starter-web-->starter web will enable your application to become a web application
   3.spring-boot-devtools-->Helps you deploy the project at run time automatically without restarting the server,because web application will
   run on the web server
   4.spring-boot-starter-test we have to exclusions & write <artifactId>junit-vintage-engine</artifactId>--> it is for unit tests
 
 We have plugins which will allow this particular project to run  in a single command
 
 In src/main/java we have two classes 1. main class which have public static void method & this will be entry point of the spring
 application & then we have a controller class 
 we have src/main/resources-->where we have view technology data available & it also hasa
 application.properties which has nothing but we can use this file to supply environment specific properties for the development environment or
 the testing environment or the real production environment
 If we have unit tests it will go under src/test/java
 *
 *Once we hit a particular url then we need to create the controller for that url mapping 
 *so we have created a greeting controller & the way we create at controller by using annotation @Controller
 *And the movement you put the annotation That class will also be registered with the dispatcher servlet.
 *The way you can receive the requests to the cotroller is by providing the exact url mapping So if somebody
 *runs the initial application & says /greeting than  public String greeting method shoul be invoked & how we define that is by the
 *@GetMapping annotation i.e @GetMapping("/greeting") use the GetMapping annotation to provide the url path whenever somebody
 *invokes this url path that method would be called & when that method is getting called  that url can also accept
 *some Query parameters we call that as Request parameters(@RequestParam) in the spring language  so we can use the 
 *request parameters as anotation to wide a place holder for the varible for the which the value will be supplies in the url we do it by ?atribute name (/greeting?name)
 * The second argument which our methods which are intercepting the request should have is the model argument
	
 */

public class SpringMVCInJava {
	
}
