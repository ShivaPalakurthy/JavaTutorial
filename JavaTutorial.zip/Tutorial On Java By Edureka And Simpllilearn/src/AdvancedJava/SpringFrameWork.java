package AdvancedJava;
/*
 * In enterprise level application we have 3 different parts as follow
 * 	
 * 					 |			   |-->Frontend-->HTML,JAvascript,Java EE			
 *   FrameWork   <---| 3 tier	   |-->BackEnd-->Java core -->business logic
 *   [spring]	     |architecture |-->Database-->used to store data
 *   
 *   We need to do intergration & more different programming & concepts to build an complete
 *   enterprise grid application & if we try to build all of this by ourselves it gonna take 
 *   lot of time thats why we have frameworks to provide the structure to these 3 layers/architecture
 *   Spring is the most famous framework
 *   
 *   		Architecture on how a web application works
 *   |HTML| calls |		   |transfers control to |Business|transfers control to |Data Layer	  |transfers control to 
 *   | JS | --->  |Endpoint|   --------------->  |Layer	  |   --------------->  | or DAO layer|   --------------->  |Database|
 *   Browser	 Backend Layer		core business logic return 
 *    			
 *    			---------------------------------------------------------------------------------------------------------------
 *    					Spring provide support for all of this parts -^
 *    
 *    Why Spring:
 *    Spring is everywhere
 *    Spring is flexible-Spring Framework’s Inversion of Control (IoC) and Dependency Injection 
 *    					(DI) features provide the foundation for a wide-ranging set of features 
 *    					 and functionality.
 *    Spring is fast
 *    Spring is productive
 *    Spring is secure
 *    Spring is supportive
 * *   
 *   		Architecture on how a web application works
 *   |HTML| calls |		   |transfers control to |Business|transfers control to |Data Layer	  |transfers control to 
 *   | JS | --->  |Endpoint|   --------------->  |Layer	  |   --------------->  | or DAO layer|   --------------->  |Database|
 *   Browser	 Backend Layer		core business logic return 
 *    			
 *    			---------------------------------------------------------------------------------------------------------------
 *    					Spring provide support for all of this parts -^
 *     
 *   Core Component of Spring framework: Spring support inversion of control by providing
 *   Inversion of Control(IOC) container
 *   
 *   If we created a student class & we went to main class & we initialised the student object
 *   so the responsibility of Student object lies with the Student class itself. so student class
 *   has to be explicitly initialised to having the object of a student.This creates a problem
 *   when we start dealing with enterprise grid framework as you might need to create lot of objects on
 *   the fly whenever the end point is talking to the business layer,if business layer classes are talking
 *   to the database class. so when the business layer classes needs to talk to the datalayer classes,the data
 *   layer classes need to have an object as the communication happens between the objects. so who create those
 *   objects? if every time the data access object is being called when businne layer wants to talk to data layer,
 *   when end point talks to the business class we ask the business layer to create objects ,it becomes lot of 
 *   painful process as everytime u have to create objects so what springs says is, invert the control of creating the object
 *   i.e lets not give the responsibilty of creating the objects to the class,lets give the responsibility to the framework
 *   so the framework.so the framework will be responsible for creating the objects of a class & its not the class who will be 
 *   responsible creating its own objects.So generally outside the framework, class is responsible for creating the 
 *   object but in  spring it inverts this responsibility to framework that's why we call this inveresion of control, the control 
 *   is inverted & now its framework responsibility to create the objects
 *   Dependency Injection is an Implementation of the IOC concept.so using springs dependecny injection mechanism we can inject 
 *   the object of any class into any class.Once we do that spring dependency is going to use the inversion of control (IOC) concept 
 *   & create the object.
 *   
 *   Resources module will provide a way to refer different files & properties if we want.
 *   Validation module provides different validation concepts because once we receive the data
 *   		we might need to run lot of validation & writing the validation will be painful so spring provides a validation
 *   		module by providing the validator interface 
 *   Spring supports expression language ,we can do expression language evaluation
 *   Spring also provides support for Aspect Oriented Programming
 *   Sping also provides very good logging capabilities
 */
public class SpringFrameWork {

}
