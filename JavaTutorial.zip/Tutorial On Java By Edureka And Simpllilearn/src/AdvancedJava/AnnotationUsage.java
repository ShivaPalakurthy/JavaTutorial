package AdvancedJava;

import java.lang.reflect.Method;

public class AnnotationUsage {
	
	@MyCustomAnnotation(value=10)

	public void sayHello() {
		System.out.println("My custom Annotattion");
	}

	public static void main(String args[]) throws Exception {
		AnnotationUsage h = new AnnotationUsage();
		Method methodVal=h.getClass().getMethod("sayHello"); /*calling the method by using Reflection API  getClass()
		return Annotation Usage class type & getMethod is going to return the method type which as the name says hello
		so this is the way to fetch a method name or method type from a class using java reflection's api which is an
		advanced api
		so we fetch the class & we fetch  the method it is going to search the class for a method name "sayHello" if it finds
		the method it is going to return the method in this variable &then we can call methodVal.getAnnotation -->give me any
		annotation which is applied on this particular method & we supply the annotation class as well.Once we do that we get a
		MyCustomAnnotation reference type than if we call the value method on this we will get this value as 10*/ 
		
		MyCustomAnnotation myCustomAnnotation=methodVal.getAnnotation(MyCustomAnnotation.class);
		System.out.println("value is: "+myCustomAnnotation.value());
	}
}
