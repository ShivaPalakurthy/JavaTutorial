package AdvancedJava;
/*
 * Autoboxing is the automatic coversion that the java compiler makes between the primitive
 * types & their corresponding wrapper class,for example converting an int to an Integer,
 * a double to a Double & so on.... If the conversion goes the other way it is called
 * unboxing
 */
public class AutoboxingInJava {
		public static void main(String args[]) {
			int i=10;
			
			//Autobox
			Integer iObj=Integer.valueOf(i);
			System.out.println("Value of the Integer obj: "+iObj);
			
			//auto-unbox
			int i1=iObj;
			System.out.println("Value of i1: "+i1);
			
			//Autobox
			Character charobj='a';  //or char x='a'; Character charObj=Character.valueOf(x);
			
			//Auto-unbox
			char ch=charobj;
			System.out.println("Value of ch: "+ch);
			System.out.println("Value of charObj: "+charobj);
		}
}
