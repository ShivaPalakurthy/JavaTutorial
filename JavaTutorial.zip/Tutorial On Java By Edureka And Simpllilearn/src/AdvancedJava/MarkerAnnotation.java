package AdvancedJava;
/*
 * there would be some cases in your application where you need to provide some metadata information to the 
 * java compiler.Generally Annotations will not have any direct affect on the operation of the code they annotate bugt
 * they provide additional logic to the code.They are shortHand MetaData
 * Annotation uses:
 * 1.Information for the compiler
 * 2.Compile-time & deployment-time processing
 * 3.Runtime Processing
 * 
 * denoted by @ symbol example in inheritence when we override we'll write @override -->this is an annotations .this annotation
 * is used to tell the compiler that I'm overriding this method
 * 
 * @SuppressWarnings(value="unchecked") -->this anotation is used to suppress any kind of yellow warnings in our code
 * @Author(name="Shiva palakurthy")--->if you want to put ur name one a particular peice of code then we'll use this
 * 
 */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface MarkerAnnotation {
	/* we can also build our own custom annotations as well
	 * 1.MarkerAnnotation: it is just an empty annotation without having a metadata logic
	 * MarkerAnnotation is used to provide high level instructions to the compiler & the way you will write  your custom annotation
	 * is you will put access modifier keyword like public then we'll write @interface this is the keyword which we have
	 * to use whenever we are trying to create a custom annotation,after this you have to provide a name for your annotation
	 * which can be anything but still not complete .we need to also provide more instructions to the compiler or the runtime
	 * processor to tell them when to execite this annotation & what the annotation type is going to be applied upon.so at first
	 * we'll specify when this annotation is going to be active or executed or evaluated. so here you can say add the 
	 * retention which is another annotation & then you say RetentionPolicy.RUNTIMEor SOURCE --->for source it is going to be 
	 * applied at compile time & if you select runtime then the annotation is going to be proccessed on runtime.The second thing
	 *  we should provide is where this annotation is going to be applied whether you want this annotation to be applied to a
	 *  class or to a method or to a member variable or to any other type. That's what you define in the @Target annotation-you
	 *  specify the target audience for this particular annotation inside element type you get multiple options to you can apply this
	 *  annotation to a constructor to a field ,local variable method, module, package, record component type etc.Here we are using
	 *  type which means it can be applied to a class or a generic element type which generally means class type & that's all
	
	 */
}
