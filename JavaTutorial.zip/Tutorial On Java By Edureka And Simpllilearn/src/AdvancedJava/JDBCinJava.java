package AdvancedJava;

/*
 * https://www.postgresql.org/download/windows/ to download PostgreSQL & 
 * https://jdbc.postgresql.org/download/  for jdbc driver for postgreSQl
 * INstall both
 * For every database vendor there would be different jdbc jar which we need to download
 * when we install the postgresql we also get an SQL client name pgadmin to talk to the 
 * database.
 * Two passwords for pgadmin is 1.charless@143 MAIN PASSWORD & 2.charless PASSWORD FOR postgres DATABASE USERNAME
 * 
 * create database after openning pgadmin heree we made test
 */
import java.sql.Connection; //main important package for the connection
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
/*
 * Java is a programming language & it doesn't comes with its own database but there are
 * multiple vendors like postsql,oraclesql,postgresql,mysql,microsoftsql etc. so java wanted to 
 * provide a uniform way to host all these databases so java created this application 
 * interface called JDBC
  */
public class JDBCinJava {
		public static void main(String args[]) throws SQLException {
			//creating the connection
			String url="jdbc:postgresql://localhost/test";  //address of the database-->to connect the database every 
					//database vendor will provide its connection url & we can find it from the
//					  the official documentation so the general syntax is
//			"jdbc:yourdatabasevendorsname://thehostname(can be any ip address here local host , genreally we also put localhost:5432 ,5432 is the port at which postgresql runs every
//			database vendor has a default port at which there database is running)/databse name";
//			so , "jdbc:postgresql://localhost/test"; or "jdbc:postgresql://localhost:5432/test"; is the url for postgresql
//			here test is the database name we created in PGADMIN of POstgresql
			Connection conn=null;
			
			
			//inserting a record data into a table
			
			/*creating table in PGADMIN select schemas in test database, select public,
			go to tables from the public then right click & create table name & give 
			columns & there datatypes aswell.
			you can also create columns by right click on table then select scripts 
			*/
			int rollno=4;
			String name="Bramhananda Reddy";
			int age=24;
			String sql="insert into student(rollno, name, age) " + "values(" + rollno + ",'" + name + "'," + age + ")" ; //once you got the values build the exact sql statement which is going to be run on postgresql server
			//			insert into TABLENAME(ALLCOLUMNNAMES)	VAlues				 name is a strig variable we have to keep single inverted comma but its not needed for rollno & age as they are integers
			try {
				conn=DriverManager.getConnection(url,"postgres", "charless"); //to get a connection to the database & supply username & password
				

				Statement st =conn.createStatement(); //creating statement object on the conncection insert,delete,etc
				int m=st.executeUpdate(sql); //used to any insert or deletion operation
				if(m==1) //row got inserted successfully
					System.out.println("inserted successfully : "+ sql);
				else
					System.out.println("insertion failed");
			}catch (Exception ex) {
				 System.err.println(ex);
			}finally {
				conn.close(); //closing database connections is must
			}
		}
}
/*			IMPORTAT STEPS TO ADD JAR FILES
 *  adding jar file of jdbc driver for postgresql  to eclipse
 *  goto project name or pakage name or class name right click & goto buildpath then
 *  goto configure buildpath then goto libraries tab select classpath & choose add external
 *  jars, load your jdbc sql driver jar file of postgresql then click apply & close
 */ 