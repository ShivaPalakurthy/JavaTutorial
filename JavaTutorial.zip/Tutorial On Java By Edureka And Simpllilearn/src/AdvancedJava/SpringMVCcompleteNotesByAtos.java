package AdvancedJava;
/*
 * 								Topics:
 * 1.Web Application
 * 2.MVC Architecture
 * 3.Life Cycle of a request in MVC Architecture
 * 4.Spring MVC setUp: Spring 4.x,Spring 5.x
 * 5.Spring MVC Architecture
 * 6.J2EE Design Pattern
 * 7.Life Cycle of a request in Spring MVC
 * 8.LAB-Spring MVC Login Application
 * 9.LAB-Spring MVC Login Application+Service+DAO+DB
 *	
 *
 *					//Web Application Architecture
 *
	A simple web application has following Tiers:
	
		
			UI							SERVER
	----------------- 			-------------------------------------------
	|				|			|-----------------		----------------- |
	|	HTML		|			||	Web-server	 |		| App-Server	 ||					EIS-->Logical Level Enterprise Information System
	|	CSS			|			||				 |		|				 ||				-------------
	|	Java Script	|			|| 	ex.tomcat	 |		|ex.jBoss		 ||				|			|
	|	Bootstrap	|	==>		||	web component|		|				 ||		==>		|	DB		|
	|	Angular		|			||	 -servlet,	 |		|App Component	 ||				|	ERP		|
	|	Extjs		|			||	 jsp,bean	 |		|	ejb,adfbs,	 ||				|	CRM		|
	|				|	<==		||				 |		|	springbc,bc4j||		<==		|	JMS		|
	|				|			||				 |		|				 ||				|			|
	|				|			||				 |		|				 ||				|			|
	|				|			||				 |		|				 ||				-------------
	|				|			|-----------------		----------------- |
	-----------------		     ------------------------------------------
	Client Tier							Middle Tier											Database Tier
	
	A spring frameworks usually supports all the 3 Tiers
	If you want to use spring bc as an application componet you wont be needed an application server,
 
 
 							//MVC Architecture-->MOdel view Controller Architecture
 							   
 	assume We are implementing some use case.
 	Use case:search
 	
 	How MVC Architecture will work for search use case
 	
 	When client sents a request the MVC Architecture the request is passed to the controller & the controller will
 	take help of model to implement the business logic & the controller will get the corresponding response as well
 	& the controller will send the response in the format of this view
 	when we implement search use case ,we write the viewlayer used searchView.jsp & in the controller layer  SearchController.java is going 
 	to connect with the Service Layer SearchService.java & this interacts with the DAO layer SearchDAO.java
 	
 	In a Simple MVC  Application , the controller is responsible for handling the client request &
 	response we don't write any business logic inside a controller & is always responsible to 
 	interact with model layer.
 	Model Layeer contain actual business logic & we can consider that model layer contains SERVIDE+DAO layer(SearchService.java & SearchDAO.java)
 	DAO cantains CUrd operations while service contains related operations like log in, authentication & authroisation services etc
 	View Layer is used to interact with the client .we create the view layer by using UI techonologies like the
 	html or jsp or angular or react
 				
 								view				 Controller					Service						DAO
 	use case:search			SearchView.jsp 		SearchController.java		SearchService.java 			SearchDAO.java
     -------------     
 	|          	  |				
 	|			  |				 ----------------------------------------------------------
 	|	CLIENT	  |		===>	|													       |
 	|			  |				|	 ----------	 -->Handle request & response		       |
 	|			  |				|	|		   | -->NO Business Logic(Bl)			       |
 	 -------------				|	|Controller| -->responsible to interact with model     |
 	 							|	|		   |				 ---------  		       |
 	 							|	 ----------	      <===	    |  		  | -->Contain	   |
 	 							|		   /\		  ===>		|  Model  | Business logic |
 	 							|	  ||   ||					|		  | -->service &   |
 	 							|	  \/						 ---------	 DAO layer	   |
 	 							|														   |
 	 							|	 ---------	   `									   |
 	 							|	|		  | -->Client side view						   |
 	 							|	|	View  |	-->No Business Logic					   |
 	 							|	|		  |	-->UI interface like html,				   |
 								|	 ---------		jsp,angular,react etc				   |
 								 ----------------------------------------------------------
 	If I want to create a simple mvc architecture using servlet then we can use SearchCOntroller as Controller ,searchService & serviceDAO in the model layer
 	& searchview as a view layer
 	This basic MVC ARchitecture has some limitation & the limitation is for one  use case we have one servelet i.e one controller,so if in 
 	your project if you are having 200 use cases then you are going to handle 200 controller.if we have multiple controller i.e if no.of servelet is 
 	going to grow then it's very hard to implement security features for all the controllers like authentication or authroisation security checks 
 	That's is the problem for basic MVC Architecture as the number of servelets grow then we have to face implementation of security for all the 
 	servelets so the solution is that we should have centralized request handling mechanism
 	Based on that there are following types of MVC Architecture 
 					
 							//Types of MVC Architeture
 		-->JSP Model 1 MVC Architecture
 		-->JSP Model 2 MVC Architecture
 		-->JSP Model 3 MVC Architecture
 		-->JSP Model 4 MVC Architecture
 		
 	1.	JSP Model 1 MVC Architecture-JSP Model 1 MVC Architecture or JSP centric Architecture contains
 	javaBeans or EJB model object ,View JSP PAges & Action JSP Pages.In Model 1 Architecture,the incoming
 	request is directly sent to the JSP Page from a web browser & Jsp page is responsible for processing it & sending back to
 	the client.
 									 ----------------				 ---------------		
 		 -------------  1 Request	| -----------  	 |			   	| 	 -------  	|				
 		|			  |-----------> ||			 |   |				|	|		|	|
 		|	Browser	  |				|| JSP Pages |	 |				|	|		|	|
 		|			  |<-----------	||			 |	 |				|	|		|	|
 		 -------------  4 Response 	| ----------- 	 |				|	|		|	|
 		 							|	 /\			 |				|	|		|	|
 		 							|	 ||			 |			   	| 	 -------  	|
 		 							|	 ||	2		 |			   	| 	 		  	|
 		 							|	 ||			 |			   	| 	 -------  	|
 		 							|	 \/			 |				|	|		|	|
 		 						    | -------------	 |				|	|		|	|   													    
 	 							 	||		       | |				|	|		|	| 						   
 	 							 	||	Java Bean  | |				|	|		|	|	  					    
 	 							  	||		 	   |<|--------------|-->|		|	|	 				    
 								 	| -------------	 |			   	| 	 -------  	|		
 								     ----------------				 ---------------
 								     Servlet Container	 		Enterprise Information System (EIS)

  2.JSP Model 2 MVC Architecture:JSP Model 2 is a complex design pattern used in the design of Java Web applications which separates
   the display of content from the logic used to obtain and manipulate the content. Since Model 2 drives a separation between logic 
   and display, it is usually associated with the model–view–controller (MVC) paradigm. While the exact form of the MVC "Model" was
   never specified by the Model 2 design, a number of publications recommend a formalized layer to contain MVC Model code. The Java 
   BluePrints, for example, originally recommended using EJBs to encapsulate the MVC Model.
   In a Model 2 application, requests from the client browser are passed to the controller. The controller performs any logic necessary 
   to obtain the correct content for display. It then places the content in the request (commonly in the form of a JavaBean or POJO) and 
   decides which view it will pass the request to. The view then renders the content passed by the controller.
   Model 2 is recommended for medium- and large-sized applications.
   	Search in internet for  images of JSP MODEL 2 MVC  Architecture
   	
   	Similartly go to chrome & search the images & description of JSP Model 3 MVC Architecture & JSP Model 4 MVC Architecture
   	
    							 //Spring MVC Architecture
    							  * 
    							  * 
  Spring framework follow some design patter interms of Spring MVC Architecture i.e we have
  desing pattern in presentation layer , design pattern in businnes layer , & design pattern in the integration layer 
  Spring MVC follow some design pattern which is called as J2EE design pattern.
  In presentation layer it follow some JSEE design pattern called FrontController design pattern,
   																					-------
   																	dispatches	   | View  |
   																 ----------------->|	   |
   																|					-------
   -------- 				---------------- 			---------------------
  | Client | sends request |Front Controller|delegates |ApplicationCOntroller|
  |		   |-------------->|				|--------->|					 | 
   --------					----------------			---------------------		 ---------
   								  /\							|					| Command |
   								  ||							 ------------------>|		  |
   	   			 -----------------------------------		  		 invokes		 ---------
 				|								   |
 		 --------------- 					----------------
 		| <<Servlet>>	|				   |	<<JSP>>		|
 		| ServletFront	|				   |	JSP Front	|
 		 --------------- 					----------------
 When client request is comming it won't go directly to the controller, ForntCOntroller provides the
 centralised request handling mechanism , so who ever & what ever is the request it must pass through the FrontCOntroller (it's a servlet itself ,only one servlet),
 based on the use case if we have 200 use cases ,we can create 200 application controller but we should have only one servlet(one centralized servlet),The centralised request
 handling mechanism comes effective when you've, who ever is going to pass the request, the request must pass through front controller.FrontController
 will do automatic authentication , authorisation,logging then pass the request to the corresponding handler user, IN case of SPring Framework , this 
 FrontControoller is created with the name of dispatcher servlet.This frontController design pattern is accepted by all the frameworks in the market .SO 
 dispatcherservlet will interact with different handlers like, use case is account it handles with account handler, if the use case is search it handles with search handler,if use
 case is salary it handles salary handler.
 
 
 Business Delegate desing pattern is used in the bussiness tier/layer.The purpose of business delegate business pattern is to segregate or decouple presentation layer from
 the business layer so business deligate design pattern is used to seggregate service layer from the controller layer. It provides access to business service methods.Assume we are
 using a use case is search, so we have the Searchcontroller, in the service layer we have SearchService in the DAO layer we have SearchDAO.Between searchController & searchService
 this Business delegate design pattern is used .It uses ServiceLocator.Business delegate provides access to business service methods.it is mainly used to hide implementation details of
 the Business Service.The client requests the BUsinessdelegate to provide access to the underlying business service.The BusinessDElegate uses a LookUpService to locate the required 
 BusinessService Component.
 
 
 
 *		  
 */
public class SpringMVCcompleteNotesByAtos {

}
