package AdvancedJava;
import java.io.Serializable; //for class Student
import java.io.FileInputStream; //for SerializationInJava
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/*
 * When we build the enterprise grid apllications in different organisations, we often has
 * a need/use case  to sent an object from one application to other application which is
 * deployed on other machine. we will transfer from one application to other appplication
 * through network lines in the form of Bytes. so the process of converting an object
 * to a byte so that it can be sent over a network is called serialization & the process of
 * converting back the byte from the network to a java object is called DEserialization.
 * 
 * To serialize an object, we will use 	java.io.serializable interface. or its subingterface
 * 							java.io.Externalizable
 */

/*
class Student implements Serializable{
	
	private static final long serialVersionUID =1L;
//	serialVersionUID -->Serial version
//	Universal ID. this is added so that java can uniquely identify your object once it is
//	serialized & deserialized. It also keep a version track of it because what happens if 
//	somebody hops over the network line & change the representaion of your object & the 
//	consumer application will get a complete diferent object now.so this is java way to make
//	sure that the same version which the producer application is producing is received by the
//	application. so it's also a sort of security feature. whenever we do an update on to
//	an object,it is going to increment this serialVersionUID by 1.when we create the object
//	for the first time & serialize it for the first time the values is going to be set as
//	default 1 & as you mutate the object again & again before deserializing ,it the account
//	keep on increasing that's how we keep a track on the state of the object which is being
//	serialized by adding this long serialVersionUID 
	
	private String name;
	private int age;
	private String address;

	
	//transient int x;
	public Student(String name, int age, String address) { 
		this.name = name;
		this.age = age;
		this.address = address;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}



	
//	public void setX(int x) { for tansient variable
//		this.x=x;
//	}
//	public int getX() {
//		return x;
//	}
	@Override
	public String toString() {
		return  ("Student Name is "+this.getName()+". age is: "+getAge()+" and address is: "
				+this.getAddress());
	}
	
}

public class SerializationInJava {

		public static void main(String args[]) {
			Student student=new Student("john", 25,"23 East,California");
			
			
	
//	 * we want to store the state of the object student when we serialise this object
//	 * this object has to be either sent to a network, but since we're running this
//	 * demo on the same machine we'll serialise this object on to our local file system
//	 
			String filename="C:\\Files\\Test.txt"; 
//			A specify of filename
//			where the serialized representation of the student objeect is going to be
//			stored & this is the location F:\\java-tutorials\\Test.txt where we are supposed
//			to store this. then we created two different classes FileOutputStream & 
//			ObjectOutputStream which is for writing to the file objOut.writeObject(student); 
//			& creating an object for it
//			
			FileOutputStream fileOut=null;
			ObjectOutputStream objOut=null;
			
			//serialization
			try {
				fileOut=new FileOutputStream(filename); //supllying the filename
				objOut=new ObjectOutputStream(fileOut);
				objOut.writeObject(student); //writing the student object to the file
				
//				 * so when java has to write this object to the file ,it is automatically
//				 * going to serialize.That's the only a java can write an object to the file
				
				objOut.close();
				fileOut.close();
				System.out.println("Object has been serialized: \n" +student);
			}catch(IOException ex) {
				System.out.println("IO Exception is caught");
			}
			
			//Deserialization
			FileInputStream fileIn=null;
			ObjectInputStream objIn=null;
			try {
				fileIn=new FileInputStream(filename); //loading the same file filename to JVM
				objIn=new ObjectInputStream(fileIn);
				
				Student object= (Student) objIn.readObject(); //reading the object
				 
//				 *The way we read the object is by using this  ObjectInputStream class we
//				 *supplied the file then we called the readObject() method which is going to
//				 *return an object (a general object).when we call the readObject() method
//				 *it doesn't know that it is the student type object so we need to
//				 *explicity cast (Student) objIn.readObject() this to the student type so
//				 *that we can store this as a student object.If we don't explicitly cast
//				 *we wil get an error.-->Type mismatch: cannot convert from Object to Student
//				 * As we said readObject() doesn't know anything about the Student class so this 
//				 * mean is that when we serialise an object the class type information is lost,we
//				 * cannot store the class type information when we serialize an object because
//				 * the moment we call writeObject(student) from the ObjectOutputStream class it is
//				 * just any java object for this java program,the signature of the student class is 
//				 * lost.Similarly when we deserialize it, the serialization api has no idea about
//				 * what student class is& what student object is so we need to tell the readObject()
//				 * method explicitly that it is reading an object of the Stundet type & thats how
//				 * line 141 works
//				 *
				   
				
				System.out.println("Object has been deserialized:	\n"+object);
				
				objIn.close();
				fileIn.close();
			}catch(IOException ex) {
				System.out.println("IO Exception is caught");
			}catch (ClassNotFoundException ex) {
				System.out.println("ClassNotFoundException" +" is caught ");
			}
			
			}
		
}

*/

/*
 * What if we have a use case where we have a property in the Student class or in your
 * object but you don't want to be serialized, that's also a use case where we may have
 * 50 diffeerent properties inside the student class & one of the properties something
 * which you don't want to serialize because we don't the consumer application to see 
 * that value. so if we ever have the scenario use the transient variable
 */
//Same as above program but adding tansient variable
class Student implements Serializable{
	
	private static final long serialVersionUID =1L; 
	
	private String name;
	private int age;
	private String address;

	
	transient int x;
	// Transient is a keyword,when we keep this variable infort of a member variable
	//that varaible becomes transient variable.The use case of this transient variable
//	 is that if we don't want this x to be serialized & deserialized then we put the 
//	  transient keyword & then have the getters & setters for that transient variable
	 
	public Student(String name, int age, String address) { 
		this.name = name;
		this.age = age;
		this.address = address;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}



	
	public void setX(int x) {
		this.x=x;
	}
	public int getX() {
		return x;
	}
	@Override
	public String toString() {
		return  ("Student Name is "+this.getName()+". age is: "+getAge()+" and address is: "
				+this.getAddress());
	}
	
}

public class SerializationInJava {

		public static void main(String args[]) {
			Student student=new Student("john", 25,"23 East,California");
			student.setX(10);
 
			String filename="C:\\Files\\Test.txt";  
			FileOutputStream fileOut=null;
			ObjectOutputStream objOut=null;
			
			//serialization
			try {
				fileOut=new FileOutputStream(filename); //supllying the filename
				objOut=new ObjectOutputStream(fileOut);
				objOut.writeObject(student); //writing the student object to the file
				 
				objOut.close();
				fileOut.close();
				System.out.println("Object has been serialized: \n" +student);
			}catch(IOException ex) {
				System.out.println("IO Exception is caught");
			}
			
			//Deserialization
			FileInputStream fileIn=null;
			ObjectInputStream objIn=null;
			try {
				fileIn=new FileInputStream(filename); //loading the same file filename to JVM
				objIn=new ObjectInputStream(fileIn);
				
				Student object= (Student) objIn.readObject(); //reading the object
				 
				
				System.out.println("Object has been deserialized:	\n"+object);
				System.out.println("The deserialized value of x is: "+object.getX()); //remove transient keyword from int x in Student class to see the difference
				objIn.close();
				fileIn.close();
			}catch(IOException ex) {
				System.out.println("IO Exception is caught");
			}catch (ClassNotFoundException ex) {
				System.out.println("ClassNotFoundException" +" is caught ");
			}
			
			}
		
}

