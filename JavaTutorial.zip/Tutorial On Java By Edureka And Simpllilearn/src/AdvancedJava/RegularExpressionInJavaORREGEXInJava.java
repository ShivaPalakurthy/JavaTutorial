package AdvancedJava;
//Regular Expression in java or REGEX in java
/*
 * The basic idea behind Regular Expressions is to find a pattern in a text corpose,if we
 * have lot of strings or text & if we would like to find a particular pattern say does this
 * whole text paragraph contains any special characters? or any numbers? or contains characters
 * after numbers?.If we find those kind of patterns in the text corpase ,then that concept is
 * called Regular Expression finding.
 * java.util.regex:Classes for matching character sequences aginst patterns specified by
 * regular expressions.This package is used when we want to find anhy regular expression
 * finding in the text
 * 
 * String handling methods is limited as it only provide string methods ways to manipulate
 * ,find & replace string But, REGEX is generic we can find any kind of character in your
 * string,it can be a special character ,it can be a square bracket ,it can be a multiply sign
 * it can be a divide sign, any kind of pattern that we need to find we can use java.util.regex
 * package
 * Learn more from java documentation on this package
 * 
 * Regular Expression are a way to describe a set of strings based on common characteristics
 * shared by each string in the set
 * 
 * Classes in regex package:
 * 1.Pattern class:-A pattern object is a compiled representation of a regular expression.
 * The Pattern class provides no public constructors.To create a pattern,you must first
 * invoke one of its public static compile methods, which will then return a Pattern object.These
 * methods accept a regular expression as the first arguments 
 * 
 * 2.Matcher class:- A matcher object is the engine that interprets the pattern & performs
 * match operations against an input string.Like the pattern class,Matcher defines no public
 * constructors.You obtain a Matcher object by invoking the matcher method on a Pattern object.
 * 3.PatternSyntaxException:A PatternSyntaxException object is an unchecked exception that
 * indicates a syntax error in a regular expresssion pattern
 * 
 * if we write regular expression as bellow cat.  when you are applying this regular expression
 * to find the match in a string  it is only going to find the match for cat ,it is not going
 * to find the mactch for cat. because . is a metacharacter in regular expression & has a 
 * special meaning. metacharacter->a character with special meaning interpreted by the matcher.
 * The metahcaracter "." means "any character " which is why the match succeeds in this example
 * 				Enter your regex:cat.
 * 				Enter input string to search:cats
 * 				I found the text cats starting at index 0 & ending at index 4.
 *Similar metacharacters are:   <([{\^-=$!]})?*+.> & these all have a special meaning
 *
 *
 *CHaracter classes: 
 *		Construct							Description
 *		[abc]					a,b,or c (simple class)
 *		[^abc]					Any character except a,b or c (negation)
 *		[a-zA-Z]				a thorugh z,or A thorugh Z, inlcusive (range)
 *		[a-d[m-p]]				a thorugh d, or m through p:[a-dm-p](union)
 *		[a-z&&[def]]			d,e or f(intersection)
 *		[a-z&&[^bc]]			a through z,except for b & c:[ad-z](subtraction)
 *		[a-z&&[^m-p]]			a thorugh z,& not m through p:[a-lq-z](subtraction)
 *
 *Predefined Character classes
 *  .			Any character(may or may not match line terminators)
 *  \d			A digit[0-9]
 *	\D			A non digit:[^0-9]
 *	\s			A Whitespace character:[\t\n\x0B\f\r]
 *	\S 			A non-whitespace character: [^\s]
 *  \w 			A word character: [a-zA-Z_0-9]
 *  \W 			A non-word character:[^\w]
 */

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionInJavaORREGEXInJava {
			public static void main(String args[]) {
				String regexStr=".*[a-z][0-9]."; //.(any character)*(any number of characters)[a-z](the pattern expects alphabetical string followed by numerical string)[0-9].(after numerical section it can be any character)
				Pattern pattern=Pattern.compile(regexStr); //after pattern.compile we get pattern object
				
				Matcher matcher =pattern.matcher("123435646adadaf242341234");
				boolean matchFound=matcher.find();
				if(matchFound) {
					System.out.println("Match Found");
					
				}else {
					System.out.println("Match Not Found");
				}
				
				String regexStr1=".*[a-z][0-9][a-z]";  //match not found as the string doesn't have any alphabet after numbers
				Pattern pattern1=Pattern.compile(regexStr1); 
				
				Matcher matcher1 =pattern1.matcher("123435646adadaf242341234");
				boolean matchFound1=matcher1.find();
				if(matchFound1) {
					System.out.println("Match Found");
					
				}else {
					System.out.println("Match Not Found");
				}
			}
}
