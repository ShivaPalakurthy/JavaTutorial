package AdvancedJava;



/*
 * Java Beans is a standard /specification provided by java to be followed while we're
 * implementing production grade or enterprise grade application.
 * //to learn more about java bean go to this link https://www.oracle.com/java/technologies/javase/javabeans-spec.html
 * 
 * click download & download the 101 pdf
 * 
 * What is a Bean?
 A Java Bean is a reusable software component that can be manipulated visually in a 
 builder tool like eclipse,intellige or netbeans etc.
 
 Technically Java Bean is basically a java class but this java class should have 3 main properties:
 	1.That java class should have getters & setters to access the properties
 	2.That java class should have  a public no argument constructor so that any body 
 	can create object of it.
 	3.The java class should implement serializable interface because java bean would be 
 	required to exported between applications, may be required to be returned to a database
 	or to a file system or to be converted into xml or a json document sent over the 
 	network again deserialised. so this will be moving across alot.
 	Multiple different software components & applications  might be reusing that bean again &
 	again & that bean needs to travel across & to enable that the bean has to be serialisable
 	because if we can't serialise it we just can not transport that object to another application
 	
 	The most important features of java bean are the set of properties it exposes,the set of
 	methods it allows other components to call & the set of events it fires.\
 	Properties are names attributes associated with a bean that can be read or written by calling
 	appropriate methods on the bean.
 	The methods a Java Bean exports are just normal methods which can be called from other components
 	or from a scripting environment.By default all of a bean's public methods will be exported,but a
 	bean can choose to export only a subset of its public methods.
 	Events provide a way for one component to notify other components that something interesting has 
 	happened. Under the new AWT event model an event listener object can be registered
 	 with an event source. When the event source detects that something interesting happens it will
 	  call an appropriate method on the event listener object.
 	  
 	  
 */

//Writing the code in java beans format having 3 main properties

import java.io.Serializable;

public class JavaBeans implements Serializable{  //property no.3

	private static final long serialVeersionUID=1l;
	
	private String name;
	private int age ;
	private String address;
	
	public JavaBeans() {}  //property no:2 --> a public no argument constructor 
	
	//property no.1
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
