package AdvancedJava;
/*
 * Doing manipulations on image like read an image ,write an image ,load an image are 
 * known as image Handling in java
 * Java basically creates the byte representation of an image & save the content (Java2D)
 * 
 * The two main classes that java provides to do image handling are:
 * 1.java.awt.Image :is the superclass that represents graphical images as rectangular(2D)
 * arrays of pixels.
 * 2.java.awt.image.BufferedImage : extends the Image class to allow the application
 * to operate directly with image data(for example , retrieving or setting up the pixel
 * color).Applications can directly construct instances of this class. BufferedImage class
 * is goto class whenever we are dealing with any kind of image rendering tasks in the java
 * program
 */
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageHandlingInJava {
		public static void main(String args[]) throws IOException {
				int width=963;
				int height=640;
				
				BufferedImage image=null; //reference of the Buffered Image
				
				image=readFromFile(width,height,image);
				
				writeToFile(image);
		}
		
		private static BufferedImage readFromFile(int width,int height,BufferedImage image) {
			try {
				File sampleFile=new File("C:\\Files\\cropped3.jpeg"); //use double forward slashes \\ for windows
				
				//creating object of the BufferedImage
				image=new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB); //TYPE_INT_ARGB-->Type of the image 
				//After step 39 bufferedImage object is ready now we've to read the image
				
				//Reading input File
				image=ImageIO.read(sampleFile); //read the file & store the output into the bufferedImage object image -->read the whole image into a 2D array then copy that to image
				
				System.out.println("Reading complete. "+image); //we'll get hashcode for the image
			}catch(IOException e) {
				System.out.println("Error "+e);
			}
			return image;
		}	
							//supplying the same image object which was returned from the read operation
		private static void writeToFile(BufferedImage image) {  //static methods can only call other static methods since read is static write should also be static
			try {
				File output=new File("C:\\Files\\simplilearnAdvanceJava\\out.jpeg"); //out.jpeg-->we give the name with which the image should be written
				
					//	write(Rendered image im,String formatName,File Output)
				ImageIO.write(image, "jpeg", output); //ImageIO-->it is the utility ,write--> we supply the whole image object,we supply the image type extension,we supply the output location
				
				System.out.println("Writing Completed. ");
			}catch(IOException e) {
				System.out.println("Error "+e);
			}
		}
		
		/*			Instead of JPEG we are using jpg so even if we read image from jpeg forma
		 * since we converted into  2D format in java now if we write the image we can
		 * write it in any formate like JPEg,jpg or etc
		 * 
		 * 
		 * 
							//supplying the same image object which was returned from the read operation
		private static void writeToFile(BufferedImage image) {  //static methods can only call other static methods since read is static write should also be static
			try {
				File output=new File("C:\\Files\\simplilearnAdvanceJava\\out.jpg"); //out.jpeg-->we give the name with which the image should be written
				
					//	write(Rendered image im,String formatName,File Output)
				ImageIO.write(image, "jpg", output); //ImageIO-->it is the utility ,write--> we supply the whole image object,we supply the image type extension,we supply the output location
				
				System.out.println("Writing Completed. ");
			}catch(IOException e) {
				System.out.println("Error "+e);
			}
		}
		 * 
		 * 
		 */
}
