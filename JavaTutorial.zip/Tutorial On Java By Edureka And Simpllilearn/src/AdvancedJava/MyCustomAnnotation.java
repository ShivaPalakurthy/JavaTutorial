package AdvancedJava;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*
 *we can define our marker annotation like this but generally these marker annotation doesn't have any logic so we not
get much value out of it until you have a special cases, but you have a case where you want to also run some business
logic or provide some metadata logic to the compiler while defining the annotation then you can define your annotation like this
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME )
public @interface MyCustomAnnotation {
	int value();
}
/*The target audience for this annotation is method so this annotation can only be applied to methods, if we try to 
 * apply this annotation to a class we get error.The retention policy is runtime it means it is going to be 
 * processed in runtime & have declared a method where which is called int value so this is how we will declare your 
 * annotation. Lets see how we'll use this annotation in AnnotationUsage java program
 * 
 * 
 * */
