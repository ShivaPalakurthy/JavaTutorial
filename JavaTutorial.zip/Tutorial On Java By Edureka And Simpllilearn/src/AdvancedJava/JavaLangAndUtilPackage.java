package AdvancedJava;

public class JavaLangAndUtilPackage {
/*
 * Interfaces in Java.lang package
 * 1.Appendable:-An object to which char sequences & values can be appended.
 * 2.Autocloseable:An object that may hold resources(such as file or socket handles)
 * 					until it is closed]
 * 3.CharSequence:A charSequence is a readable sequence of char values
 * 4.Comparable<T>:This interface imposes a total ordering on the objects of each class that
 * 					implements it.
 * 5.Iterable<T>:Implementing this interface allows an object to be the target of the enhanced
 * 				 for statemenr (sometimes called the for-each loop)
 * 6.Readable:A Readable is a source of characters.
 * 7.Runnable:The Runnable interface should be implemented by any class whose instance are
 *			 intended to be executed by a thread
 *
 *ALl the datatype classes which we were using in different examples are also part of the
 *java.lang package.
 *It has Threads, Enum class & also various exception classes, It also provide some
 *error classes
 *It also provide some Annotations as well.
 *	
 *							Java.util package
 *Java.util package is not imported automatically, we have to explicitly import the
 *java.util package in order to use it unlike java.lang package
 *
 *You can use class coming from java.lang package without explicitly importing those classes
 *or importing the java.lang package but the java util package is something that we have to
 *explicitly import in our program in order to work or even compile.
 *
 *Java.util provide the whole COllection Framework.
 *All the interfaces that we use while we work with the collection framework classes are
 *present in the java.util package e.g: Iterator<E>,List<E>,Map<k,v> etc
 *All the concreat classes implementation of the collection framework interms of arraylist,
 *linkedlist , hashmap ,hashset, treeset comes under java.util package including Scanner class
 *Scanner class comes under java.util package
 *Exception which are used while working with the collection framework are
 *also present in java.util package
 */
}
