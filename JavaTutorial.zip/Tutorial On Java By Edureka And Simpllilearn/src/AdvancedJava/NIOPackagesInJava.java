package AdvancedJava;
/*NIO->non-blocking Input output in java->you dont want to block your threads while 
 * you are reading through a file or writing through a file
 * we can use NIO packages to read from a file or to write from a file
 * The main reason to launch the NIO package by java is to provide multithreading 
 * capabilities to the I/O library & we couldn't do this in the existing library because
 * we'd to probably rewrite  & change the functionaity of it (referring to I/O package)
 * 
 * The central Abstractions of NIO APIs are:
 * 1.Buffers->which are containers for data.The read operation will be happening from the
 * channel into the buffer & similarly the write operation will be happening to the channel form teh
 * buffer
 * 2.Charsets->And their associated decoders & encoders,which translate between bytes 
 * & unicode characters
 * 3.Channels->of various types, which represent connections to entities capable of 
 * performing I/O operations 
 * 4.Selectors & selector keys, which together with selectable channels define a multiplexed,
 * non-blocking IO facility
 * 
 * The read operation will be happening from the channel into the buffer & similarly 
 * the write operation will be happening to the channel form the  buffer
 * 
 * Operations on buffers:
 * clear() makes a buffer ready for a new sequence of channel-read or relative put 
 * operations.It sets the limit to the capacity & the position to zero
 * flip() makes a buffer ready for a new sequece of channel-write or relative get operations
 * IT sets the limit to the current position & then sets the position to zero.
 * rewind() makes a buffer ready for re-reading the data that it already contains:it leaves
 * the limit unchanged & sets the position to zero
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
//nio package is generic & it can be used for any kind of communication of reading & writing not specific to file handling
public class NIOPackagesInJava {
		public static void main(String[] args) throws IOException {
			
			//read function
			FileInputStream fin=new FileInputStream("C:\\Files\\simplilearnAdvanceJava\\source.txt");
			FileChannel readChannel=fin.getChannel();//because we're dealing with file we used FileChannel,if you're dealing with network socket then you might have a Socket Channel
			ByteBuffer readBuffer=ByteBuffer.allocate(1024);//1024-> we allocate some starting size to it, we can put any number which we think is practical for ur use case here we put 1024 bytes
			int result=readChannel.read(readBuffer);//read the file via channel into the buffer
			System.out.println("file read successfully"+result);
			
			//writing the file
			FileOutputStream fout=new FileOutputStream("C:\\Files\\simplilearnAdvanceJava\\dest.txt");
		
			FileChannel writeChannel=fout.getChannel();
			ByteBuffer writeBuffer=ByteBuffer.allocate(1024);
			String message="This is a test String"; 
			writeBuffer.put(message.getBytes());
			writeBuffer.flip();//reset the index
			writeChannel.write(writeBuffer);
			System.out.println("file written successfully");
		}
}
