package AdvancedJava;
/*
 * Java has dedicated package for networking called java.net package which has all the necessary clases
 * which we need to have to write a networking program in java
 * 
 * InetAddress class is the abrstraction representating IP(Internet Protocol) address.It 
 * has two subclasses namely:
 * 		1.Inet4Address for IPv4 addresses.
 * 		2.Inet6Address for IPV6 addresses.
 * This pacake has High level API's like
 *  URI used to represent Universal Resource Identifier as specified in the RFC 2396.
 *   It us an identifier & doesn't provide directly the means to access teh resource .
 *   it we have to access the resource then we need to use URL which is the class repres
 *   enting the Universal Resource Locator but it is slightly older concept than URI
 *   URLConnection: is created from the URL & is the communication link used to 
 *   access the resource pointed by the URl
 *   
 *   GO & check the java page about java.net package for get more details
 */
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
public class NetworkingInJava {
	public static void main(String[] args) throws UnknownHostException{
		String url="www.simplilearn.com";
		
		InetAddress inetAddress=Inet4Address.getByName(url); //Concreate Implementation of Inet4Address class
	/*
	 * we used getByName(url)	& supplied the url to get an InetAddress object
	 */
		//If we want to see the IPAddress where the particular website is hosted we can call the getAddress method
		System.out.println("Address : "+Arrays.toString(inetAddress.getAddress()));
		/*Ip4Address has 4 sections all the 4 sections will have some values when we try to use
		 * the getAddress() method & try to convert to String it basically returns an Array
		 *  which will look this  [108, -98, 61, 66] but if want to see exactly the 
		 *  format in which the real world networking looks like then we'll use the
		 *  getHostAddress() method & we will get like this 108.158.61.66
		*/
		
		//getHostAddress() method
		System.out.println("Host Address : "+inetAddress.getHostAddress());
		
		//isAnyLocalAddress() method-->check & tells is there any wildcard address which is associated with the particular host
		System.out.println("isAnyLocalAddress : "+inetAddress.isAnyLocalAddress());//result will be boolean
		

		//isLinkLocalAddress() method--> to check if the InetAddress is a link to a local address within the domain of the website
		System.out.println("isLinkLocalAddress : "+inetAddress.isLinkLocalAddress());//result will be boolean
		
		//isLoopbackAddress() method-->to check if the InetAddress is a loopback Address
		System.out.println("isLoopbackAddress : " +inetAddress.isLoopbackAddress());//result will be boolean
	
		//isSiteLocalAddress() method-->to check if the InetAddress is a site local address
		System.out.println("isSiteLocalAddress() : "+inetAddress.isSiteLocalAddress());//result will be boolean
		
		//hashCode() method-->hashcode contained by the Inet object
		System.out.println("hashCode() : "+inetAddress.hashCode());
	}
}
