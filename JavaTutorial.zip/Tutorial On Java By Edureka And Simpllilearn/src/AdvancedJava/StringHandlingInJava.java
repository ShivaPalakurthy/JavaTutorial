package AdvancedJava;
/*
 * 1.compareToIgnoreCase-->compares two strings ignoring the upper & lower case
 * 2.concat(String str)-->Concatenates the specified string to end of this string.
 * check more methods used to handle string in order to perform different actions
 * Strings are immutable in nature, once we created a string  str holding a particular value
 * this particular objects value pointing to str cannot be changed. we cannot mutate the 
 * strings, if we try to change str value, java is going to create the new object & point
 * str to that object,but the object which was created initially is not going to be oveerriden
 * it can be overrriden for STringBuferr & StringBuilders but not for the STrings
 * 
 */
import java.util.Arrays;
public class StringHandlingInJava {
		public static void main(String args[]) {
			String str1="John is studying";
			String str2="in college";
			System.out.println(str1.length());
			
			String result=str1.concat(str2); //joining two Strings
			System.out.println(result);
			
			String r=String.format("The name of the stundent is " +"%s, and the age is "+"variable is %d","John",21);
			System.out.println(r);
			
	/*
	 * format method is used to dynamically populate some parts of string for example if 
	 * we have long list of students & if you print the name of students,then what we can assign those
	 * names to certain variables & you can point or refer those variables in the string 
	 * with the % syntax(%s,%d etc)
	 * here, String.format method is used to supply dynamic values inside a static string
	 */
			System.out.println(str1.charAt(5));
			
			if(str1.equals(str2)) {
				System.out.println("both strings are same");
			}else {
				System.out.println("both strings are different");
			}
			
			System.out.println(str1.indexOf('y')); //if character is not present in the string you get -1
			
			System.out.println(str1.replace('s', 'r'));
			
			String[]	arr=str1.split(" "); //here we are separating the string when we get space so john is separate,is is separate,studying is separate
			Arrays.asList(arr).forEach(s->System.out.println(s));// using streams api to iterate over String arr outputing /printing each element of the array
			
			String newStr1=str1.substring(1,5); //starts from begining index & go till n-1 of ending index
			System.out.println(newStr1);
		}
}
