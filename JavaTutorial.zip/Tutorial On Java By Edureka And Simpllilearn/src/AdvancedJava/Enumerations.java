package AdvancedJava;
/*
 * when we are building java applications we will face scenarios where you'll have to define some variables which will
 * remain constant forever
 * eg. Months of the year, days in a week, name of the flowers,name of the seasons etc.These are constants & our programs
 * will interpretate them differently. so when ever we have situation to define such constants we'll write under enum Types
 * Enum is basically a language construct & this langugae construct can be used to defined Type safe variables.
 * Type safe Variables-->These variables are not integer or string they are of enum types.Thats the reason java has
 * created a completely new dataType called enum type.They are by default constant & you can't change them & that's
 * there property. They way we define enum is as follows
 * 
 * 			public enum Day{
 * 			SUNDAY,MONDAY,TUESDAY,WEDNESSDAY,
 * 			THURSDAY,FRIDAY,SATURDAY
 * 			}
 * We notice that the values are caps by default & that's is how we define enums
 */
enum Color{
	RED("red"),GREEN("green"),BLUE("blue"); //here we have defined the value of enum types
	
	/*
	 * whenever if you want to fetch the values of enum types eg red in RED , green Green etc, we have to write
	 * some extra code which is written as below but if you are not defining values of the enum types, your enum can be as 
	 * simple as below
	 *  			public enum Day{
 * 			SUNDAY,MONDAY,TUESDAY,WEDNESSDAY,
 * 			THURSDAY,FRIDAY,SATURDAY
 * 			}
	 */
	private String value;
	
	Color(String value){
		this.value=value;
	}

	public String getValue() {
		return value;
	}
	
	
}
public class Enumerations {
		public static void main(String args[]) {
			Color c1=Color.RED;
			
			System.out.println("Red Enum Value is : "+c1.name());
			System.out.println("Red Enum Value is : "+c1.getValue());
			
			for(Color color:Color.values()) {
				System.out.println("Enum Value: "+ color.getValue()+ " for Enum Names is :"+ color.name());
			}
			
		}
}
