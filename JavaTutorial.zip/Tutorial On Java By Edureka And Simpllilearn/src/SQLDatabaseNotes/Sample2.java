package SQLDatabaseNotes;

public class Sample2 {
/*
 * 					
 * 					SQL NOTES FROM FREECODECAMP.ORG
 * 
 * 
 *  SURROGATE KEY-->Type of primary key & it doesn't actually have any real mappings, for example if emp_id starts from 100001
 *  it doesn't acctualy mean the employee name is 100001 ,
 *  				100001   |shiva
 *  				100002	 |dhana
 *  				100003	 | aswin
 *  				100004	 |bramha
 *  
 *  NATURAL KEY: Type of a primary key which has meaning in the actual world . example emp_ssn number-->SSN number is given
 *  	for foreign employess to work in usa.
 *  	e.g: emp_ssn		|fname
 *  		138221342		|shiva
 *  		213142121		|dana
 *  		213531122		|BRmha
 *  		241536248		|aswin	
 *  
 *  surrogate key has no mapping to the real world where as natural key has a mappping to the real world
 *  
 *  COMPOSITE KEY: A composite key is baiscally a key that needs two attributes.\
 *  
 *  blob is used to large binary data , images etc
 *  
 *  
 *  STEPS TO DOWNLOAD MYSQL COMMUNITY SERVER
 *  1. Open https://dev.mysql.com/downloads/installer/ link
 *  2.Download  Windows (x86, 32-bit), MSI Installer	8.0.33	428.3M	 
 *  3.Select custom as we want MYSQL workbench & MYSQL shell
 *  4.Now select MySQL server 8.0 latest version & from application select MYSQL workbench & MYSQL Shell latest version,
 *    click on next and select path & click next.
 *  5.Now click execute, after installing click next & next again
 *    we will find different configurations like port number(3306),protocol code leave as it is and click next
 *  6.select 'use strong password encryption for authentication and click next
 *  7.give root password here I gave BlackHawkDown@143
 *  8.click next on window service
 *  9.click on Yes, grant full access to the user  & then click next
 *  10.click execute in apply configuration page & then finish
 *  11.click on product configuration click next & then finish.
 *  
 *  Open Mysql workbench , you can see local instance MYSQL80 connect to it & give the root password BlackHawkDown@143 &
 *  click ok. We've successfully installed MYSQL workbench.
 *  
 *  Before working on the MYSQL we've to connect all the files & packages to the server.
 *  so go to the C:\Program Files\MySQL\MySQL Server 8.0\bin location path , copy the location address as
 *  this C:\Program Files\MySQL\MySQL Server 8.0\bin then, open command prompt & 
 *  type ' cd C:\Program Files\MySQL\MySQL Server 8.0\bin ' and click enter
 *  Then type -u root -p  & click enter -->here -u is the root user which we have taken & -p is the password of the user
 *  it will ask you to enter the password , now type the root password BlackHawkDown@143 & click enter
 *  Now, we have successfully installed all the files & packages  into the server
 *  
 *  
	INT                           -- Whole Numbers
	DECIMAL(M,N)                  -- Decimal Numbers - Exact Value
	VARCHAR(l)                    -- String of text of length l
	BLOB                          -- Binary Large Object, Stores large data
	DATE                          -- 'YYYY-MM-DD'
	TIMESTAMP                     -- 'YYYY-MM-DD HH:MM:SS' - used for recording events

	------------------------- Creating tables-------------------
	CREATE TABLE student ( 
  	student_id INT PRIMARY KEY, -- here PRIMARY KEY(student_id)
  	name VARCHAR(40),
  	major VARCHAR(40)
	);

	DESCRIBE student;
	DROP TABLE student;
	ALTER TABLE student ADD gpa DECIMAL(3,2);
	ALTER TABLE student DROP COLUMN gpa;
	
	-------------------------Inserting into tables------------------------------	
	INSERT INTO student VALUES(1, 'Jack', 'Biology');
	INSERT INTO student VALUES(2, 'Kate', 'Sociology');
	INSERT INTO student(student_id, name) VALUES(3, 'Claire'); --if student don't have a major
	INSERT INTO student VALUES(4, 'Jack', 'Biology');
	INSERT INTO student VALUES(5, 'Mike', 'Computer Science');
	SELECT * FROM student;
	
	------------------------Constraints in the SQl------------------------------
	DROP TABLE student;
	CREATE TABLE student (
  	student_id INT AUTO_INCREMENT,
  	name VARCHAR(40) NOT NULL,   -->it cannot have a null value in the table
  	name VARCHAR(40) UNIQUE,	 -->name should be unique for each row in the table
  	major VARCHAR(40) DEFAULT 'undecided',   -->keeping a default value in sql table
  	PRIMARY KEY(student_id)		 -->primary key is basically a not null & unique
	);
	DROP TABLE student;

	-------------------------UPDATE & DELETE-------------------------------------
	CREATE TABLE student ( 
  	student_id INT PRIMARY KEY, -- here PRIMARY KEY(student_id)
  	name VARCHAR(40),
  	major VARCHAR(40)
	);
	INSERT INTO student VALUES(1, 'Jack', 'Biology');
	INSERT INTO student VALUES(2, 'Kate', 'Sociology');
	INSERT INTO student(student_id, name) VALUES(3, 'Claire'); --if student don't have a major
	INSERT INTO student VALUES(4, 'Jack', 'Biology');
	INSERT INTO student VALUES(5, 'Mike', 'Computer Science');
	SELECT * FROM student;
	
	
	DELETE FROM student;                    -->deletes all the data from student table
	DELETE FROM student WHERE student_id = 4;
	DELETE FROM student WHERE major = 'Sociology' AND name = 'Kate';
	UPDATE student SET major = 'Undecided';
	UPDATE student SET name = 'Johnny' WHERE student_id = 4;
	UPDATE student SET major = 'Biological Sciences' WHERE major = 'Biology';
	UPDATE student SET major = 'Biosociology' WHERE major = 'Biology' OR major = 'sociology'
	UPDATE student SET major = 'Undecided', name = 'Tom'WHERE student_id = 4;
	SELECT * FROM student;
	
	-----------------------------BASIC QUERIES-------------------------------------
	
	SELECT * FROM student;
	SELECT * FROM student ORDER BY major,student_id;
	SELECT * FROM student ORDER BY major,student_id DESC;
	SELECT * FROM student LIMIT 2;  -->it only displays two rows from the table
	SELECT * FROM student ORDER BY student_id DESC LIMIT 2;
	SELECT student.name, student.major FROM student;
	SELECT student.name, student.major FROM student ORDER BY name;
	SELECT student.name, student.major FROM student ORDER BY name DESC;
	SELECT * FROM student WHERE name = 'Jack';
	SELECT * FROM student WHERE student_id > 2;
 	SELECT * FROM student WHERE major = 'Biology' AND student_id > 1;
 	SELECT * FROM student WHERE major = 'Biology' OR major='Chemistry';  -->symbols in place of OR ,AND are <, >, <=, >=, =, <>, AND, OR
 	SELECT * FROM student WHERE name IN ('Claire', 'Kate', 'Mike');
	SELECT * FROM student WHERE major IN ('Biology', 'Chemistry') AND student_id>2;
	DROP TABLE student;
	
	-----------------------------Complex database ----------------------------------
	goto vs code-->HTML-FreeCodeCamoOrg folder-->html3.html file
	
	-----------------------------CREATING COMPLEX DATABASE-----------------------------------
	
	CREATE TABLE employee (
  		emp_id INT PRIMARY KEY,
  		first_name VARCHAR(40),
  		last_name VARCHAR(40),
    	birth_day DATE,
   	  	sex VARCHAR(1),
    	salary INT,
    	super_id INT,
    	branch_id INT
	);

	CREATE TABLE branch (
    	branch_id INT PRIMARY KEY,
    	branch_name VARCHAR(40),
    	mgr_id INT,
    	mgr_start_date DATE,
    	FOREIGN KEY(mgr_id) REFERENCES employee(emp_id) ON DELETE SET NULL
  	);

  	ALTER TABLE employee ADD FOREIGN KEY(branch_id) REFERENCES branch(branch_id) ON DELETE SET NULL;
	ALTER TABLE employee ADD FOREIGN KEY(super_id) REFERENCES employee(emp_id) ON DELETE SET NULL;

	CREATE TABLE client (
    	client_id INT PRIMARY KEY,
    	client_name VARCHAR(40),
   	   	branch_id INT,
    	FOREIGN KEY(branch_id) REFERENCES branch(branch_id) ON DELETE SET NULL
	);

	CREATE TABLE works_with (
    	emp_id INT,
    	client_id INT,
    	total_sales INT,
    	PRIMARY KEY(emp_id, client_id),
    	FOREIGN KEY(emp_id) REFERENCES employee(emp_id) ON DELETE CASCADE,
    	FOREIGN KEY(client_id) REFERENCES client(client_id) ON DELETE CASCADE
	);

	CREATE TABLE branch_supplier (
    	branch_id INT,
    	supplier_name VARCHAR(40),
    	supply_type VARCHAR(40),
    	PRIMARY KEY(branch_id, supplier_name),
    	FOREIGN KEY(branch_id) REFERENCES branch(branch_id) ON DELETE CASCADE
	);

	-- -----------------------------------------------------------------------------

	-- Corporate
	INSERT INTO employee VALUES(100, 'David', 'Wallace', '1967-11-17', 'M', 250000, NULL, NULL);
	INSERT INTO branch VALUES(1, 'Corporate', 100, '2006-02-09');

	UPDATE employee SET branch_id = 1 WHERE emp_id = 100;
	INSERT INTO employee VALUES(101, 'Jan', 'Levinson', '1961-05-11', 'F', 110000, 100, 1);

	-- Scranton
	INSERT INTO employee VALUES(102, 'Michael', 'Scott', '1964-03-15', 'M', 75000, 100, NULL);
	INSERT INTO branch VALUES(2, 'Scranton', 102, '1992-04-06');

	UPDATE employee SET branch_id = 2 WHERE emp_id = 102;

	INSERT INTO employee VALUES(103, 'Angela', 'Martin', '1971-06-25', 'F', 63000, 102, 2);
	INSERT INTO employee VALUES(104, 'Kelly', 'Kapoor', '1980-02-05', 'F', 55000, 102, 2);
	INSERT INTO employee VALUES(105, 'Stanley', 'Hudson', '1958-02-19', 'M', 69000, 102, 2);

	-- Stamford
	INSERT INTO employee VALUES(106, 'Josh', 'Porter', '1969-09-05', 'M', 78000, 100, NULL);
	INSERT INTO branch VALUES(3, 'Stamford', 106, '1998-02-13');

	UPDATE employee SET branch_id = 3 WHERE emp_id = 106;

	INSERT INTO employee VALUES(107, 'Andy', 'Bernard', '1973-07-22', 'M', 65000, 106, 3);
	INSERT INTO employee VALUES(108, 'Jim', 'Halpert', '1978-10-01', 'M', 71000, 106, 3);

	-- BRANCH SUPPLIER
	INSERT INTO branch_supplier VALUES(2, 'Hammer Mill', 'Paper');
	INSERT INTO branch_supplier VALUES(2, 'Uni-ball', 'Writing Utensils');
	INSERT INTO branch_supplier VALUES(3, 'Patriot Paper', 'Paper');
	INSERT INTO branch_supplier VALUES(2, 'J.T. Forms & Labels', 'Custom Forms');
	INSERT INTO branch_supplier VALUES(3, 'Uni-ball', 'Writing Utensils');
	INSERT INTO branch_supplier VALUES(3, 'Hammer Mill', 'Paper');
	INSERT INTO branch_supplier VALUES(3, 'Stamford Lables', 'Custom Forms');
	SELECT * FROM branch_supplier;

	-- CLIENT
	INSERT INTO client VALUES(400, 'Dunmore Highschool', 2);
	INSERT INTO client VALUES(401, 'Lackawana Country', 2);
	INSERT INTO client VALUES(402, 'FedEx', 3);
	INSERT INTO client VALUES(403, 'John Daly Law, LLC', 3);
	INSERT INTO client VALUES(404, 'Scranton Whitepages', 2);
	INSERT INTO client VALUES(405, 'Times Newspaper', 3);
	INSERT INTO client VALUES(406, 'FedEx', 2);
	SELECT * FROM client;
	
	-- WORKS_WITH
	INSERT INTO works_with VALUES(105, 400, 55000);
	INSERT INTO works_with VALUES(102, 401, 267000);
	INSERT INTO works_with VALUES(108, 402, 22500);
	INSERT INTO works_with VALUES(107, 403, 5000);
	INSERT INTO works_with VALUES(108, 403, 12000);
	INSERT INTO works_with VALUES(105, 404, 33000);
	INSERT INTO works_with VALUES(107, 405, 26000);
	INSERT INTO works_with VALUES(102, 406, 15000);
	INSERT INTO works_with VALUES(105, 406, 130000);
	SELECT * FROM works_with;
	
	
	----------------------------------MORE BASIC QUERIES---------------------------------------------
	-- Find all employees
	SELECT * FROM employee;
	-- Find all clients
	SELECT * FROM clients;
	-- Find all employees ordered by salary
	SELECT * from employee ORDER BY salary ASC/DESC;
	-- Find all employees ordered by sex then name
	SELECT * from employee ORDER BY sex, name;
 	-- Find the first 5 employees in the table
 	SELECT * from employee LIMIT 5;
	-- Find the first and last names of all employees
	SELECT first_name, employee.last_name FROM employee;
	-- Find the forename and surnames names of all employees
	SELECT first_name AS forename, employee.last_name AS surname FROM employee;
	-- Find out all the different genders
	SELECT DISCINCT sex FROM employee;
	-- Find all male employees
	SELECT * FROM employee WHERE sex = 'M'; 
	-- Find all employees at branch 2
	SELECT * FROM employee WHERE branch_id = 2;
	-- Find all employee's id's and names who were born after 1969
	SELECT emp_id, first_name, last_name FROM employee WHERE birth_day >= 1970-01-01;
	-- Find all female employees at branch 2
	SELECT * FROM employee WHERE branch_id = 2 AND sex = 'F'; 
	-- Find all employees who are female & born after 1969 or who make over 80000
	SELECT * FROM employee WHERE (birth_day >= '1970-01-01' AND sex = 'F') OR salary > 80000; 
	-- Find all employees born between 1970 and 1975
 	SELECT * FROM employee WHERE birth_day BETWEEN '1970-01-01' AND '1975-01-01'; 
 	-- Find all employees named Jim, Michael, Johnny or David
	SELECT * FROM employee WHERE first_name IN ('Jim', 'Michael', 'Johnny', 'David');
	
	
	-----------------------------------SQL FUNCTIONS-----------------------------------
	
	-- Find the number of employees
	SELECT COUNT(super_id) FROM employee;
	-- Find the average of all employee's salaries
	SELECT AVG(salary) FROM employee;
	-- Find the average of all employee's salaries where sex='M'
	SELECT AVG(salary) FROM employee WHERE sex='M';
	-- Find the sum of all employee's salaries
	SELECT SUM(salary) FROM employee; 
	-- Find out how many males and females there are
	SELECT COUNT(sex), sex FROM employee GROUP BY sex
	-- Find the total sales of each salesman
	SELECT SUM(total_sales), emp_id FROM works_with GROUP BY client_id;
	-- Find the total amount of money spent by each client
	SELECT SUM(total_sales), client_id FROM works_with GROUP BY client_id;
	
	
	----------------------WILD CARDS IN SQL-------------------------------------
	--wildcards are used to find then patterns in the database
	-- % = any # characters, _ = one character  
	-- Find any client's who are an LLC
	SELECT * FROM client WHERE client_name LIKE '%LLC';   --if the client name matches the specific characters , here % say any no.of character so %LLC any no.of characters with LLC
 	-- Find any branch suppliers who are in the label business
	SELECT * FROM branch_supplier WHERE supplier_name LIKE '% Label%';
	-- Find any employee born on the 10th day of the month
	SELECT * FROM employee WHERE birth_day LIKE '_____10%'; --gives all the birthdays in october _____ says YYYY- 
	-- Find any clients who are schools
	SELECT * FROM client WHERE client_name LIKE '%Highschool%';


	-------------------------------Unions in SQL--------------------------------		
	-->union is used to combine the results of multiple select statements into one 
	-->union should have same number of columns in there select statement , if a select statement has two columns & other
	   select statement has one column it throws an error
	-- Find a list of employee and branch names
	SELECT employee.first_name AS Employee_Branch_Names FROM employee UNION SELECT branch.branch_name FROM branch;
	-- Find a list of all clients & branch suppliers' names
	SELECT client.client_name AS Non-Employee_Entities, client.branch_id AS Branch_ID FROM client UNION SELECT branch_supplier.supplier_name, branch_supplier.branch_id FROM branch_supplier;
	--Find a list of all money spent or earned by the company
	SELECT salary FROM employee UNION SELECT total_sales FROM works_with;
	
	
	--------------------------------JIONS In SQL---------------------------------------
	joins-->combining tables based on related information(columns)
	
	-- Add the extra branch
	INSERT INTO branch VALUES(4, "Buffalo", NULL, NULL);

	SELECT employee.emp_id, employee.first_name, branch.branch_name
	FROM employee
	JOIN branch    -- LEFT JOIN, RIGHT JOIN
	ON employee.emp_id = branch.mgr_id;
	
	
	---------------------------------Nested Queries----------------------------------------
	A query using multiple select statements is called Nested Queries
	
	-- Find names of all employees who have sold over 50,000
	SELECT employee.first_name, employee.last_name FROM employee
	WHERE employee.emp_id IN (SELECT works_with.emp_id FROM works_with WHERE works_with.total_sales > 50000);

	-- Find all clients who are handles by the branch that Michael Scott manages
	-- Assume you know Michael's ID
	SELECT client.client_id, client.client_name FROM client
	WHERE client.branch_id = (SELECT branch.branch_id FROM branch WHERE branch.mgr_id = 102);

 	-- Find all clients who are handles by the branch that Michael Scott manages
 	-- Assume you DONT'T know Michael's ID
 	SELECT client.client_id, client.client_name FROM client
 	WHERE client.branch_id = (SELECT branch.branch_id FROM branch WHERE branch.mgr_id = (SELECT employee.emp_id
                              FROM employee WHERE employee.first_name = 'Michael' AND employee.last_name ='Scott' LIMIT 1));

	-- Find the names of employees who work with clients handled by the scranton branch
	SELECT employee.first_name, employee.last_name FROM employee WHERE employee.emp_id IN (
                      SELECT works_with.emp_id FROM works_with ) AND employee.branch_id = 2;

	-- Find the names of all clients who have spent more than 100,000 dollars
	SELECT client.client_name FROM client WHERE client.client_id IN (SELECT client_id FROM ( SELECT SUM(works_with.total_sales) AS totals, client_id
                                FROM works_with GROUP BY client_id) AS total_client_sales WHERE totals > 100000
);

	------------------------delete entries when they've foreign key associated with-----------------------------------
	--ON DELETE SET NOW
	
	CREATE TABLE branch(
		branch_id INT PRIMARY KEY,
		branch_name VARCHAR(40),
		mgr_id INT,
		mgr_start_date DATE,
		FOREIGN KEY(mgr_id) REFERENCES employee(emp_id) ON DELETE SET NULL  -->So if the employee_id is deleted we want to set the manager_id as NULL
	);
	DELETE FROM EMPLOYEE WHERE EMP_ID=102;
	SELECT * FROM BRANCH;
	SELECT * FROM EMPLOYEE;
	
	--ON DELETE CASCADE

	CREATE TABLE branch_supplier(
		branch_id INT;
		supplier_name VARCHAR(40);
		supply_type VARCHAR(40);
		PRIMARY KEY (branch_id,supplier_name),
		FOREIGN KEY(branch_id) REFERENCES branch(branch_id) ON DELETE CASCADE  -->if brancg id from branch table is deleted then all the rows in the
																				 branch supplier having branch_id gets deleted 
	);
	
	
	DELETE FROM branch WHERE branch_id=2;
	SELECT * FROM branch_supplier;
	SELECT * FROM branch;
	
	
	-------------------------------------TRIGGERS------------------------------------------
	-->Block of SQL code which will define a certain action that should happen when certain operation gets performed on
	   the database.
	   
	   
	-- CREATE
	--     TRIGGER `event_name` BEFORE/AFTER INSERT/UPDATE/DELETE
	--     ON `database`.`table`
	--     FOR EACH ROW BEGIN
	-- 		-- trigger body
	-- 		-- this code is applied to every
	-- 		-- inserted/updated/deleted row
	--     END;

	CREATE TABLE trigger_test (
     	message VARCHAR(100)
	);
 
	DELIMITER $$
	CREATE
    	TRIGGER my_trigger BEFORE INSERT
    	ON employee
    	FOR EACH ROW BEGIN
        	INSERT INTO trigger_test VALUES('added new employee');
    	END$$
	DELIMITER ;  -->changing delimeter from $$ to ;
	
	INSERT INTO employee VALUES(109, 'Oscar', 'Martinez', '1968-02-19', 'M', 69000, 106, 3);
	SELECT * FROM trigger_test;


		DELIMITER $$
	CREATE
    	TRIGGER my_trigger BEFORE INSERT
    	ON employee
    	FOR EACH ROW BEGIN
        	INSERT INTO trigger_test VALUES(NEW.first_name); -->to access a particular attribute/specific column we have inserted
    	END$$
	DELIMITER ;
	
	INSERT INTO employee VALUES(110, 'Kevin', 'Malone', '1978-02-19', 'M', 69000, 106, 3);
	SELECT * FROM trigger_test;
	
	
	DELIMITER $$
	CREATE 
    	TRIGGER my_trigger BEFORE INSERT   -->we can do it with update ,delete instead of insert & also After in place of before
    	ON employee
    	FOR EACH ROW BEGIN
         	IF NEW.sex = 'M' THEN
               	INSERT INTO trigger_test VALUES('added male employee');
         	ELSEIF NEW.sex = 'F' THEN
               	INSERT INTO trigger_test VALUES('added female');
         	ELSE
               	INSERT INTO trigger_test VALUES('added other employee');
         	END IF;
    	END$$
	DELIMITER ;
	
	INSERT INTO employee VALUES(111, 'Pam', 'Beesly', '1988-02-19', 'F', 69000, 106, 3);
	SELECT * FROM trigger_test;


	DROP TRIGGER my_trigger;
	
	
	------------------------------------ER DIAGRAMS INTRO---------------------------------
	ER-->ENTITY RELATIONSHIP
	Entity-->An object we want to model & store information about
	Attributes-->Specific pieces of information about an entity
	Primary key-->An attribute(s) that uniquely identify an entity in the database table
	composite attribute -->An attribute that can be broken up into sub-attributes.
														 /---[fname]
														/
								[student]---------[name]
														\
														 \---[lname]
					name can be broken into two parts as fname & lname
	Multi-valued Attribute-->An attribute that can have more than one value
	Derived Attribute-->An attribute that can be derived from the other attributes
	Multiple Entities-->You can define more than one entity in the diagram
	Relationships-->defines a relationship between two entities.
	Total Participation-->All members must participate in the relationship
	single line-->partial participation;double line-->total participation
	Relationship Attribute-->An attribute about the relationship
	Relationship Cardinality-->the no.of instances of an entity from a relation that can be associated with the relation
								1:1 ; 1:N ; N:M
	Weak Entity-->An entity that cannot be uniquely identified by its attributes alone
	Identifying Relationship-->A relationship that serves to uniquily identify the weak entity.
	
	REFER HTML 3 FROM HTML-CODECAMP.ORG FOLDER FOR DIAGRAAMS

 *  
 */
}
