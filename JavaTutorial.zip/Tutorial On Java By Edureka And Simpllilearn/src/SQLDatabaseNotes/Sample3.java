package SQLDatabaseNotes;

//			SQL FOR DATA ANALYTICS SIMPLILEARN
public class Sample3 {
/*
 * Why we need database:-To avoid data redudancy & inconsistency, data isolation, limited data access, security & integrity issues
 *						   sql query							processing
 *			|			|  ---------->	|					|  ----------->	|				|
 *			|	USER	|				| DATABASE SERVER	|				|	DATA FOUND	|	
 *			|			| <-----------	|			^		|  <-----------	|				|
 *							retrieving		|		|
 *											|->SQl -|	
 *											 Engine
 *
 *	--------------------	TYPES OF SQL COMMANDS	------------------------------------------------
 *1. DATA DEFINITION LANGUAGE (DDL):DDL allows the user to define the table & change its overall structure
 *	commands used in DDL are CEREATE, ALTER, DROP, TRUNCATE. TRUNCATE is used to delete rows in the tables
 *2. DATA MANIPULATION LANGUAGE (DML): DML is used to access & manipulate the data. Commands used in the DML
 *	are SELECT, UPDATE, DELETE (used to delete specific row in the table) ,INSERT.
 *3. DATA CONTROL LANGUAGE (DCL):DCL is responsible for maintaing the security which gives controll access & persmission
 *	to the database. Commands that are used in the DCl are GRANT , REVOKE.
 *4. TRANSACTIONAL CONTROL LANGUAGE (DDL):TCL has 3 commands namely COMIT-->It is used to permanently save the transaction,
 *		ROLLBACK-->It is used to restore the transaction that is not saved, SAVEPOINT-->It is used to hold a transaction 
 *	 temporarily, it can rollback to its previous state at any point.
 *
 *	DISADVANTAGES OF SQL:-
 *	1.Complex interface,
 *	2.High operating cost: since it is a platform base languges most of the commercially available sql  servers are relatively
 *						  higher.
 *	3.High maintenance: sql is constantly working on high amounts of data it requires higher maintenance
 *
 *
 *---------------------------------------DBMS--------------------------------------------
 *DBMS-->DATA BASE +MANAGEMENT SYSTEM
 *
 *Levels of DBMS architecture:
 *
 *	User/External level							Logical/Conceptual level 	Physical / Internet level
 *
 *  [view 1 (for User)]		<-------------------->|				 |			 |				 |
 *  											  |				 |			 |				 |
 *  [view 2 (for Author)]	<-------------------->|Logical Schema|<--------->|Physical Schema| <------------>[server]
 *  											  |				 |			 |				 |
 *  [view N (for Admin)]	<-------------------->|				 |			 |				 |
 *  
 *  
 *  Types of DBMS Architecture:	
 *  														 
 *  1.Single Tier Architecture/local database system:- 			
 *  
 *  						direct access
 *  		[END USER]		<----------->		[DATABASE SYSTEM]
 *  	
 *  
 *  2.Two Tier Architecture:-	helps to access the database with the help of an application
 *  
 *  	[DATABASE SYSTEM]		<------------>			[DTABASE APPLICATION<->DATABASE USER]
 *  	  SERVER LEVEL											CLIENT LEVEL
 *  3.Three Tier Architecture:-In this architecture the client database application doesn't communicate directly with
 *   the database system present at the server machine, instead the client application communicates with the server 
 *   application & then internally communicates with database system present at the server
 *   
 *   [DATABASE SYSTEM]	<---> [APPLICATION SERVER]   <---->   [DATABASE APPLICATION <--->DATABASE USER]
 *    SERVER LEVEL													CLIENT LEVEL
 *    
 *    ----------------------------------------------RDBM---------------------------------------------------------
 *    RDBMS:-Relational database management system stores data in the form of tables
 *    
 *    			 RDBMS 						VS						DBMS
 *    1.Stores data in tables				 | 1.Stores data in files
 *    2.Handles large amount of data		 | 2.Handles small amount of data
 *    3.Supports multiple users				 | 3.Supports single user at a time
 *    4.Supports distributed database		 | 4.No support for distributed database
 *    
 *    Types of keys in DBMS:-
 *    1.Primary key:uniquely identifies every row in a table.
 *    2.Super key:Contains additional or other sets of attributes that uniquely identify a row within a table.
 *    3.Candidate key:These are selected from the set of super keys & the only diference is it shouldn't have repeated
 *    				  attributes.it is also called as minimal super key
 *    4.Foreign key: It is used to create a relationship between two tables with the help of a already existing table.
 *    
 *    Advantages of DBMS:
 *    1.Reduced data redundancy
 *    2.Data Integrity
 *    3.Data Privacy & security
 *    4.Data Consistency
 *    5.Ease of sharing data
 *    6.Backup & recovery.
 *    
 *    SQL DATATYPES:-
 *    NUMERIC-->INT -->holds values of integers without any decimal point, further divided into SMALL INT & BIG INT
 *    				 according to size.
 *    		   BIT-->holds null, 0 or 1 numbers
 *    		   FLOAT-->stores numbers having decimal values
 *    		   BOOLEAN-->used to give true or false . zero is considered as false whereas non zero is considered as true
 *    STRING DATA-->CHAR-->used to specify a fixed length string that can contain number ,letters & special characters.
 *    					   size can be 0 to 255 characters.
 *    			    VARCHAR-->similar to char but it stores variables , length strings & size of varchar is also more than
 *    						  char datatype with a range of 0 to 66,000 characters
 *    				TEXT-->holds any kind of text data
 *    DATETIME-->DATE-->used to specify date i.e. YYYY-MM-DD
 *    			 DATETIME-->used to specify the combination of both day & time. YYYY-MM-DD HH-MM-SS
 *    			 TIMESTAMP-->similar to datetime but the difference is it has less range of values to store.it used to convert
 *    						 time into various timeszones like IST etc.
 *    			 
 *    XML & JASON Datetypes
 *    			
 *    
 *    SYNTAX OF GRANT & REVOKE:---
 *    GRANT <PRIVILEGE LIST> ON <TABLE NAME> FROM <USER>;
 *    eg.GRANT INSERT,SELECT ON EMPLOYEE TO RAHUL;
 *    
 *    REVOKE <PRIVILEGE LIST> ON <TABLE NAME> FROM <USER>;
 *    e.g:REVOKE INSERT ON EMPLOYEE FROM RAHUL;
 *    
 *    
 *    CREATING A DATABASE IN MYSQL:-
 *    SYNTAX: CREATE DATABASE DatabaseName;
 *     E.G:CREATE DATABASE SQLSIMPLILEARNDATAANALYTICS;		-->creating database
		   SHOW DATABASES;									-->Showing databases 
		   DROP DATABASE SQL_Simplilearn_DataAnalytics; 	-->deleting the database 
		   SELECT current_user();							-->Showing current user
		   
		   
	  SELECTING A DATABASE:--
	  SYNTAX: USE DatabaseName;
	   E.g: USE SQL_Simplilearn_DataAnalytics;   -->selecting a database
	   If you dont select a database then you have to mention database_name.table_name every time when you need to perfrom
	   a task
	   
	   TYPES OF SQL EXPRESSION:
	   SQL expression are of three types:- Boolean, Numeric, Date.
	   E.G:-CREATE TABLE student(   -->creating table , if you don't select database then you've to create table with database_name.table_name
			   `roll no` INT NOT NULL,
			   `name` VARCHAR(45) NULL, 
			   `age`  VARCHAR(45) NULL,
			   `city` VARCHAR(45) NULL,
			   `date of birth` DATE NULL,
			   `stream` VARCHAR(45) NULL,
			   `total marks` VARCHAR(45) NULL,
			   PRIMARY KEY (`roll no`) );

		    INSERT INTO student VALUES (1,'ROHAN','21','BANGALORE','1996-06-26','CSE',977);
		    INSERT INTO student VALUES (2,'AMAN','22','PUNE','1995-05-14','EEE',922);
		    INSERT INTO student VALUES (3,'DIVYA','21','KOCHI','1996-01-20','ECE',935);
		    INSERT INTO student VALUES (4,'PRATEEK','20','HYDERABAD','1997-02-11','CSE',988);
		    INSERT INTO student VALUES (5,'NITYA','23','CHENNAI','1994-10-21','IT',942);
		    INSERT INTO student VALUES (6,'SUHANA','24','MUMBAI','1993-08-17','MECH',931); 
		    INSERT INTO student VALUES (7,'ADITYA',22,'CHENNAI','1995-02-21','ECE',968);  -->even though we declared varchar for age we dont have to write 
			INSERT INTO student VALUES (8,'INDRA','25','PUNE','1992-05-11','MBA',972); 					varchar if it's a number.
		    SELECT * FROM STUDENT;
		    
		    SELECT * FROM STUDENT WHERE `TOTAL MARKS`/2>480; 				-->numeric condition 
		    SELECT AVG(`TOTAL MARKS`) FROM STUDENT; 						-->Average of total marks
			SELECT SUM(`TOTAL MARKS`) FROM STUDENT;							-->sum of total marks
			SELECT * FROM STUDENT WHERE `date of birth`>'1995-01-01';		-->displaying value > given date
			SELECT current_timestamp();										-->to know about current date and time
			SELECT current_time();											-->to know about current time
			SELECT current_date();											-->to know about current date
			DROP TABLE STUDENT;												-->after this drop the table
			
			In table rows are also called as TUPLES whereas columns are also called as ATTRIBUTES
			
	 BASIC QUERIES IN TABLE:
		1.DELETE FROM TABLENAME  							-->deletes all the rows in the table
		2.DELETE FROM TABLENAME WHERE CONDITION;			-->delete a row from table with the given condition
		3.TRUNCATE TABLE TABLENAME							-->used to remove all the rows/data from the table , it is 
									similar to delete statement but donot use where clause & trancate is faster,drop is
									also used to delete complete data but it also deletes the structure of the table
		4.ALTER TABLE TableName ADD/MODIFY/DELETE CONDITION;-->used to add , modify & delete columns of an existing table
		5.ALTER TABLE CurrTableName RENAME TO NewTableName; -->changing the existing name & column of a table in a database.
		6.SELECT * INTO FROM NEW_TABLE_NAME FROM OLD_TABLE_NAME; -->Copy the data from an existing table into another SQL table
 *    	   E.g:-CREATE TABLE employee_details SELECT * FROM EMPLOYEE; --> Above query is written in MYSQL in this form
 *    
 *    
 *    WHAT IS SQL SELECT STATEMENT:-
 *    Retrive data from one or more database tables
 *    SYNTAX: 	SELECT Column_1, Column_2,...,Column_N FROM Table_Name;
 *    			SELECT * FROM Table_Name;
 *    			SELECT * FROM Table_Name WHERE CONDITION;	
 *    			SELECT DISTINCT Column_name FROM TABLE_NAME -->used to fetch distinct/unique column values from the existing table
 *    			SELECT COUNT(*) FROM TABLE_NAME-->used to display total number of rows in a table.
 *    			SELECT COUNT(*) FROM TABLE_NAME WHERE CONDITION; -->gives total rows satisfying the given condition
 *    				E.g:-SELECT COUNT(*) FROM EMPLOYEE WHERE SALARY=50000; 
 *    			SELECT COUNT(DISTINCT COLUMN_NAME) FROM TABLE_NAME; -->gives total rows which are distinct in nature
 *    				E.g:-SELECT COUNT(DISTINCT city) FROM Employee;
 *    			SELECT TOP/LIMIT -->shows the limited no.of rows /records in the table & the top clause in statement
 *    							 specifies how many rows we want to specify from our table.This clause is used when there 
 *    							are thousands of records stored in the table
 *    				E.g:-SELECT * FROM EMPLOYEE LIMIT 3;
 *    					 SELECT * FROM EMPLOYEE ORDER BY SALARY DESC LIMIT 2;
 *    			SELECT RANDOM-->used to return a random row from a table present in the database
 *    				E.g: SELECT * FROM EMPLOYEE ORDER BY RAND();
 *    					 SELECT * FROM EMPLOYEE ORDER BY RAND() LIMIT 4;
     			SELECT IN -->select in function is used to specific rows or values from a existing table wth multiple conditions
     				E.g:-SELECT * FROM EMPLOYEE WHERE EMP_ID IN(102,104,107);
     			SELECT DATE -->used to retrive the value of date from the database
     				E.g:-SELECT * FROM EMPLOYEE WHERE `date of birth`>'1995-01-01';
     			SELECT SUM-->used to  return some of the all the values in the specified column
     				E.g:-SELECT SUM(`TOTAL MARKS`) FROM STUDENT;
     					 SELECT SUM(`TOTAL MARKS`) FROM STUDENT WHERE CITY='MUMBAI';
     			SELECT NULL-->used to represent the missing data in the table
     				E.g:-SELECT * FROM STUDENTS WHERE MARKS IS NULL;
     			SELECT AS -->used to temporarily change the column name for bettwe understanding
     				E.g:-SELECT SALARY AS 'TOTAL_SALARY' FROM EMPLOYEE;
     			SELECT LIKE-->used to display value which have the given condition
     				E.g:-SELECT * FROM EMPLOYEE WHERE EMPNAME LIKE 'k%';-->displays empname that starts with k
     				 	 SELECT * FROM EMPLOYEE WHERE EMPNAME LIKE '%a';-->displays empname that ends with a
     				 	 
     				 	 
      ORDER BY: ORDER BY clause in SQL is used to sort the records in the database tables.It can be arranged in either
      			Ascending or Descending order.
      		
      		E.g:- SELECT * FROM EMPLOYEE ORDER BY DESIGNATION ASC ,SALARY DESC;  -->ORDER BY MULTIPLE
     			
     			
 *     */	
}
