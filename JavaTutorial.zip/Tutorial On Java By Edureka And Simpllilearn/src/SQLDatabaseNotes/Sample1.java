package SQLDatabaseNotes;

public class Sample1 {
	/*
	 * A database is a collection of related data stored electronically in a systematic manner.
	 * 
	 * DBMS:A Database Management System is software designed to store, retrive define & manage
	 * data is database.Stores data as file Examples of DBMS are a file system, XML,Windows 
	 * Registry,etc.
	 * 
	 * RDBMS: Relational Database Management System(RDBMS) is an advanced version of DBMS,RDBMS
	 * stores data in tabluar form Example of RDBMS is MYSQL,Oracle,SQL Server, etc.
	 * 
	 * 									Database Table
	 * Tables are database objects that contain all the data in a databse.
	 * In tables , data is logically organized in a row-and-colum format
	 * Each row represent a unique record
	 * Each Column represents a field in the record.
	 * 									
	 * 										SQL
	 *Structured Query Language.
	 *SQL is a standard programming langugae.
	 *SQL designed for storing ,retrieving, managing or manipulating the data inside a relational
	 *database management system RDBMS.
	 *										
	 *						What we can do with SQL	
	 *There are lot more things we can do with SQl
	 *	i.we can create a database
	 *	ii.We can create tables in a database.
	 *	iii.we can query or request information from a database.
	 *	iv.we can insert records in a database.
	 *	v.we can update or modify records in a database.
	 *	vi.we can delete records from the database.
	 *	vii.we can set permissions or access control within the database for data security
	 *  viii.we can create views to avoid typing frequently used complex queries.
	 *
	 *						DataTypes in SQl
	 *INT				-Whole Numbers
	 *DECIMAL(M,N) 		-Decimal Numbers-Exact Value
	 *VARCHAR(Length)	-String of text length
	 *BLOB				-Binary Large Object,Store Large data such as file or image
	 *DATE				-User for Date 'YYYY-MM-DD'
	 *TIMESTAMP			-'YYYY-MM-DD HH-MM-SS'use for Recording
	 *						
	 			 	-----------Create TABLE-------------
	 --Rules for creating table :
	 `		Table name can be maximum of upto 30 characters. 
	 		we can write table name with single or double quotation.
	 		Fields will always be in parenthessis and end will be with semicolon;
	  
	  SYNTAX:
	  
	  		CREATE TABLE TABLE_NAME(FIELD_NAME1 FIELD_DATATYPE,FILED_NAME2 FIELD_DATATYPE,...);
	  	
	  	CREATE TABLE EMP(
							emp_id NUMBER PRIMARY KEY, emp_name VARCHAR2(20), emp_salary DECIMAL(10,2)
		);
		
		To see a table attribute details we will use 	-	 DESC TABLE_Name
	
	 							
	 				--------------INSERT STATEMENT-------------------
	 							
	 SYNTAX:
	 
	 	 INSERT INTO TABLE_NAME VALUES(NUMBER,'FOR CHARACTERS/VARCHAR',..);
	 	 
	 	 eg.INSERT INTO EMP VALUES(1,'Ahmad',40000);
			INSERT INTO EMP VALUES(2,'Mark',35000);
			INSERT INTO EMP VALUES(3,'Abid',50000);
			INSERT INTO EMP VALUES(4,'Rahul',45000);
	 
	 							
	 							
	 				-------------------SELECT STATEMENT--------------------
	To view the data in a SQL Table , we use SELECT Statement & we use SELECT statment to view a particular data aswell.
	 
	 SYNTAX:
	 
	 	 SELECT * FROM TABLE_NAME;  -->To view entire data in a table
	 	 SELECT * FROM TABLE_NAME WHERE TABLE_PARAMETER_CONDITION --->To view particular data in a table
	 	 SELECT PARRAMETER_NAME FROM TABLE_NAME WHERE PARAMETER_VALUE='VALUE';-->To get a value if it is present in the table
	 	 
	 e.g: SELECT * FROM EMP;--->gives all the table data
	 	  SELECT * FROM EMP WHERE EMP_ID=4;---->gives data of the table where emp_id=4
	 	  SELECT EMP_NAME FROM EMP WHERE EMP_NAME='ABID';--->to get the name if it is present in the table
	 	  SELECT * FROM EMP WHERE EMP_SALARY>40000;--->To get all the data where emp_salary>40000
	 	  
	 	  
	 	  
------------------------------------------UPDATE STATEMENT--------------------------------------------------------------
	 Used to update the value of the data in a SQL Table.
	 
	 SYNTAX:
	 
	 	UPDATE TABLENAME SET UPDATING_PARAMETER_NAME='UPDATING_VALUE' WHERE UPDATING_PARAMETER_CONDITION
	 	
	 E.g: UPDATE  EMP  SET EMP_SALARY='50000' WHERE EMP_ID=4; -->Updates salaray where id=4
	 	  UPDATE  EMP  SET EMP_SALARY='60000';--->This will update all the members salary by 60000 if there's no where condition
	 	  UPDATE  EMP  SET EMP_SALARY='60000' WHERE EMP_SALARY='50000'; --->Updates salary by 60000 for all the emps having salary =50000

	 	   
	 	  		 ------------------------DELETE STATEMENT--------------------------------	 
	We can delete the data from the table using DELETE statement. we can delete single record & also multiple records from
	the table
	
	SYNTAX:
	
	  DELETE FROM TABLE_NAME --->Deletes all the records from the Table
	  DELETE FROM TABLE_NAME WHERE DELETING_PARAMETER_CONDITION---> Deletes record from table where deleting condition is satisfied
	 
	E.g: DELETE FROM EMP WHERE EMP_ID=4;-->deletes the record where emp_id=4
	
	
	 	  		 ------------------------ORDER BY--------------------------------		
	=>The ORDER BY clause is used to sort the data returned by a query in ascending or descending order
	=>The basic syntax of this clause can be given with
	
	 SELECT COLUMN_LIST FROM TABLE_NAME ORDER BY COLUMN_NAME ASC|DESC;
	 
	 E.g: SELECT * FROM EMP ORDER BY EMP_ID DESC;--->orders the data by keeping emp_id in descending order
	 	  SELECT * FROM EMP ORDER BY EMP_ID ASC;---->Orders the data by keeping emp_id in ascending order
	 	  SELECT EMP_NAME FROM EMP ORDER BY EMP_ID DESC;--->displays emp_name field record in the emp table by keeping emp_id in desceding order
	 	   
	 	   
	 	  		 ------------------------DISTINCT Clause--------------------------------		 	    
	=>The DISTINCT clause is use to remove duplicate rows from the result set
	
	 SELECT DISTINCT column_list FROM table_name;  -->fetches unique record from the database 
	 
	 E.g:SELECT DISTINCT EMP_NAME FROM EMP;-->displays unique emp_name values
		 SELECT DISTINCT EMP_NAME,EMP_SALARY FROM EMP;-->displays unique emp_name & emp_salary records


	 	  		 ------------------------TRUNCATE TABLE Statement--------------------------------	
	=>The TRUNCATE TABLE statement removes all the rows from a table more quickly than a DELETE.
	=>Logically, TRUNCATE TABLE is similar to the DELETE statement with no WHERE clause.
	
	 TRUNCATE TABLE table_name
	 
	 E.g: TRUNCATE TABLE EMP;-->removes all the data from the table emp
	 

	 	  		 ------------------------DROP TABLE Statement--------------------------------	
	=>The DROP TABLE removes one or more tables
	
	  DROP TABLE table1_name,table2_name,........;
	  
	  E.g:DROP TABLE EMP;-->emp table is dropped permanently
	  
	  
	 	  		 ------------------------Table Relationship--------------------------------		  
	=>A TABLE RELATIONHIP is established when a child table defines a FOREIGN KEY column that references the PRIMARY KEY
	column of its parent table.
	=>ONE TO ONE:-One record in a table is associated with one & only one record.
	=>ONE TO MANY:One record in a table can be associated with one or more records in another table.
	=>MANY TO MANY:Multiple records in a table are associated with multiple records in another table.
	
	E.g: Lets create a department table acting as parent table & employee table as child table.
		CREATE TABLE DEPARTMENT(DEP_ID INT NOT NULL PRIMARY KEY,DEPT_NAME VARCHAR2(50));-->parent table
		CREATE TABLE EMPLOYEE(EMP_ID INT NOT NULL PRIMARY KEY,EMP_NAME VARCHAR2(20),EMP_SALARY DECIMAL(10,2),DEPT_ID INTEGER REFERENCES DEPARTMENT(DEP_ID));-->child table
	
		INSERT INTO DEPARTMENT VALUES(1,'IT');
		INSERT INTO DEPARTMENT VALUES(2,'HR');
		INSERT INTO DEPARTMENT VALUES(3,'MEDICAL');
		INSERT INTO DEPARTMENT VALUES(4,'QUALITY');
		SELECT * FROM DEPARTMENT;

		INSERT INTO EMPLOYEE VALUES(1,'AHMAD',40000,1);
		INSERT INTO EMPLOYEE VALUES(2,'MARK',35000,2);
		INSERT INTO EMPLOYEE VALUES(3,'ABID',50000,2);
		INSERT INTO EMPLOYEE VALUES(4,'RAHUL',45000,1);
		SELECT * FROM EMPLOYEE;
		INSERT INTO EMPLOYEE VALUES(5,'RAHUL',45000,5); -->gives error as parent key is not found


	 	  		 ------------------------AND & OR OPERATORS--------------------------------	
	-------------AND OPERATOR---------------
	=>The AND operator is a logical operator that combines two conditions & returns TRUE only if both condition evaluate to
	  TRUE.
	=>The AND operator is often used in the WHERE clause of the SELECT, UPDATE, DELETE statement to form conditions to filter
	  the result set
	  
	SYNTAX:
	  SELECT column1_name,column2_name, columnN_name
	  FROM table_name
	  WHERE condition1 AND condition2;
	
	E.g:SELECT * FROM EMPLOYEE WHERE EMP_SALARY>35000 AND DEPT_ID=1;
	
	---------------OR OPERATOR---------------
	OR operator is also a logical operator that combines two conditions,but it returns TRUE when either of the conditions is TRUE
	
	E.g.:SELECT * FROM EMPLOYEE WHERE EMP_SALARY>35000 OR DEPT_ID=1;
	 	 SELECT * FROM EMPLOYEE WHERE EMP_SALARY>35000 AND (DEPT_ID=1 OR DEPT_ID=2);-->Using both AND & OR operators 
	 
	 	  		 ------------------------IN & NOT IN OPERATORS--------------------------------	
	--------------IN OPERATOR-------------------
	=>The IN operator is a logical operator & check a value within a set of values ad retrieve the rows/records from the
	  table which are matching.
	=>Its basic syntax can be given with:
	
	  SELECT cloumn_list FROM table_name
	  WHERE column_name IN(value1,value2,.....);

	-------------NOT IN OPERATOR----------------
	=>The NOT IN operator is a logical operator & check a value within a set of values ad retrieve the rows/records from the
	  table which are not matching.	
	=>Its basic syntax can be given with:
	
	  SELECT cloumn_list FROM table_name
	  WHERE column_name NOT IN(value1,value2,.....);
	  
	E.g:INSERT INTO EMPLOYEE VALUES(5,'UZMA',30000,3);
		INSERT INTO EMPLOYEE VALUES(6,'SEAN',40000,4);
		SELECT * FROM EMPLOYEE WHERE DEPT_ID IN(1,3);-->displays the data which dep_id values of 1,3  
		SELECT * FROM EMPLOYEE WHERE EMP_NAME IN('AHMAD','RAHUL');-->displays the data where emp_name is ahmad & rahul
		SELECT * FROM EMPLOYEE WHERE DEPT_ID NOT IN(1,3);-->displays the data where dept_id is not equal to values 1,3


	 	  		 ------------------------BETWEEN OPERATORS--------------------------------	
	 =>The BETWEEN operator selects values within a given range.The values can be numbers, texts or dates
	 =>Its basic syntax can be given with:
	 
	 SELECT column1_name,column2_name,columnN_name 
	 FROM table_name
	 WHERE column_name BETWEEN min_value AND max_value;
	 
	 E.g:SELECT * FROM EMPLOYEE WHERE EMP_SALARY BETWEEN 35000 AND 40000;-->displays all the date between emp_salary from 35000 to 40000


	 	  		 ------------------------LIKE OPERATORS--------------------------------		
	 =>The LIKE operator is used in a WHERE clause to search for a specified pattern in a column.
	 =>There are two wildcards often used in conjuction with the LIKE operator
	 	1.The percent sign(%) represents zero, one or multiple characters.
	 	2.The underscore(_) represents one,single character.
	 E.g:SELECT * FROM EMPLOYEE WHERE EMP_NAME LIKE 'A%';-->% indicate it can be any characters but first letter should start with A.
	 				-->displays all the date with emp_name starting with A
	 	 SELECT * FROM EMPLOYEE WHERE EMP_NAME LIKE '%H%';-->%H% anything can be before & after h
	 	            -->displays all the data with emp_name having H in them
	 	 SELECT * FROM EMPLOYEE WHERE EMP_NAME LIKE '_B%';-->_B% will ignore the first character & search for b in second 
	 	 			   character of emp_name & % indicates any character can be after b & it will dispalay all the data 
	 	 			   which satisfy this condition
		 SELECT * FROM EMPLOYEE WHERE EMP_NAME LIKE '__M%';-->__M% ignores the first two characters & search for m in third
		 			   character of emp_name & % indicates any character can be after m & it will display all the data which
					   satisfy this condition.


	 	  		 ------------------------UNION OPERATORS--------------------------------
	 =>The UNION operator is used to combine the results of two or more SELECT queries into a single result set
	 =>Combines two or more queries and removes the duplicates
	 =>The UNION operation creates a new table by placing all rows from two source tables into a single result table
	 =>Basic Rules
	 		1.The number & the order of the columns must be the same in all queries
	 		2.The columns must also have similar data types.
	 		
	 SYNTAX:
	 SELECT column_list FROM table_name
	 UNION SELECT column_list FROM table2_name;
	 
	 E.g:SELECT DEPT_ID FROM EMPLOYEE UNION SELECT DEPT_ID FROM EMPLOYEE; -->unites all the dep_id values of department 
	 				  & employee table removing all duplicate values
	 	 SELECT DEPT_ID FROM EMPLOYEE UNION ALL SELECT DEPT_ID FROM EMPLOYEE;-->unites all the dep_id values of department 
	 				  & employee table keeping all duplicate values
	 	 SELECT DEPT_ID FROM EMPLOYEE UNION ALL SELECT DEPT_ID FROM EMPLOYEE ORDER BY DEPT_ID;-->unites all the dep_id 
	 	 			  values of department & employee table keeping all duplicate value & in a sorted/ascending order

	 
	 	  		 ------------------------COLUMN ALIAS--------------------------------	 
	 =>Column Alias is use to give a temporary name for a column in a table.
	 =>Alias are often used to make column names more readable.
	 
	 E.g:SELECT EMP_ID "ID",EMP_NAME "EMPLOYEE NAME",EMP_SALARY "SALARY",DEPT_ID "DEPARTMENT ID" FROM EMPLOYEE;	
	 				  -->Temporarily change the name of the columns of employee table
	
	 
	 	 	  	------------------------TABLE ALIAS--------------------------------	 
	 =>The use of table aliases is to rename a table in a specific SQL statement.
	 =>The renaming is a temporary change & the actual table name does not change in the database.
	 
	 E.g:SELECT EMP_NAME,EMP_SALARY,DEPT_NAME FROM EMPLOYEE, DEPARTMENT WHERE EMPLOYEE.DEPT_ID=DEPARTMENT.DEP_ID; 
	 				-->displays columns of two tables by keeping dept_id as a verifying factor.
	 	 SELECT EMP_NAME,EMP_SALARY,DEPT_NAME FROM EMPLOYEE E, DEPARTMENT D WHERE E.DEPT_ID=D.DEP_ID; 
	 	 			-->displays columns of two tables by keeping dept_id as a verifying factor by using table alias
	 	 			   here E & D are the table alias & using this we reduced the space of the query.
	 	 			   

	 	 	  	------------------------INNER JOIN--------------------------------		 	 
	 =>Inner Join returns only those rows that have a match in both joined tables.
	 =>Its basic syntax can be given with:
	   SELECT Column_list FROM TABLE1 INNER JOIN TABLE2
	   ON Table1.ColName=Table2.ColName	
	   
	 E.g:Drop employee table ,remove reference, create employee table again insert 1-6 values of emp_id then proceed below
	 	 INSERT INTO EMPLOYEE VALUES(7,'ASEAN',47000,6);
		 INSERT INTO DEPARTMENT VALUES(5,'CAFTERIA');
	     SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON E.DEPT_ID=D.DEP_ID;
		 SELECT E1.EMP_ID,E1.EMP_NAME,E1.EMP_SALARY FROM EMPLOYEE E1, EMPLOYEE E2 WHERE E1.EMP_ID=E2.EMP_ID;
	
	 	 	  	------------------------LEFT JOIN--------------------------------	
	 =>The LEFT JOIN command returns all rows from the left table,& the matching rows from the right table.
	 =>The result is NULL from the right side,if there is no match.
	 
	 SYNTAX:
	 SELECT	column_list 
	 FROM table1
	 LEFT JOIN table2
	 ON table1.column_name=table2.column_name;
	 
	 E.g:SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E LEFT JOIN DEPARTMENT D ON E.DEPT_ID=D.DEP_ID; 
	
	
	 	 	  	------------------------RIGHT JOIN--------------------------------		
	 =>The RIGHT JOIN command returns all rows from the right table, & the matching rows from the left side.
	 =>The result is NULL from the left side,if there is no match	 	
	 
	 SYNTAX:
	 SELECT column_list
	 FROM table1
	 RIGHT JOIN table2
	 ON table1.column_name=table2.column_name;
	 
	 E.g:SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E RIGHT JOIN DEPARTMENT D ON E.DEPT_ID=D.DEP_ID; 
	
	
	 	 	  	------------------------FULL JOIN--------------------------------	
	 =>A FULL JOIN returns all the rows from the joined tables,whether they are matched or not.
	 =>You can say a full join combines the functions of a LEFT JOIN & a RIGHT JOIN.
	 =>FULL JOIN is a type of outer join that's why it is also referred as full outer join. 	 	
	 
	 SYNTAX:
	 SELECT column_list
	 FROM table1
	 FULL JOIN table2
	 ON table1.column_name=table2.column_name;	
	 
	 E.g:SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E FULL JOIN DEPARTMENT D ON E.DEPT_ID=D.DEP_ID;
	 
	 
	 	 	  	------------------------CROSS JOIN--------------------------------	 '
	 =>The CROSS JOIN specifies that all rows from first table join with all of the rows of second table.
	 
	 SYNTAX:
	 SELECT column_list
	 FROM table1
	 CROSS JOIN table2
	 
	 E.g:SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E CROSS JOIN DEPARTMENT D;
	 
	 
	 	 	  	------------------------NATURAL JOIN--------------------------------	
	 =>Compare all common columns in both table & return all match record
	 	 
	 SYNTAX:
	 SELECT column_list
	 FROM table1
	 NATURAL JOIN table2;
	 
	 E.g:SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E NATURAL JOIN DEPARTMENT D;
	 
	 
	 	 	  	------------------------SELF JOIN--------------------------------	
	 =>A self join is a join in which a table is joined with itself
	 
	 SYNTAX:
	 SELECT column_list
	 FROM table1,table2
	 WHERE condition;
	 
	 E.g:SELECT E1.EMP_ID,E1.EMP_NAME,E1.EMP_SALARY FROM EMPLOYEE E1, EMPLOYEE E2 WHERE E1.EMP_ID=E2.EMP_ID;
	 
	 
	 	 	 	  	------------------------TABLESPACE AND DATAFILES--------------------------------
	 The Oracle Database stores logically in tablespace & physically in data file
	 
	 					TABLESPACE		 						|						DATA FILES
	 Can belong to only one database							| Can belong to only one tablespace & one Database
	 Consist of one or more data files							| All data store under the data file physically
	 Are further divided into logical units of storage			|
	 
	 Query to check the tablespaces in the database:
	 SELECT TABLESPACE_NAME FROM USER_TABLESPACES;
	 
	 Query to check the tablespaces, data files name , size:
	 SELECT TABLESPACE_NAME,FILE_NAME, BYTES FROM DBA_DATA_FILES;
	 
	 Query to create a new tablespace:
	 CREATE TABLESPACE TableSpaceName DATAFILE 'Path/DatafileName.DBF' SIZE;
	 E.g:CREATE TABLESPACE TEST DATAFILE 'C:\Oracledatabase\Appdb\oradata\ORCL\TEST1.DBF' SIZE 50M;
	  
	 Query to delete a tablespace: 
	 DROP TABLESPACE TEST;
	 
	 
	 	 	 	  	------------------------TABLESPACE,USERS AND ROLE--------------------------------
	 Create TableSpace:
	   CREATE TABLESPACE TableSpaceName DATAFILE 'Path/DatafileName.DBF' SIZE;
	   
	   E.g:CREATE TABLESPACE TEST DATAFILE 'C:\Oracledatabase\Appdb\oradata\ORCL\TEST1.DBF' SIZE 50M;
	   
	 Create User:
	   CREATE USER C##UserName IDENTIFIED BY Password  -->C## is for this laptop & may not required for other laptops so try to write without it & check
	   DEFAULT TABLESPACE TablespaceName
	   TEMPORARY TABLESPACE Temp
	   QUOTA UNLIMITED ON TablespaceName;
	   
	   E.g:CREATE USER C##SHIVA IDENTIFIED BY SHIVA
	   	   DEFAULT TABLESPACE TEST
	       TEMPORARY TABLESPACE TEMP
	       QUOTA UNLIMITED ON TEST;
	   
	 Create Role:
	   CREATE C##ROLE RoleName; -->C## is for this laptop & may not required for other laptop's so try to write without it & check
	   
	   E.g:CREATE ROLE C##DEMO;
	   	 
	 Permission to role
	   GRANT CREATE TABLE,CREATE SESSION TO C##RoleName;-->C## is for this laptop & may not required for other laptop's so try to write without it & check
	   
	   E.g:GRANT CREATE TABLE,CREATE SESSION TO C##DEMO;
	   
	 Assign Role to User
	   GRANT c##RoleName To C##UserName;-->C## is for this laptop & may not required for other laptop's so try to write without it & check
	   
	   E.g:GRANT C##DEMO TO C##SHIVA;
	   
	   
	   	 	 	 	  	------------------------ALTER TABLESPACE--------------------------------
	 ALTER TABLESPACE statement changes the description of a table space at the current server. -->making more dataFiles for a given TableSpace
	 
	 E.g:ALTER TABLESPACE TEST ADD DATAFILE 'C:\Oracledatabase\Appdb\oradata\ORCL\TEST2.DBF' SIZE 40M;-->Creates second dataFile for TableSpace TEST
	 	 SELECT TABLESPACE_NAME,FILE_NAME, BYTES FROM DBA_DATA_FILES;-->To check whether datafile is created or not.
	 
	 To Delete A DATAFILE-
	 
	 E.g:ALTER TABLESPACE TEST DROP DATAFILE 'C:\Oracledatabase\Appdb\oradata\ORCL\TEST2.DBF';-->Dropping dataFile with name TEST2 for TableSpace TEST
	 
	 To Delete A TABLESPACE & itS DATAFILE:
	 DROP TABLESPACE tableSpace_Name INCLUDING CONTENTS AND DATAFILES;
	 
	 E.g:DROP TABLESPACE TEST INCLUDING CONTENTS AND DATAFILES;
	 
	 
		   	 	 	 	  	------------------------ALTER TABLE STATEMENT--------------------------------
	 =>The ALTER TABLE statement is used to add,delete,or modify columns in an existing table.
	 =>The ALTER TABLE statement is also used to add & drop various constraints on an existing table.
	 
	 E.g:-SELECT * FROM EMPLOYEE;
		  DESC EMPLOYEE;
 		  ALTER TABLE EMPLOYEE ADD EMP_ADDRESS VARCHAR2(50);-->To add new column in the table
 		  ALTER TABLE EMPLOYEE RENAME COLUMN EMP_ADDRESS TO ADDRESS;-->To change the column name of the table
 		  ALTER TABLE EMPLOYEE MODIFY ADDRESS NUMBER;-->To change the datatype of a column in a table
		  ALTER TABLE EMPLOYEE MODIFY ADDRESS NUMBER UNIQUE;-->To add a constraint to a column in a table
		  ALTER TABLE EMPLOYEE DROP COLUMN ADDRESS;-->To drop a column from the table
		  
		  
		   	 	 	 	  	------------------------REFERENTIAL INTEGRITY--------------------------------		 
 	 =>REFERENTIAL INTEGRITY refers to the accuracy & consistency of data within a relationship.
 	 =>In relationships, data is linked between two or more tables.
 	 =>This is achieved by having the foreign key(in the associated table) reference a primary key value(in the primary -or
 	   parent table).
 	   
 	 E.g:CREATE TABLE DEPARTMENTT(DEP_ID NUMBER PRIMARY KEY,DEPT_NAME VARCHAR2(50));
		 INSERT INTO DEPARTMENTT VALUES(1,'IT');
		 INSERT INTO DEPARTMENTT VALUES(2,'HR');
		 INSERT INTO DEPARTMENTT VALUES(3,'MEDICAL');
		 INSERT INTO DEPARTMENTT VALUES(4,'QUALITY');
		 SELECT * FROM DEPARTMENTT;	
		 CREATE TABLE EMPLOYEEE(EMP_ID NUMBER PRIMARY KEY,EMP_NAME VARCHAR2(30),EMP_SALARY DECIMAL(10,2),
		 DEPT_ID INTEGER REFERENCES DEPARTMENTT);-->This will not allow any row with dept_id other than those of dep_id in department table but will not
		 											delete the data of employee table if corresponding department data is deleted.Ref. 2.30.00 Youtube
		 DROP TABLE EMPLOYEEE;-->drop the table & run the below query.
		 CREATE TABLE EMPLOYEEE(EMP_ID NUMBER PRIMARY KEY,EMP_NAME VARCHAR2(30),EMP_SALARY DECIMAL(10,2),
		 DEPT_ID INTEGER REFERENCES DEPARTMENTT ON DELETE CASCADE);-->If any record of Department table is deleted then the corresponding dep_id of record 
		 															  from employee table is deleted automatically. ***IMP*****
		 INSERT INTO EMPLOYEEE VALUES(1,'AHMAD',40000,1);
		 INSERT INTO EMPLOYEEE VALUES(2,'MARK',35000,2);
		 INSERT INTO EMPLOYEEE VALUES(3,'ABID',50000,2);
		 INSERT INTO EMPLOYEEE VALUES(4,'RAHUL',40000,1);
		 INSERT INTO EMPLOYEEE VALUES(5,'UZMA',30000,3);
		 INSERT INTO EMPLOYEEE VALUES(6,'SEAN',40000,4);
		 SELECT * FROM EMPLOYEEE;
		 -->Now lets see if we delete any data from parent table then the corresponding records of child table gets deleted or not?
		 DELETE FROM DEPARTMENTT WHERE DEPT_ID=4;-->This will delete 'QUALITY' dep_name from DEPARTMENTT table & also SEAN details
		 										    from EMPLOYEEE Table directly.
		 SELECT * FROM EMPLOYEEE;
		  
		  
		   	 	 	 	  	------------------------GROUP BY CLAUSE--------------------------------	
	 =>The GROUP BY clause is used to group rows that have the same value.
	 =>The GROUP By clause is used in the SELECT statement.
	 =>Optionally it is used in conjunction with aggregate functions to provide summary report from the databases.
	 
	 SYNTAX:
	 SELECT column_name(s)
	 FROM table_name
	 GROUP BY column_name(s);]
	 
	 E.g:INSERT INTO EMPLOYEEE VALUES(7,'ABID',50000,2);
		 INSERT INTO EMPLOYEEE VALUES(8,'RAHUL',40000,1);
		 INSERT INTO EMPLOYEEE VALUES(9,'MARK',35000,2);
		 INSERT INTO EMPLOYEEE VALUES(10,'AHMAD',40000,1);
		 SELECT EMP_NAME FROM EMPLOYEEE GROUP BY EMP_NAME; ==>Groups the values by same name /values removing duplicates.
		 DELETE FROM EMPLOYEEE WHERE EMP_ID=10;-->using this delete data from EMPLOYEEE table where emp_id=7,8,9,10.
		  
		  
		   	 	 	 	  	------------------------AGGREGATE FUNCTIONS--------------------------------	
	=>Oracle Aggregate Functions calculate on a group of rows & return a single value for each group.
	=>We commonly use the Aggregate Functions together with the GROUP BY clause. (but its not mandatory to use all time)
	=>The GROUP BY clause divides the rows into groups & an Aggregate functions calculates & returns a single result for
	  each group.
	 	
	 			FUNCTION		|				ACTION
	 		COUNT				| Returns the number of rows in the column
	 		MIN					| Returns the minimum of the range of values
	 		MAX					| Returns the maximum of the range of values
	 		AVG					| Returns the average of the range of values
	 		STDDEV				| Returns the standard deviation of the range of values
	 		VARIANCE			| Returns the variance of the range of values
	 		SUM					| Returns the sum of the range of values
	 		
	E.g:SELECT COUNT(*) FROM EMPLOYEEE; ==>counts the no.of rows/data in the EMPLOYEEE table
		SELECT COUNT(EMP_SALARY) FROM EMPLOYEEE; ==>counts the no.of rows/data in the emp_salary column from the EMPLOYEEE table
		SELECT MIN(EMP_SALARY) FROM EMPLOYEEE; ==>gives the min value/salary in the emp_salary column from the EMPLOYEEE table
		SELECT MAX(EMP_SALARY) FROM EMPLOYEEE; ==>gives the max value/salary in the emp_salary column from the EMPLOYEEE table
		SELECT AVG(EMP_SALARY) FROM EMPLOYEEE; ==>gives the avg value/salary in the emp_salary column from the EMPLOYEEE table
		SELECT STDDEV(EMP_SALARY) FROM EMPLOYEEE; =>gives the standard deviation value/salary in the emp_salary column from the EMPLOYEEE table
		SELECT VARIANCE(EMP_SALARY) FROM EMPLOYEEE; ==>gives the variance value/salary in the emp_salary column from the EMPLOYEEE table
		SELECT SUM(EMP_SALARY) FROM EMPLOYEEE; ==>gives the sum of the values/salaries in the emp_salary column from the EMPLOYEEE table
		SELECT EMP_SALARY,COUNT(*) FROM EMPLOYEEE GROUP BY EMP_SALARY; =>gives the count of each value /salary of emp_salary column from the 
									EMPLOYEEE table & displays the emp_salary column & its count side by side.
		SELECT EMP_SALARY,COUNT(EMP_SALARY) FROM EMPLOYEEE GROUP BY EMP_SALARY; =>gives the emp_salary value count for each same value /salary of
									 emp_salary column from the EMPLOYEEE table & displays the emp_salary column & the count of emp_salary values 
									 side by side.
		SELECT EMP_SALARY,COUNT(EMP_ID) FROM EMPLOYEEE GROUP BY EMP_SALARY; =>gives the emp_id value count for each same value /salary of emp_salary
									 column from the EMPLOYEEE table & displays the emp_salary column & the count of emp_id values side by side.
		SELECT EMP_SALARY,SUM(EMP_SALARY) FROM EMPLOYEEE GROUP BY EMP_SALARY;  =>gives the sum of emp_salary values for each same value /salary of
									 emp_salary column from the EMPLOYEEE table & displays the emp_salary column & the sum of its corresponding same
									 emp_salary values side by side.	
		  
		  
		   	 	 	 	  	------------------------HAVING CLAUSE--------------------------------		
	=>HAVING clause is used with GROUP BY clause to restrict the groups of returned rows where condition is TRUE.								 
	  
	 E.g:CREATE TABLE SUPPLIER(SUPPLIER_ID NUMBER PRIMARY KEY,SUPPLIER_NAME VARCHAR2(50));
		 INSERT INTO SUPPLIER VALUES(1,'DELL');
		 INSERT INTO SUPPLIER VALUES(2,'LENOVO');
		 INSERT INTO SUPPLIER VALUES(3,'HP');
		 INSERT INTO SUPPLIER VALUES(4,'AMAZON');
		 SELECT * FROM SUPPLIER;
		 CREATE TABLE PRODUCTSS(PRO_ID NUMBER PRIMARY KEY,PRO_NAME VARCHAR2(30),PRO_PRICE DECIMAL(10,2),
		 SUPPLIER_ID INTEGER REFERENCES SUPPLIER ON DELETE CASCADE);
		 INSERT INTO PRODUCTSS VALUES(1,'MOUSE',100,2);
		 INSERT INTO PRODUCTSS VALUES(2,'KEYBOARD',150,1);
		 INSERT INTO PRODUCTSS VALUES(3,'HHD',1000,4);
		 INSERT INTO PRODUCTSS VALUES(4,'MOUSE',200,1);
		 INSERT INTO PRODUCTSS VALUES(5,'KEYBOARD',100,2);
		 INSERT INTO PRODUCTSS VALUES(6,'MOUSE',150,3);
		 SELECT * FROM PRODUCTSS; 
	     SELECT PRO_NAME,COUNT(*) FROM PRODUCTSS GROUP BY PRO_NAME; -->displays unique name in the Pro_name & its repetation/counts from PRODUCTSS table
	     SELECT PRO_NAME,COUNT(*) FROM PRODUCTSS GROUP BY PRO_NAME HAVING COUNT(*)>2;-->displays unique name in the Pro_name & its repetation/counts from
	      								PRODUCTSS table whose count/repetations is more than 2.
	     SELECT PRO_NAME,SUM(PRO_PRICE) FROM PRODUCTSS GROUP BY PRO_NAME;-->displays unique name in the pro_name & sum of the total number of items/repetation
	                                    of each unique pro_name from the PRODUCTSS table
	     SELECT PRO_NAME,SUM(PRO_PRICE) FROM PRODUCTSS GROUP BY PRO_NAME HAVING SUM(PRO_PRICE)>250; -->displays unique name in the pro_name & sum of the total
	                                    number of items/repetation of each unique pro_name from the PRODUCTSS table whose sum value is greater than 250.
		  
		  
		   	 	 	 	  	------------------------CHARACTER FUNCTIONS--------------------------------	
	=>A Character Functions is a function that takes one or more character values as parameters & returns either a character value or a number value.
	
	     										CHARACTER FUNCTIONS
	     												|
	       ----------------------------------------------------------------------------------------------
	       |																							|
	 CASE CONVERSION FUNCTIONS													CHARACTER MANIPULATION FUNCTIONS  											
	    *LOWER																				*CONCAT
	    *UPPER																				*SUBSTR
	    *INITCAP																			*LENGTH
	    																					*INSTR
	    																					*LPAD|RPAD
	    																					*TRIM
	    																					*REPLACE
	 
	E.g:SELECT * FROM EMPLOYEEE;
		SELECT UPPER(EMP_NAME) FROM EMPLOYEEE; -->displays all the values in lower case 
		SELECT LOWER(EMP_NAME) FROM EMPLOYEEE; -->displays all the values in upper case
		SELECT INITCAP(EMP_NAME) FROM EMPLOYEEE; -->displays initial value in upper case & remaining values in lower case
		SELECT * FROM EMPLOYEEE WHERE EMP_NAME='Ahmad'; -->if we run the query we don't get any output as AHMAD is in upper case in the emp_name column in
														   the EMPLOYEEE table since SQL is case sensitive.
		SELECT * FROM EMPLOYEEE WHERE INITCAP(EMP_NAME)='Ahmad'; -->this will display as it converts all the emp_name value to INITCAP & then checks the
																	condition in EMPLOYEE table.
		SELECT CONCAT(EMP_NAME,EMP_SALARY) FROM EMPLOYEEE; -->joins two columns & displays the value
		SELECT SUBSTR('I AM SHIVA',3,2) FROM DUAL; --> here 3 is the character at which it should start displaying the value & 2 is the length till which
													  it has to display. DUAL is the dummy table.
		SELECT LENGTH('I AM SHIVA') FROM DUAL;-->gives the total length of characters.DUAL is the dummy table.
		SELECT EMP_NAME FROM EMPLOYEEE WHERE LENGTH (EMP_NAME)=5;-->displays emp_name values whose length is equal to 5 from EMPLOYEEE Table
		SELECT INSTR('I AM SHIVA','SHIVA') FROM DUAL; -->gives the string location i.e., character at which the given string starts.DUAL is the dummy table.
		SELECT LPAD('SHIVA',2) FROM DUAL; -->displays two characters from the left side.DUAL is the dummy table.
		SELECT ' SHIVA ' FROM DUAL; -->displays the spacings too in the output.DUAL is the dummy table.
		SELECT TRIM(' SHIVA ') FROM DUAL; -->Trims /displays the data without spacings.DUAL is the dummy table.
		SELECT REPLACE ('123SHIVA123','123') FROM DUAL; -->removes the mentioned characters & displays the output.DUAL is the dummy table.
		  
		  
		   	 	 	 	  	------------------------NUMERIC FUNCTIONS--------------------------------	    
	=>The Oracle Numeric functions takes a numeric input as an expression and return numeric values 
	FUNCTIONS:
	1.CEIL(n)	 : Returns nearest whole number greater than or equal to n.
		E.g: SELECT CEIL(12.3) FROM DUAL; -->output:-13 as it is the nearest greatest number of 12.3
	2.FLOOR(n)	 : Returns nearest whole number less than or equal to n.
		E.g: SELECT FLOOR(127.6) FROM DUAL; -->output:-127 as it is the nearest least value or equal value of 127.6
	3.ROUND(n,m) : Rounds n to m places to the right of the decimal point.
		E.g: SELECT  ROUND(12.55654546,3) FROM DUAL; -->output:- 12.557, it rounds the decimal value to 3 digits.
	4.POWER(m,n) : Multiplies m to the power n.
		E.g: SELECT POWER(5,3) FROM DUAL; -->output:-125, it gives 3 to the power of 5 value/
	5.MOD(m,n)	 : Returns the remainder of the division of m by n.if n=0, then 0 is returned.If n>m,then m is returned.
		E.g: SELECT MOD(9,5) FROM DUAL; -->output:-4, it gives the remainder between 9/5.
	6.SQRT(n)	 : Returns the square root of n.
		E.g: SELECT SQRT(9) FROM DUAL; -->output:3, it gives the square root of 9
	7.ABS(n)	 : Returns the absolute value of n.
		E.g: SELECT ABS(-29) FROM DUAL; -->output:-20, it gives positive value. ABS is absolute value that is positive value
	8.TRUNC      : Returns a value with the required number of decimal places while a negative n2 rounds to the left of the decimal.
		E.g: SELECT TRUNC(29.16,1) FROM DUAL; -->output:-29.1, it gives the value keeping the no.of digits in decimal as mentioned 
												here we have 1 so it gives 29.1, if we have 2 then it gives 29.16.
		  
		  
		   	 	 	 	  	------------------------CONVERSION FUNCTIONS--------------------------------	
	=>Converts a value(of any type) into a specified dataType.
		1.To_Date :Converts a STRING into a date format.
		2.To_Char :Converts either a number or a date value to a string value.
		3.NVL	  :Allows you to replace a NULL value with another value.
		4.Decode  :Use to expand small abbreviation.
    E.g:-CREATE TABLE EMPLOYEEDATA(EMP_ID NUMBER PRIMARY KEY, EMP_NAME VARCHAR2(20),EMP_SALARY DECIMAL(10,2),JOIN_DATE DATE, COUNTRY VARCHAR2(50));
		 INSERT INTO EMPLOYEEDATA VALUES(1,'AHMAD',50000,'1-JAN-2020','PAK'); -->this is the original order of writing the date.
		 INSERT INTO EMPLOYEEDATA VALUES(2,'MARK',50000,TO_DATE('2020-JAN-1','YYYY-MM-DD'),'USA');-->if the order of date is not known then by using
		 																							 TO_DATE function we can insert the date into the EMPLOYEEDATA Table.
		 INSERT INTO EMPLOYEEDATA VALUES(3,'UZMA',50000,TO_DATE('2020-MARCH-1','YYYY-MM-DD'),'UAE');
		 SELECT * FROM EMPLOYEEDATA; 
		 SELECT EMP_NAME,TO_CHAR(JOIN_DATE,'MM') FROM EMPLOYEEDATA;-->display emp_name along with the Month of joining with the help of TO_CHAR function
		 SELECT EMP_NAME,NVL(EMP_SALARY,5000) FROM EMPLOYEEDATA; -->displays emp_name & emp_salary & if the emp_salary is null then in that place it will display 5000.
		 															NVL->null value
		 SELECT EMP_NAME,DECODE(COUNTRY,'PAK','PAKISTAN','USA','UNITED STATES OF AMERICA' ) FROM EMPLOYEEDATA;-->decode is used for abbrevations, here it displays 
		 													emp_name & country with the abrrevations. since UAE abbrevation is not provided it displays null over there.
		  
		  
		   	 	 	 	  	------------------------SQL commands types--------------------------------
	=>DATA DEFINITION LANGUAGE(DDL):-use to define the databases,like
			1.CREATE
			2.DROP
			3.TRUNCATE
			4.ALTER
			5.BACKUPDATABASE
	=>DATA MANIPULATION LANGUAGE(DML):-use to manipulate the data present in the database, like
			1.USE
			2.INSERT
			3.UPDATE
			4.DELETE
			5.SELECT
	  Apart from these commands, there are also other manipulative operators/functions such as:
	  		1.Operators
	  		2.Aggregate Functions
	  		3.NULL Functions
	  		4.Aliases & Case Statement
	=>DATA CONTROL LANGUAGE(DCL):-Deals with the user permissions & controls of the database system,Like
			1.PrivilegeName		:-Is the privilege/right/access granted to the user.
			2.ObjectName   		:-Name of a database object like TABLE/VIEW/STOREDPROC.
			3.UserName    	    :-Name of the user who is given the access/rights/privileges.
			4.PUBLIC	    	:-To grant access rights to all users.
			5.RoleName	   		:-The name of a set of privileges grouped together.
			6.WITH GRANT OPTION :-To give the user access to grant other users with rights.
 	=>TRANSACTION CONTROL LANGUAGE(TCL):-Deal with the transaction of the database,like
 			1.COMMIT
 			2.ROLLBACK
 			3.SAVEPOINT
		  
		  
		   	 	 	 	  	------------------------NOT NULL CONSTRAINT--------------------------------	
	=>If a column is declared as not null, then we can't have null values in that column
	E.g:CREATE TABLE STUDENTS(STD_ID NUMBER,STD_NAME VARCHAR2(20) NOT NULL); -->std_name cannot have null values in it
		  
		  
		   	 	 	 	  	------------------------Unique CONSTRAINT--------------------------------
 	=>If a column is declared as Unique, then it cannot have same /similar values in that column.
 	E.g:CREATE TABLE STUDENTS(STD_ID NUMBER,STD_NAME VARCHAR2(20) UNIQUE); -->std_name cannot have same /similar values 
		  
		  
		   	 	 	 	  	------------------------Primary Key & Foreign Key CONSTRAINT--------------------------------
	=>To identify a row/record uniquely in a table ,primary key is used. we can declare only one Primary Key in a table
	  and primary key cannot be null.
	=>Foreign key refers primary key of other table.In a table we can declare one or more foreign keys.
	 
	 E.g:CREATE TABLE DEPARTMENTS (DEP_ID NUMBER PRIMARY KEY,DEPT_NAME VARCHAR2(50));
		 CREATE TABLE STUDENTS(STD_ID NUMBER PRIMARY KEY,STD_NAME VARCHAR2(30),DEP_ID NUMBER REFERENCES DEPARTMENTS);
		  
		  
		   	 	 	 	  	------------------------SEQUENCE in Oracle Database--------------------------------
   =>SEQUENCE generates set of unique integers with a proper order as per the configuration we do.
   =>Usually we use sequence with the primary key
   =>Syntax to create a sequence is,
   				CREATE SEQUENCE schema_name.sequence_name
   				[INCREMENT BY interval]
   				[START WITH first_number]
   				[MAXVALUE max_value | NOMAXVALUE]
   				[MINVALUE min_value | NOMINVALUE]
   				[CYCLE | NOCYCLE]							-->cycle means if the sequence reaches it's maxvalue then the sequence starts with the first number again
   				[CACHE cache_size | NOCACHE]
   E.g:CREATE TABLE STUDENTS(STD_ID NUMBER PRIMARY KEY,STD_NAME VARCHAR2(20));
	   CREATE SEQUENCE STD_SEQ INCREMENT BY 1 START WITH 100 MAXVALUE 999 MINVALUE 1 NOCYCLE NOCACHE NOORDER; -->creating the sequence
	   INSERT INTO STUDENTS VALUES (STD_SEQ.NEXTVAL,'AHMAD');
	   SELECT STD_SEQ.CURRVAL FROM STUDENTS; -->to check the current value of the sequence
	   SELECT * FROM STUDENTS;
	   INSERT INTO STUDENTS VALUES (STD_SEQ.NEXTVAL,'MARK');
	   INSERT INTO STUDENTS VALUES (STD_SEQ.NEXTVAL,'UZMA');
		  
		  
		   	 	 	 	  	------------------------Pseudocolumns--------------------------------
   =>A pseudocolumn behaves like a table column, but is not actually stored in the table.
   =>You can select from pseudocolumns, but we cannot insert ,update or delete their values.
   =>Used to get the system-related data.
   =>Help us to get the metadata of our database.
   =>Allow us to get the details of access rights on our database.
   =>Help us to keep a check on our database.
   
   		1.SYSDATE		:Return the current System Date.
   		2.SYSTIMESTAMP	:Return the current System Date with time, millisecond and AM,PM etc.
   		3.UID			:Return Current User ID.
   		4.USER			:Return Current User Details.
   		5.ROWID			:Returns the rowid(binary address) of a row in a database table.
   		6.ROWNUM		:Maintains the number of each record inserted by users in the table.
   		7.CURRVAL		:Current Value
   		8.NEXTVAL		:Next Value
    E.g:SELECT SYSDATE FROM DUAL;
		SELECT SYSTIMESTAMP FROM DUAL;
		SELECT  UID FROM DUAL;
		SELECT USER FROM DUAL;
		SELECT ROWID,EMP_NAME FROM EMPLOYEE;
		SELECT ROWNUM,EMP_NAME FROM EMPLOYEE;
		SELECT ROWNUM,EMP_NAME FROM EMPLOYEE WHERE ROWNUM<3;
		  
		  
		   	 	 	 	  	------------------------Subquery,Inner Query or Nested Query--------------------------------
   =>A subquery is a query within a query.
   =>Use for to select records where we do not know the condition values.
   =>Mostly we are using after WHERE clause but we can use with FROM & SELECT clause
   =>Oracle allows upto 255 levels of subqueries in the WHERE clause.
   
   E.g:SELECT * FROM EMPLOYEE WHERE EMP_SALARY=(SELECT MAX(EMP_SALARY) FROM EMPLOYEE);
	   SELECT * FROM EMPLOYEE WHERE EMP_SALARY IN( SELECT EMP_SALARY FROM EMPLOYEE WHERE EMP_SALARY>30000);
       SELECT EMP_NAME FROM EMPLOYEE WHERE EMP_SALARY IN( SELECT EMP_SALARY FROM EMPLOYEE WHERE EMP_SALARY>30000);
		  
		  
		   	 	 	 	  	------------------------Data Dictionary--------------------------------
   =>The Oracle Data Dictionary is one of the most important components of the oracle DBMS.
   =>It contains all information about the structures & objects of the database such as 
   		•Tab
   		•All Tables
   		•All Sequences
   		•All views
   		•All Constraints etc.
   =>The data stored in the data dictionary are also often called metadata.
  	
  	E.g:SELECT * FROM TAB;
		SELECT * FROM ALL_TABLES; 
		SELECT * FROM ALL_SEQUENCES;
		SELECT * FROM ALL_VIEWS;
		SELECT * FROM ALL_CONSTRAINTS;
		  
		  
		   	 	 	 	  	------------------------Execute commands written in Notepad file--------------------------------
   E.g:SELECT * FROM EMPLOYEEE;
	   START C:\Users\a861892\Downloads\EMPLOYEEE.TXT; --> write SELECT * FROM EMPLOYEEE; in notepad & save the file & run in sqldeveloper
       START C:\Users\a861892\Downloads\EMPLOYEEE.SQL; -->you can save the file in either .txt format or .sql format	
		  
		  
		   	 	 	 	  	------------------------REPORTS--------------------------------
	=>Generating a report & saving it in physical file.
	E.g:
		SET PAGESIZE 10 							-->setting pagesize
		SET LINESIZE 150           					-->setting each line size in the report
		SET PAUSE ON								-->to set pop up message
		SET PAUSE 'PRESS ANY KEY..' 
		TTITLE LEFT 'EMPLOYEE REPORT' 				-->TTILE-->Top title
		BTITLE LEFT 'End Report' 					-->BTITLE--> Bottom title
		COLUMN EMP_NAME FORMAT A5 TRUNC 
		SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E,DEPARTMENT D WHERE E.DEPT_ID=D.DEP_ID; 
		CLEAR COLUMN
		TTITLE OFF
		SET PAUSE OFF								-->Offing
		SET LINESIZE 80 							-->offing & 80 is default line size  
		SET PAGESIZE 24 							-->closing & 24 is default size
		
		
		Now copy the code & click run script(F5) instead of Run statement(ctrl+enter) to get the report.Now write the
		following code above & below in order to print the report & save it in document format.
		 
		SPOOL C:\Users\a861892\Downloads\EMPREPORT.TXT;
		SET PAGESIZE  10
		SET LINESIZE 150 
		SET PAUSE ON 
		SET PAUSE 'PRESS ANY KEY..' 
		TTITLE LEFT 'EMPLOYEE REPORT'  
		BTITLE LEFT 'End Report'  
		COLUMN EMP_NAME FORMAT A5 TRUNC 
		SELECT E.EMP_ID,E.EMP_NAME,E.EMP_SALARY,D.DEPT_NAME FROM EMPLOYEE E,DEPARTMENT D WHERE E.DEPT_ID=D.DEP_ID; 
		CLEAR COLUMN
		TTITLE OFF 
		SET PAUSE OFF 
		SET LINESIZE 80  
		SET PAGESIZE 24 
		SPOOL OFF
		
		copy the code & click run script(F5) instead of Run statement(ctrl+enter) to get the report in physical document format.
		  
		  
		   	 	 	 	  	------------------------VIEWS IN ORACLE--------------------------------
	=>VIEWS are the logical table version of a physical table.
	
	E.g:SELECT * FROM EMPLOYEE;
		CREATE VIEW EMPLOYEE_VIEW AS SELECT EMP_NAME ,EMP_SALARY FROM EMPLOYEE;  -->creating a view
		SELECT * FROM EMPLOYEE_VIEW;
		CREATE OR REPLACE VIEW EMPLOYEE_VIEW AS SELECT * FROM EMPLOYEE-->editing or modifying a view
		SELECT * FROM EMPLOYEE_VIEW;
		INSERT INTO EMPLOYEE_VIEW VALUES (8,'NADEEM',40000,4);-->Inserting values into the view there by inserting into main table aswell
		SELECT * FROM EMPLOYEE_VIEW;
		SELECT * FROM EMPLOYEE;
		DELETE FROM EMPLOYEE WHERE EMP_ID =8;
		CREATE OR REPLACE VIEW EMPLOYEE_VIEW AS SELECT * FROM EMPLOYEE WHERE EMP_SALARY=40000 WITH CHECK OPTION;
		SELECT * FROM EMPLOYEE_VIEW;
		DROP VIEW EMPLOYEE_VIEW; -->deleting a view		  
		  
		  
		   	 	 	 	  	------------------------Input Variables--------------------------------
	=>By using Input Variable, we take any variable from the user &keep it  in a local variable & we use that variable in the
	  Select statement to get that variable related data or to perform actions by using that variable.Input variables are 
	  temporary variables.
	 E.g:SELECT * FROM EMPLOYEE;
	 	 ACCEPT ENAME CHAR PROMPT 'PLEASE ENTER EMPLOYEE NAME'; --->ACCEPT VARIABLE_NAME DATATTYPE PROMPT 'POP UP MSG';
	 	 															PROMPT is used to display a pop up msg. 
		 SELECT * FROM EMPLOYEE WHERE EMP_NAME='&ENAME';
		  
		  
		   	 	 	 	  	------------------------Define Variables--------------------------------
	=>We define temporary variables with the help of DEFINE VARAIBLES & by using this temporary variable we return a
	  value or record.
	 E.g:SELECT * FROM EMPLOYEE;
		 DEFINE EID=7;
		 SELECT * FROM EMPLOYEE WHERE EMP_ID=&EID;
		 DEFINE;-->This will display the list of variables which are defined in the database.
		 UNDEFINE EID;-->This will undefine EID from the database.
		  
		  
		   	 	 	 	  	------------------------PL/SQL--------------------------------
	=>PL/SQL(Procedural Language Extension of SQL)
	=>SQL is the Standard Database Language & PL/SQL is strongly integrated with SQL.
	=>PL/SQL supports both static & Dynamic SQL.
	=>PL/SQL allows sending an entire block of statements to the database at one time.
	=>PL/SQL saves time on design & debugging by strong feature as exception handling,Encapsulation,Data Hiding and
	  Object -oriented data types.
	=>PL/SQL provides high security level.
	=>PL/SQL provides access to predefined SQL packages.
	=>It offers a variety of programming structures.
	=>It supports structured programming through functions & procedures.
	=>It supports Object -Oriented programming.
	=>It supports the development of web Applications & server pages.
	
				BLOCK STRUCTURE OF PL/SQL:-
							
							DECALRE 
							
									<Declarations section>
									
		 					BEGIN
		 					
		 							<Executable command(s)>
		 					
		 					EXCEPTION
		 					
		 							<Exception Handling>
		 					
		 					END;
	 E.g:
	 	1.SET SERVEROUTPUT ON;--->on the serveroutput to run a PL/SQL BLOCK
		  DECLARE
		  MESSAGE VARCHAR2(50);
		  BEGIN
		  MESSAGE:='WELCOME TO ATOS SYNTEL-BANGALORE';
		  DBMS_OUTPUT.PUT_LINE(MESSAGE);
		  END;
		  SET SERVEROUTPUT OFF;--->After running PL/SQL block turn off the serveroutput
		  
	    2.Using SQL in PL/SQL.
	      Taking the input from user & returning the record based upon the user input.
	      
	      SELECT * FROM EMPLOYEE; 
	      SET SERVEROUTPUT ON; --->on the serveroutput to run a PL/SQL BLOCK
	      DECLARE
	      NAME EMPLOYEE.EMP_NAME%TYPE; -->%TYPE will make name datatype as the same datatype of EMP_NAME
	      SALARY EMPLOYEE.EMP_SALARY%TYPE; -->%TYPE will make salary datatype as the same datatype of EMP_salary
	      MSG NUMBER;
	      BEGIN
	      SELECT EMP_NAME,EMP_SALARY INTO NAME,SALARY FROM EMPLOYEE WHERE EMP_ID=&MSG; -->command line
	      DBMS_OUTPUT.PUT_LINE(NAME);  -->displating command
	      DBMS_OUTPUT.PUT_LINE(SALARY);-->displaying command
	      END;
	      SET SERVEROUTPUT OFF;--->After running PL/SQL block turn off the serveroutput
		  
		  
		   	 	 	 	  	------------------------IF-ELSE STATEMENT--------------------------------
	=>IF statement:
	  E.g:SET SERVEROUTPUT ON;
		  DECLARE 
		  E_SALES NUMBER:=50000;
		  E_COMMISION NUMBER:=0;
		  BEGIN
		  IF E_SALES>40000 THEN E_COMMISION:=(E_SALES*10)/100;
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 10% EQUAL TO:'||E_COMMISION);
		  END IF;
		  END;
		  SET SERVEROUTPUT OFF;
		  
	=>If -ELSE statement:
	  E.g:SELECT * FROM EMPLOYEE;
		  SET SERVEROUTPUT ON;
		  DECLARE 
		  E_SALES NUMBER:=30000;
		  E_COMMISION NUMBER:=0;
		  BEGIN
		  IF E_SALES>40000 THEN E_COMMISION:=(E_SALES*10)/100;
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 10% EQUAL TO:'||E_COMMISION);
		  ELSE
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 02% EQUAL TO:'||(E_SALES*2)/100);
		  END IF;
		  END;
		  SET SERVEROUTPUT OFF;
		  
	=>Else-IF statement:
	  E.g:SELECT * FROM EMPLOYEE;
		  SET SERVEROUTPUT ON;
		  DECLARE 
		  E_SALES NUMBER:=30000;
		  E_COMMISION NUMBER:=0;
		  BEGIN
		  IF E_SALES>40000 THEN E_COMMISION:=(E_SALES*10)/100;
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 10% EQUAL TO:'||E_COMMISION);
		  ELSIF E_SALES <=40000 AND E_SALES >30000 THEN E_COMMISION:=(E_SALES*5)/100; -->else if is written as ELSIF in SQL
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 5% EQUAL TO:'||E_COMMISION);
		  ELSE
		  DBMS_OUTPUT.PUT_LINE('YOUR COMMISSION IS 02% EQUAL TO:'||(E_SALES*2)/100);
		  END IF;
		  END;
		  SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------BASIC LOOP--------------------------------
	=>BASIC LOOP execute statements until condition is met.
	=>The body of loop must contains at least one EXIT or EXIT WHEN statement for terminating the loop.
	
	SYNTAX:		<<label>>LOOP
				statements;
				END LOOP loop_label;
	 E.g: 1.SET SERVEROUTPUT ON;
		  	DECLARE
		  	I NUMBER :=0;
		  	BEGIN 
		  	LOOP
		  	I:=I+1;
		  	EXIT WHEN I>10;    -->EXIT WHEN example
		  	DBMS_OUTPUT.PUT_LINE('VALUE OF I WITH EXIT WHEN CONDITION:'||I);
		  	END LOOP;
		  	END;
		  	SET SERVEROUTPUT OFF;
		 2. SET SERVEROUTPUT ON;
		  	DECLARE
		  	I NUMBER :=0;
		  	BEGIN 
		  	LOOP
		  	I:=I+1;
		  	IF I>10 THEN EXIT;-->example with only EXIT
			END IF;    
		  	DBMS_OUTPUT.PUT_LINE('VALUE OF I:'||I);
		  	END LOOP;
		  	END;
		  	SET SERVEROUTPUT OFF;
		3. Example using Lables in loops
		  	SET SERVEROUTPUT ON;
			DECLARE 
			I NUMBER:=0;
			J NUMBER:=0;
			BEGIN 
			<<OUTER_LOOP>> LOOP
			I:=I+1;
			EXIT OUTER_LOOP WHEN I>2;
			DBMS_OUTPUT.PUT_LINE('OUTER LOOP:'||I);
			J:=0;
			<<INNER_LOOP>> LOOP
			J:=J+1;
			EXIT INNER_LOOP WHEN J>3;
			DBMS_OUTPUT.PUT_LINE('INNER LOOP:'||J);
			END LOOP INNER_LOOP;
			END LOOP OUTER_LOOP;
			END;
			SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------WHILE LOOP--------------------------------
	=>WHILE LOOP execute one or more statements while a condition is TRUE
	=>SYNTAX:	
				WHILE condition
				LOOP
				statements;
				END LOOP;
	 E.g:1.SET SERVEROUTPUT ON;
		   DECLARE
		   I NUMBER :=1;
		   BEGIN
		   WHILE I<=10
		   LOOP
		   DBMS_OUTPUT.PUT_LINE('VALUE OF I IN WHILE LOOP IS: '||I);
		   I:=I+1;
		   END LOOP;
		   END;
		   SET SERVEROUTPUT OFF;
		 2.EXIT WHEN condition in WHILE loop
		   SET SERVEROUTPUT ON;
		   DECLARE
		   I NUMBER :=1;
		   BEGIN
		   WHILE I<=10
		   LOOP
		   DBMS_OUTPUT.PUT_LINE('VALUE OF I IN WHILE LOOP IS: '||I);
		   I:=I+1;
		   EXIT WHEN I=3;
		   END LOOP;
		   END;
		   SET SERVEROUTPUT OFF;
		 3.WHILE LOOP example for tables.
		   SET SERVEROUTPUT ON;
		   DECLARE
		   VAR1 NUMBER;
		   VAR2 NUMBER;
		   BEGIN
		   VAR1:=200;
		   VAR2:=1;
		   WHILE VAR2<=10
		   LOOP
		   DBMS_OUTPUT.PUT_LINE(VAR1*VAR2);
		   VAR2:=VAR2+1;
		   END LOOP;
		   END;
		   SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------FOR LOOP--------------------------------
	=>FOR LOOP executes statments for a predetermined number of time
	SYNTAX:
			FOR Index IN initial_value..final_value LOOP
			LOOP statements;
			END LOOP;
	 E.g:1.Printing value of I from 1 to 5
	 	   SET SERVEROUTPUT ON;
	 	   BEGIN
	 	   FOR I IN 1..5 LOOP
	 	   DBMS_OUTPUT.PUT_LINE('VALUE OF I IN FOR LOOP:'||I);
	 	   END LOOP;
	 	   END;
	 	   SET SERVEROUTPUT OFF;
	 	   
	 	 2.Printing tables using for loop
	 	   SET SERVEROUTPUT ON;
	 	   DECLARE
	 	   VAR1 NUMBER;
	 	   BEGIN 
	 	   VAR1:=100;
	 	   FOR VAR2 IN 1..10 LOOP
	 	   DBMS_OUTPUT.PUT_LINE(VAR1*VAR2);
	 	   END LOOP;
	 	   END;
	 	   SET SERVEROUTPUT OFF;
	 	  
	 	 3.Using SQL statements in FOR loop
	 	   SET SERVEROUTPUT ON;
		   BEGIN
	 	   FOR E IN(SELECT * FROM EMPLOYEE) LOOP
	 	   IF E.EMP_SALARY =40000 THEN
	 	   DBMS_OUTPUT.PUT_LINE('ID:'||E.EMP_ID||',NAME:'||E.EMP_NAME||',SALARY:'||E.EMP_SALARY);
	 	   END IF;
	 	   END LOOP;
	 	   END;
	 	   SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------PL/SQL Cursor--------------------------------
	=>When an SQL statement is processed,Oracle creates a memory area known as context area.
	=>A cursor is a pointer to this context area.
	=>It contains all information needed for processing the statement.
	=>In PL/SQL, the context area is controlled by Cursor.
	=>A cursor contains information on a select statement and the rows of data accessed by it.
	=>Cursor use for processing Row-by-Row.
	=>There are two types of Cursors:1.Implicit Cursors
		   							 2.Explicit Cursors
	CURSOR ATTRIBUTES:
	To work with the cursor whether Implicit or Explicit cursor, there are following attributes which are used:
	
	ATRIBUTE NAME		|DESCRIPTION
	1.%ISOPEN			|If cursor is open it returns a Boolean value TRUE otherwise it returns Boolean value FALSE.
	2.%FOUND			|If records fetched by cursor was successful it returns Boolean value TRUE otherwise it returns
						|Boolean value FALSE.
	3.%NOTFOUND			|If records fetched by cursor was unsuccessful it returns Boolean value TRUE otherwise it returns
						|Boolean value FALSE.
	4.%ROWCOUNT			|It returns the number of rows affected by PL/SQL statement.
		  
		  
		   	 	 	 	  	------------------------PL/SQL IMPLICIT CURSORS-------------------------------
	=>The implicit cursors are automatically generated by Oracle while an SQL statement is executed.
	=>These are created by default to process the statements when DML statements like INSERT,UPDATE,DELETE etc. are executed.
	 E.g:SELECT * FROM EMPLOYEE;
		 SET SERVEROUTPUT ON;
		 DECLARE 
		 TOTAL_ROWS NUMBER;
		 BEGIN
		 UPDATE EMPLOYEE SET EMP_SALARY=EMP_SALARY+5000; -->it will add 5000 to all the values in emp_salary in employee table
		 IF SQL%NOTFOUND THEN 
		 DBMS_OUTPUT.PUT_LINE('RECORD NOT UPDATED');
		 ELSIF SQL%FOUND THEN -->in sql else if is written as ELSIF
		 TOTAL_ROWS:=SQL%ROWCOUNT;
		 DBMS_OUTPUT.PUT_LINE('TOTAL ROWS UPDATED:'||TOTAL_ROWS);
		 END IF;
		 END;
		 SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------PL/SQL EXPLICIT CURSORS-------------------------------
	=>Context Area: when a SQL statment is executed in oracle a memory is allocated for that statement. This memory is called
	       			Context Area.
	=>The Explicit cursors are defined by the programmers to gain more control over the context area.
	=>These cursors should be defined in the declaration section of the PL/SQL block.
	=>It is created on a SELECT statement which returns more than one row.
	
		Following is the syntax to create an explicit cursor.
	
		STEPS:
		You must follow these steps while working with an explicit cursor.
		1.Declare the cursor to initialize in the memory.
		2.Open the cursor to allocate memory.
		3.Fecth the cursor to retrive data.
		4.Close the cursor to release allocated memory.
		
		1.DECLARE THE CURSOR:
		It defines the cursor with a name & the associated SELECT statement.
		
		Syntax for explicit cursor declaration
		1.CURSOR name IS
		2.SELECT statement
		
		2.OPEN THE CURSOR:
		It is used to allocate memory for the cursor & make it easy to fetch the rows returned by the SQL statement into it.
		
		Syntax for cursor open:
		1.OPEN cursor_name;
		
		3.FETCH THE CURSOR:
		It is used to access one row at a time. You can fetch rows from the above-opened cursor as follows:
		
		Syntax for cursor fetch:
		1.FETCH cursor_name INTO variable_list;
		
		4.CLOSE THE CURSOR:
		It is used to release the allocated memory.The following syntax is used to close the above-opened cursors.
		
		Syntax for cursor close:
		1.CLOSE cursor_name;
		
		
		E.g:-
			SELECT * FROM EMPLOYEE; 
			SET SERVEROUTPUT ON;
			DECLARE
			E_ID EMPLOYEE.EMP_ID%TYPE;
			E_NAME EMPLOYEE.EMP_NAME%TYPE;
			E_SALARY EMPLOYEE.EMP_SALARY%TYPE;
			CURSOR E_EMPLOYEE IS
			SELECT EMP_ID,EMP_NAME,EMP_SALARY FROM EMPLOYEE;
			BEGIN 
			OPEN E_EMPLOYEE;
			LOOP
			FETCH E_EMPLOYEE INTO E_ID,E_NAME,E_SALARY;
			EXIT WHEN E_EMPLOYEE%NOTFOUND;
			DBMS_OUTPUT.PUT_LINE(E_ID||' : '||E_NAME||' : '||E_SALARY);
			END LOOP;
			CLOSE E_EMPLOYEE;
			END;
			SET SERVEROUTPUT OFF;
		  
		  
		   	 	 	 	  	------------------------TRIGERS-------------------------------
	=>Triggers are stored programs.
	=>which automatically execute or fired(before/after) occurence of some events.
		EVENTS ARE
			1.A Database manipulation (DML) statements (DELETE,INSERT or UPDATE).
			2.A Database definition(DDL) statements (CREATE,ALTER OR DROP).
			3.A Database operation(SERVERERROR,LOGON,LOGOFF,STARTUP or SHUTDOWN).
			
	 E.g:-passing the values to new_employee table if the salary in the employee table is updated or modified.
	 	  SELECT * FROM EMPLOYEE; 
		  CREATE TABLE NEW_EMPLOYEE(ID INT NOT NULL PRIMARY KEY, SALARY DECIMAL(10,2),MESSAGE VARCHAR2(60));
		  SELECT * FROM NEW_EMPLOYEE; 

		  CREATE TRIGGER TRIGGER_EMP
		  AFTER UPDATE OF EMP_SALARY ON EMPLOYEE
		  FOR EACH ROW
		  BEGIN
		  INSERT INTO NEW_EMPLOYEE(ID,SALARY,MESSAGE)
		  VALUES(:OLD.EMP_ID,:NEW.EMP_SALARY,'RECORD IS UPDATED');
		  END;

		  UPDATE EMPLOYEE SET EMP_SALARY=40000 WHERE EMP_ID=1;
		  SELECT * FROM EMPLOYEE;
		  SELECT * FROM NEW_EMPLOYEE;

		  DROP TRIGGER TRIGGER_EMP;
		  DROP TABLE NEW_EMPLOYEE;
		  
		  
		   	 	 	 	  	------------------------PL/SQL PROCEDURE-------------------------------
	=>Procedure is a PL/SQL Block which perform one or more specific tasks.
	=>Procedure is mainly created to perform one or more DML operation over Database.
	=>It is not mandatory to return the value.
	  SYNTAX:
	  	CREATE [OR REPLACE] PROCEDURE procedure_name
	  	[(parameter_name [IN | OUT |IN OUT])] type[....])
	  	{IS | AS}
	  	BEGIN
	  	<procedure_body>
	  	END procedure_name;
	  E.g:-1.CREATE OR REPLACE PROCEDURE WELCOME 
		   	 AS
		  	 BEGIN
		   	 DBMS_OUTPUT.PUT_LINE('WELCOME TO EVIDIEN-BANGALORE');
		   	 END;

		   	 SET SERVEROUT ON;
		   	 BEGIN 
		   	 WELCOME;
		   	 END;
		   	 SET SERVEROUT OFF;

		   	 DROP PROCEDURE WELCOME;
		   	 
		   2.SELECT * FROM DEPARTMENT;
			 CREATE OR REPLACE PROCEDURE INSERT_DEPT(DEPT_ID IN NUMBER ,DEPT_NAME IN VARCHAR2) -->IN represents that parameter will take input.
			 IS
			 BEGIN
			 INSERT INTO DEPARTMENT VALUES(DEPT_ID,DEPT_NAME);
			 END;
			 SET SERVEROUTPUT ON;
			 BEGIN
			 INSERT_DEPT(6,'RECEPTION');
			 END;
			 SELECT * FROM DEPARTMENT;
			 DELETE FROM DEPARTMENT WHERE DEP_ID=6;
			 SET SERVEROUTPUT OFF;
			 DROP PROCEDURE INSERT_DEPT;
			 
		   3.Taking salary amount & ID  from the user & adding it to the respective ID of Employee Table.
			 SELECT * FROM EMPLOYEE;
			 CREATE OR REPLACE PROCEDURE UPDATE_EMP(
			 ID IN NUMBER,AMOUNT IN NUMBER ,D OUT NUMBER)   -->IN is used to take input,OUT is used as output to display something from database.
			 IS
			 BEGIN
			 UPDATE EMPLOYEE SET EMP_SALARY=EMP_SALARY +AMOUNT WHERE EMP_ID=ID;
			 SELECT EMP_SALARY INTO D FROM EMPLOYEE WHERE EMP_ID=ID;
			 DBMS_OUTPUT.PUT_LINE(D);
			 END UPDATE_EMP;

			 SET SERVEROUTPUT ON;
			 VARIABLE K NUMBER;
			 EXECUTE UPDATE_EMP(1,10000,:K);
			 SET SERVEROUTPUT OFF;
			 SELECT * FROM EMPLOYEE;
			 DROP PROCEDURE UPDATE_EMP;
		  
		  
		   	 	 	 	  	------------------------PL/SQL FUNCTION-------------------------------
	=>The PL/SQL Function is very similar to PL/SQL procedure,but a function must always return a value.
	=>Use RETURN to return the value.
	=>Return datatype is mandatory at the time of creation.
	=>Used mainly to perform some calculation.
	 
	 Syntax:
	 	CREATE [OR REPLACE] FUNCTION function_name
	 	[(parameter_name [IN | OUT | IN OUT])] type[...])
	 	RETURN return_datatype
	 	{IS | AS}
	 	BEGIN
	 	<function_body>
	 	END function_name;
	 
	 E.g: 1.CREATE OR REPLACE FUNCTION ADD_NUMBER(
		    N1 IN NUMBER, N2 IN NUMBER)
		 	RETURN NUMBER
		 	IS
		 	N3 NUMBER;
		 	BEGIN
		 	N3:=N1+N2;
		 	RETURN N3;
		 	END ADD_NUMBER;

		 	SET SERVEROUTPU ON;
		 	DECLARE
		 	N3 NUMBER;
		 	BEGIN
		 	N3:=ADD_NUMBER(50,20);
		 	DBMS_OUTPUT.PUT_LINE('ADDITION IS :'|| N3);
		 	END;
		 	SET SERVEROUTPU OFF;
		 	DROP FUNCTION ADD_NUMBER;
		 	
		  2.Taking salary amount & ID  from the user & adding it to the respective ID of Employee Table.
			SELECT * FROM EMPLOYEE;
			CREATE OR REPLACE FUNCTION UPDATE_SAL(
			ID IN NUMBER,AMOUNT IN NUMBER)
			RETURN NUMBER
			IS 
			D NUMBER;
			BEGIN
			UPDATE EMPLOYEE SET EMP_SALARY=EMP_SALARY+AMOUNT WHERE EMP_ID=ID;
			SELECT EMP_SALARY INTO D FROM EMPLOYEE WHERE EMP_ID=ID;
			DBMS_OUTPUT.PUT_LINE('NEW SALARY: '||D);
			RETURN D;
			END UPDATE_SAL;

			SET SERVEROUTPUT ON;
			DECLARE 
			D NUMBER;
			BEGIN
			D:=UPDATE_SAL(3,10000);
			END;
			SET SERVEROUTPUT OFF;
			DROP FUNCTION UPDATE_SAL;
		  
		  
		   	 	 	 	  	------------------------PL/SQL EXCEPTION HANDLING-------------------------------
	=>An error occurs during the program execution is called Exception in PL/SQL
	=>There are two types of Exceptions:
			1.Pre-defined Exceptions.
			2.User-defined Exceptions.
			
	 PRE-DEFINED EXCEPTIONS:
	 =>There are many pre-defined exception in PL/SQL which are executed when any database rule is violated by the programs.
   	 SYNTAX:
   	 		DECLARE
   	 			<declarations section>
   	 		BEGIN
   	 			<executable command(s)>
   	 		EXCEPTION
   	 			<exception handling goes here>
   	 			WHEN exception1 THEN
   	 				exception1-handling-statements
   	 			WHEN exception2 THEN
   	 				exception2-handling-statements
   	 			WHEN excpetion3 THEN
   	 				exception3-handling-statements
   	 			................
   	 			WHEN others THEN 
   	 				exception other-handling-statements
   			END;
    =>Following is a list of some important pre-defined exceptions:
    	EXCEPTION			ORACLE		SQL		DESCRIPTION
    						ERROR		CODE
    1.ACCESS_INTO_NULL		06530		-6530    It is raised when a NULL object is automatically assigned a value
    2.CASE_NOT_FOUND		06592		-6592	 None of the 'WHEN' clause in CASE statement satisfied and no 'ELSE' clause
    											 is specified.
    3.COLLECTION_IS_NULL	06531		-6531	 Using collection methods (except EXISTS) or accessing collection attributes
    											 on an uninitialized collections.
    4.DUP_VAL_ON_INDEX		00001		-1		 It is raised when duplicate values are attempted to be stored in a column
    											 with unique index.
    5.INVALID_CURSOR		01001		-1001	 Illegal cursor operations like closing an unopened cursor
    6.INVALID_NUMBER		01722		-1722    Conversion of character to a number failed due to invalid number character
    7.LOGIN_DENIED			01017		-1017    It is raised when s program attempts to log on to the database with an 
    											 invalid username or password.
 	9.NO_DATA_FOUND			01403		+100	 It is raised when a Select into statement returns no rows.
 	10.NOT_LOGGED_ON		01012		-1012	 it is raised when a database call is issued without being connected to the
 												 database.
 	11.PROGRAM_ERROR 		06501		-6501	 It is raised when PL/SQL has an internal problem.
 	12.ROWTYPE_MISMATCH     06504		-6504    It is raised when a cursor fetches value in a variable having incompatible
 												 data type.
 	13.SELF_IS_NUll			30625		-30625	 It is raised when a member method is invoked, but the instance of the object
 												 type was not initialized.
 	14.STORAGE_ERROR 		06500		-6500    It is raised when PL/SQl ran out of memory or memory was corrupted.
 	15.TOO_MANY_ROWS 		01422		-1422 	 It is raised when a SELECT INTO statement returns more than one row.
 	16.VALUE_ERROR			06502		-6502	 Arithmetic or size constraint error (eg.assigning a value to a variable that
 												 is larger than the variable size).
 	17.ZERO_DIVIDE			01476		1476	 It is raised when an attempt is made to divide a number by zero.
 		
 		E.g:SELECT * FROM EMPLOYEE;
			SET SERVEROUTPUT ON ;
			DECLARE-->we take input from the user & keeping that input as base we will display corresponging record
			E_ID EMPLOYEE.EMP_ID%TYPE;
			E_NAME EMPLOYEE.EMP_NAME%TYPE;
			BEGIN
			SELECT EMP_NAME INTO E_NAME FROM EMPLOYEE WHERE EMP_ID=&E_ID;
			DBMS_OUTPUT.PUT_LINE(E_NAME);
			END;  -->give input id which is not present in the employee table
			SET SERVEROUTPUT OFF;

			-->exceptional handling for above example.
			SET SERVEROUTPUT ON ;
			DECLARE 
			E_ID EMPLOYEE.EMP_ID%TYPE;
			E_NAME EMPLOYEE.EMP_NAME%TYPE;
			BEGIN
			SELECT EMP_NAME INTO E_NAME FROM EMPLOYEE WHERE EMP_ID=&E_ID;
			DBMS_OUTPUT.PUT_LINE(E_NAME);
			EXCEPTION WHEN NO_DATA_FOUND THEN
			DBMS_OUTPUT.PUT_LINE('RECORD ID IS NOT THERE');  -->EXCEPTION handled for above case
			WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('ERROR!'); 
			END;  
			SET SERVEROUTPUT OFF;
		
	 RAISING EXCEPTIONS:
	 =>All the predefined exceptions are raised implicitly whenever the error occurs.
	 =>User-defined exceptions needs to be raised explicitly.
	 =>This can be achieved using the keyword 'RAISE'. This can be used in any of the ways mentioned below
	 
	 	SYNTAX FOR RAISING AN EXCEPTION:
	 	
	 		DECLARE
	 			exception_name EXCEPTION;
	 		BEGIN
	 			IF condition THEN	
	 				RAISE exception_name;
	 			END IF;
	 		EXCEPTION
	 			WHEN exception_name THEN
	 			statement;
	 		END;
	  	E.g:SET SERVEROUTPUT ON;
			DECLARE
			N NUMBER :=&N;
			EX_INVALID EXCEPTION;
			BEGIN
			IF N>=5 THEN
			RAISE EX_INVALID;
			ELSE 
			DBMS_OUTPUT.PUT_LINE('N IS LESS THEN 5');
			END IF;
			EXCEPTION WHEN EX_INVALID THEN
			DBMS_OUTPUT.PUT_LINE('N IS GREATER THAN 5');
			END;
			SET SERVEROUTPUT OFF;	
	 
	 USER-DEFINED EXCEPTIONS
	 =>PL/SQL facilitates their users to define their own exceptions according to the need of the program.
	 =>A user-defined exception can be raised explicitly,using either a RAISE statement or the procedure 
	   DBMS_STANDARD.RAISE_APPLICATION_ERROR.
	   
	   SYNTAX FOR USER DEFINE EXCEPTIONS
	    DECLARE
	    <exception_name> EXCEPTION;
	    BEGIN
	    <exception block>
	    EXCEPTION
	    WHEN <exception_name> THEN
	    <Handler>
	    END;
	      
	      E.g:SELECT * FROM EMPLOYEE;
			  SET SERVEROUTPUT ON ;
			  DECLARE-->we take input from the user & keeping that input as base we will display corresponging record
			  E_ID EMPLOYEE.EMP_ID%TYPE:=&E_ID;
			  E_NAME EMPLOYEE.EMP_NAME%TYPE;
			  EX_INVALID EXCEPTION;
			  BEGIN
			  IF E_ID<=0 THEN 
			  RAISE EX_INVALID;
			  ELSE
			  SELECT EMP_NAME INTO E_NAME FROM EMPLOYEE WHERE EMP_ID=E_ID;
			  DBMS_OUTPUT.PUT_LINE(E_NAME);
			  END IF;
			  EXCEPTION WHEN EX_INVALID THEN   -->User defined exception
			  DBMS_OUTPUT.PUT_LINE('ID MUST BE GREATER THAN ZERO');
			  WHEN NO_DATA_FOUND THEN-->system defined or pre-defined exception
			  DBMS_OUTPUT.PUT_LINE('NO SUCH EMPLOYEE IS PRESENT IN THE RECORD WITH THE GIVEN ID');
			  WHEN OTHERS THEN
			  DBMS_OUTPUT.PUT_LINE('ERROR!');
			  END;
			  SET SERVEROUTPUT OFF ;
		  
		  
		   	 	 	 	  	------------------------PL/SQL PACKAGE-------------------------------
	=>Package is a schema object that contains definitions for a group of related functionalities.
	=>Package includes variables ,constants ,cursors,exception,procedures and functions etc.
	=>Package is compiled and stored as a database object that can be used later.
	
	COMPONENTS OF PACKAGE:
		1.Package Specification
		2.Package body
	
	PACKAGE SPECIFICATION:
		Package specification consists of as declaration of all the public variables,cursors,objects,procedures,functions
		and exception
		
		SYNTAX:
			CREATE [OR REPLACE] PACKAGE <package_name>
			IS |  AS
			<sub_program and public element declaration>
			END <package_name>;
	
	PACKAGE BODY:
		It consist of the definition of all the elements that are present in the package specification.
		
		SYNTAX:
			CREATE [OR REPLACE] PACKAGE BODY
			<package_name>
			IS | AS
			<global_declaration part>
			<private element and public element definition>
			.
			.
			<Package initialization>
			END <package_name>;
			
	  E.g:-SELECT * FROM DEPARTMENT;
		   CREATE OR REPLACE PACKAGE PACKAGE_DEPARTMENT-->PACKAGE SPECIFICATION
		   AS
		   PROCEDURE INSERT_DEPARTMENT(DEP_ID IN NUMBER,DEPT_NAME IN VARCHAR2);-->IN is used for input
		   PROCEDURE DELETE_DEPARTMENT(DELETE_ID IN NUMBER);
		   FUNCTION ADD_NUMBER(N1 IN NUMBER,N2 IN NUMBER)
		   RETURN NUMBER;
		   END;

		   CREATE OR REPLACE PACKAGE BODY PACKAGE_DEPARTMENT -->PACKAGE BODY
		   AS
		   PROCEDURE INSERT_DEPARTMENT(DEP_ID IN NUMBER,DEPT_NAME IN VARCHAR2)
		   IS
		   BEGIN
		   INSERT INTO DEPARTMENT VALUES (DEP_ID,DEPT_NAME);
		   END INSERT_DEPARTMENT;
		   PROCEDURE DELETE_DEPARTMENT(DELETE_ID IN NUMBER)
		   IS 
		   BEGIN
		   DELETE FROM DEPARTMENT WHERE DEP_ID=DELETE_ID;
		   END DELETE_DEPARTMENT;
		   FUNCTION ADD_NUMBER(N1 IN NUMBER, N2 IN NUMBER)
		   RETURN NUMBER 
		   IS
		   N3 NUMBER;
		   BEGIN
		   N3:=N1+N2;
		   RETURN N3;
		   END ADD_NUMBER;
		   END PACKAGE_DEPARTMENT;

		   SET SERVEROUTPUT ON;-->Using these procedures & functions
		   BEGIN-->Procedure 1 i.e Insert_department
		   PACKAGE_DEPARTMENT.INSERT_DEPARTMENT(6,'INSURANCE');
		   END;
		   SELECT * FROM DEPARTMENT;

		   BEGIN-->procedure 2 i.e delete_department
		   PACKAGE_DEPARTMENT.DELETE_DEPARTMENT(6);
		   DBMS_OUTPUT.PUT_LINE('RECORD DELETED');
		   END;
		   SELECT * FROM DEPARTMENT;

		   DECLARE-->Function 1 i.e add_number
		   N3 NUMBER;
		   BEGIN
		   N3:=PACKAGE_DEPARTMENT.ADD_NUMBER(50,20);
		   DBMS_OUTPUT.PUT_LINE('ADDITION OF N1 AND N2 IS '|| N3);
		   END;
		   SET SERVEROUTPUT OFF;
		   DROP PACKAGE BODY PACKAGE_DEPARTMENT;
		   DROP PACKAGE PACKAGE_DEPARTMENT;
   	*/
}
