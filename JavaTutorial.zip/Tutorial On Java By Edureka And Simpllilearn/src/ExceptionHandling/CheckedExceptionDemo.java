package ExceptionHandling;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CheckedExceptionDemo {
		public static void main (String args[])throws FileNotFoundException,IOException {
			FileReader file=new FileReader("C:\\test\\a.txt");  //Throws error at compile time only --> Unhandled exception type FileNotFoundException
			BufferedReader fileInput=new BufferedReader(file);
			
			//PRint first 3 lines of File "C:\\test\\a.txt"
			for(int counter=0;counter<3;counter++) {
				System.out.println(fileInput.readLine()); //Unhandled exception type IOException
			}
			fileInput.close();//Unhandled exception type IOException
		}
}
//whoever is calling the main method has the responsibilty of handling FileNotFoundException& IO EXception