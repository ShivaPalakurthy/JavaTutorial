package ExceptionHandling;
import java.util.ArrayList;

 class WriterHelper {
	public void WriteList() {
		try {
			ArrayList<Integer> list=new ArrayList<Integer>(10);
			list.add(10);
			
			System.out.println("Entering "+"try Statement");
			Integer a=list.get(1);  //we aadded 10 to o index so we get exception when we try for 1 index try with 0 and see answer
			System.out.println("accessing the first Element: "+a);
		}
		catch(IndexOutOfBoundsException e){
			System.err.println("Caught IndexOutOfBoundsException: "+e.getMessage());
		}
		/*
		 * You can have multiple catch blocks in a code but they follow sequential manner if exception is found at 
		 * a catch block it'll directly jumps to finally block & it wont check remaining catch blocks
		 */
		catch(ArithmeticException e) {
			System.out.println("Caught ArrithematicException: "+e.getMessage());
		}
		finally {
			System.out.println("this will always be executed");
		}
	}
}
public class TryCatchDemo {
	public static void main(String args[]) {
		WriterHelper helper=new WriterHelper();
		helper.WriteList();
	}
}
/*
Entering try Statement
Caught IndexOutOfBoundsException: Index 1 out of bounds for length 1
this will always be executed
*/