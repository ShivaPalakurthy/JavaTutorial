package ExceptionHandling;

public class MyException extends Exception {
		//default Constructor
	 MyException() {
		 
	}
	 //Parameterized COnstructor
	 MyException(String str){
		 super(str);
	 }
}
//whenever we are creating a custom exception its by default a checked exception so our program has to handle it