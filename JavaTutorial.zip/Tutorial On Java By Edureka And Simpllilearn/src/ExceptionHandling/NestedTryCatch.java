package ExceptionHandling;

public class NestedTryCatch {
		public static void main(String args[]) {
			try {//block1
				try{//block2
					try {//block3
						int arr[]= {1,2,3,4};
					//	int a=100/0; //-->directly gives general exception
						
						System.out.println(arr[10]);
					}catch(ArrayIndexOutOfBoundsException e) {
						System.out.println("ArrayIndexOutOfBounds Exception in block 3");
						throw e;
					}
				}
				catch(ArrayIndexOutOfBoundsException e) {
					System.out.println("ArrayIndexOutOfBounds Exception in block 2");
					throw e;  //-->the exception is rethrown to inclusing try block i.e out try block
				}
			}
			catch(ArrayIndexOutOfBoundsException e4){
				System.out.println("ArrayIndexOutOfBoundsException in block 1");
			}
			catch(Exception e5) {
				System.out.println("general Exception");
			}
		} 
		
}
