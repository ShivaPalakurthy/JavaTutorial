package ExceptionHandling;

public class MyExceptionMainCode {
/*	public static void main(String args[]) {
		
		throw new MyException(); //Unhandled exception type MyException -->you have to handle her or
	}   */																			   //
																					  //
																					 //
public static void main(String args[]) throws MyException { //let the caller handle it
		
		throw new MyException(); //Unhandled exception type MyException -->you have to handle her or
	} 
}
