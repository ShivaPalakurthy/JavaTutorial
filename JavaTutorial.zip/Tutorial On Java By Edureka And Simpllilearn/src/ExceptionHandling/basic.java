package ExceptionHandling;

public class basic {
/*
  Eroors & Exceptions comes under the throwable Class.
  
  										Throwable
  											|
  		------------------------------------------------------------------------------
  		|																			 |
  Exception																			Error
  		|																			  |
  		|----IO-Exception															  |----JVM Error
  		|																			  |
  		|----SQL-Exception															  |----Memory
  		|																			  |
  		|----ClassNotFOund															  |----FrameWork
  		|
  		|----Run-Time Exceptions
  				 |
  				 |----Arithmetic
  				 |
  				 |----NumberFormat
  				 
  				 
 Exception is a type of problem which can be recovered in a program. Run time exceptions are called as unchecked exceptions
 where as compile time exceptions are called as checked exceptions.
 We can also create our own exception also , refer to MyException code
 
 
 
 */
	public static void main(String args[]) {
		
//		int data=100/0;  //divide by 0 -->gives null pointer exception
//		System.out.println(data);
		
		String a=null;//when ever we try to do any operation on null object it throws NUllPointerException 
		System.out.println(a.charAt(0)); //java.lang.NullPointerException: Cannot invoke "String.charAt(int)" because "a" is null
	}
}