package MultithreadingInJava;

/*
 * 			 // Concurrency & threads 
 * Multiple tasks eg. we are writing code in keyboad while display is diplaying & also eclipse
 * is running & also lot of tasks running in background at the same time. SOftware that can
 * do such tasks is called as concurrent software & that idea in called concurrency.
 * We work with concurrency in java is with the help of proccesses & threads. these are the basic
 * two units of execution when we talk about concurrent programming
 * 
 *  Processes:
 *  A process has a self-contained execution environment. A process generally has a complete,
 *  private set of basic run-time resources. in particular, each process has its own memory space
 *  Process can be think as a or called as a standalone execution enivronment.
 *  
 *  Threads:
 *  Threads are sometimes called as light weight processes.Both prcoess & threads provides
 *  execution environment,but creating a new thread requires fewer resources than creating a
 *  new process. Threads can be treated as a mini version of a process because a process 
 *  can have multiple threads
 *  A Process can have multiple threads,threads always exits within the process & whenever
 *  you start a process there will be atleast one thread attached to it & each thread is basically
 *  a task
 *  
 *  Multi Threading: Multiple threads running at a same time to create a better expeirience in the
 *  apllication
 */
public class ThreadingDemo {
	public static void main(String args[]) {
		int n=10;//number of threads
		for(int i=0;i<n;i++) {
			
			//Initialising two threads
			Thread1 t1=new Thread1();
			/*
			 * To run a thread first thing we should do is to  initialize the class
			 * containing the run method so we basically create the object of the thread
			 */
			t1.start();//This is the internal method of the Thread class  which inturn is 
			// going to call the run method so we are never going to invoke the run method
			//directly, we just need to start the thread which is going to change the state of the
			//thread from ready to running.so this start has the responsibilty of changing
//			the state of the thread from ready to running, the way the start() method going to do
//				is by calling the run()method internally in the JDK istelf
			
			Thread t2= new Thread(new Thread2());
			/*
			 * Initialisation of Thread2 is diferent  Thread is thread class form JDK
			 * iniside new Thread()-->we provide our own class type.
			 * so we specifiy our own custom thread class (new Thread2()) inside the
			 * new Thread Constructor
			 */
			t2.start();
		}
	}
}

/*
 * OUTPUT:
 * Thread1 is running
Thread 2 is running
Thread1 is running
Thread 2 is running
Thread1 is running
Thread 2 is running
Thread1 is running
Thread1 is running
Thread 2 is running
Thread 2 is running
Thread1 is running
Thread 2 is running
Thread1 is running
Thread 2 is running
Thread 2 is running
Thread1 is running
Thread1 is running
Thread 2 is running
Thread1 is running
Thread 2 is running

If we observe there is no particular order, this is because of concurrency i.e threads
don't run in sequence but they run in parallel.so when ever we run threads , we can't 
predict the sequence of order as they are running in parallel & they run whenever each 
thread gets there ideal CPU.
 */