package MultithreadingInJava;

public class Thread1 extends Thread{ //Thread is pre build thread class in java.lang package i.e JDK basically
	@Override
	public void run() {  //Overriding run method of thread
		try {
			System.out.println("Thread1 is running");
			
		}catch(Exception e) {
			//throwing an exception
			System.out.println("Exception raised"+e);
		}
	}
}
/* There are different states in the thread so these are  thread which says thread is ready
 * there is a state which says thread is running , there is also a state where the thread is
 * waiting for an IO input from the user from the console or the command line, there can also 
 * be a state which says dead where the thread has completed its task & it's not working
 * There is also can be a state which is called sleep state  where the thread is paused 
 * so there are different states of the thread & in this example we are going to focus
 * primarily on  three states which is the ready state & the running state & the completed
 * state. SO when we call the run() method the thread is state is going to change into
 * running & whatever code we've written inside this particular method will be the logic
 * which this particular thread is suppossed to execute
 */
