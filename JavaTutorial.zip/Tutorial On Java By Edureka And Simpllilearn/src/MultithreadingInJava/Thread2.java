package MultithreadingInJava;

public class Thread2  implements Runnable { //Runnable Interface is form java.lang package
		/*
		 * Runnable Interface is a functional Interface in java.lang package, it has only 
		 * one method that it run() method which need to be override in Thread2.
		 * The reason why java provides two different ways of creating threads (extends,
		 * implements) is because there might be a use case that we need to extend your 
		 * thread to class from some of our custom java class. As java doesn't support multiple
		 * inheritance, so by using implements Runnable we can extend a parent class properties
		 * as well with the thread
		 * eg.public class Thread2 extends Student implements Runnable{
		 * }
		 * by this we get properties of Student in Thread2 along with thread properties
		 * from the implements Runnable so that we can treat Thread2 class as a thread
		 */
	@Override
	public void run() {
			try {
				System.out.println("Thread 2 is running");
			}catch(Exception e) {
				//Throwing an Exception
				System.out.println("Exception is caught");
			}
		}
}
