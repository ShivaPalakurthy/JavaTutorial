package InputAndOutputStreamsInJava;
/*
 * I/o stream represents an input source or an output destination.generally I/O handling
 * involves taking input from some external source can be command line, can be from disk
 * files,it can be from hard disk. We have input source , we have output destination
 * the way the input source sends the data to the destination is via streams.basically
 * it converts the data into 1s & 0s and it travels as a stream
 * A program uses an Input Stream to read data from a source,one item at a time.
 * A program uses an output Stream to write data to a destination,one item at a time
 * 
 * Java provides the classes to read from a file or to write from a file using the fileInputStream
 * & the fileOutputStream class respectively
 * 
 * 							   ----------------------------
 * 							   |java.io.* class hierarchy |
 * 						       ----------------------------
 * 																		 <---== Inheritence symbol
 * 					   |<---java.io.InputStream <---java.io.FileInputStream
 * 					   |<---java.io.OutputStream<---java.io.FileOutputStream
 * java.lang.Object<---|<---java.lang.System								|<---java.io.BufferedReader
 * 					   |<---java.io.Reader<---java.io.InputStreamReader<----|<---java.io.FileReader
 * 					   |<---java.io.Writer<---java.io.OutputStreamWriter<---java.io.FileWriter
 * 
 * There are two different types of Streams i.Byte Stream; ii.Character Stream
 * we need two different types of Streams because whenever we are reading data from some data source
 *  or writing data to the data source , the data can be simple character STrings like English or unque 
 *  code characters or can  be some tabular data setting in a database ,it can be an xml file, it can be
 *  a html file, it can be a image,it can be an mathematical expression file.so thats the
 *  reason java has created two different type of classes that if you want to work on particualr file which
 *  is holding characters then we can use Character Stream And if you don't know what kind of data
 *  the file is contained then use Byte Stream. when we use character stream, the file will be read 
 *  character by character & when we use byte Stream the file will read byte by byte
 *  
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.*;

 
public class ByteStreamExample {
		public static void main(String args[]) throws IOException {
			 
			FileInputStream inStream=null;  //read operation
			FileOutputStream outStream=null; //write operation
			
			try {
				inStream =new FileInputStream("C:\\Files\\IOStreams\\sourcebytestream.txt");
				outStream=new FileOutputStream("C:\\Files\\IOStreams\\destbytestream.txt") ;
				
				//reads a byte at a time,if it reached end of the file,returns -1
				int content;
				while((content=inStream.read()) != -1) {
					outStream.write((byte) content); //since content is int, we need to convert int content to byte by using explicit caste (byte) content
				}
			}
			 finally {
				if(inStream!=null) {
					inStream.close();
				}
				if(outStream!=null) {
					outStream.close();
				}
			}
		}
 
}
