package Basic;

class OuterClass1 {
	class InnerClass{
		public void display() {
			System.out.println("This is a inner class method");
		}
	}
	//Method LOcal In a Class-->creating a class inside the method of the other class
	
	void outerClassMethod() {
		System.out.println("in the outer class method");
	
		class MethodLocalClass{
			void localInnerMethod() {
				System.out.println("in the method local class: Method ");
			}
		}
		MethodLocalClass mlc=new MethodLocalClass();
		mlc.localInnerMethod();
	}
}

public class NonStaticNestedClassOrInnerClass {
	public static void main(String args[]) {
		 
		OuterClass1.InnerClass obj=new OuterClass1().new InnerClass();/* we will initialise
		object of the outerCLass first then that object of the outer class can be used to 
		create an object of the Inner class
		*/ 
		obj.display();
		
		OuterClass1 outerClass=new OuterClass1();
		outerClass.outerClassMethod();
		
	}
}
// also study anonymous class representation

