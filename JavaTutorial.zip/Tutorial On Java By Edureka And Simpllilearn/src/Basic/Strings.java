package Basic;

public class Strings {
	
	/*
	 * 						STRINGS
	 * 1.Java String is a sequence of characters
	 * 2.They are objects of type String Class
	 * 3.Once a String object is created, it can not be changed. Strings are immutable
	 * 
   Different ways of declaring a String
   								char c[]= {'a', 'b', 'c'};
   	String creation using <-----String str= new String();
   	new keyword					String str1="edureka!";------>String creation using literals
   		
   						Immutability Of Strings
   						
   	Java Strings are immutable for several reasons:
   	1.Security: Strings are used for network connection and for database connection. 
   	To avoid the access to these connections from external users, Strings are immutable.
   	2.Synchronization: Immutability of Strings automatically makes system thread safe to solve 
   	the synchronization problem
   	3.Caching: If two String objects are having the same value, and you need only one string, 
   	then the two objects will point to the same memory location pointing same String object
 
 		STRING POOL:-
 		i.String Pool used in Java is a pool of strings stored in Java Heap Memory
 		ii.String Pool is possible only because Strings are immutable
 		iii.String Pool helps in saving lot of space for Java Runtime
 		
 					-------------------------------------------------------------
 					|   			[ H | E | L | L | O ]						|					  |
 					|  [ H | O | W |   | A | R | E |   | Y | O | U ]			|
 					-------------------------------------------------------------
 								String Pool
 		The String Pool can contain multiple Strings but a heap memory can have only one 
 		String Pool.
 		
 		
 		Strings - Memory Allocation
 		
 		public class String_Demo {
        public static void main(String[] args) {
        String s1="Happy";
		System.out.println("Original String is: "+sl);
		System.out.println("After concatenation String is: "+sl.concat(" Learning"));
		}
		}
		
		
																	String Pool
		[------------------]				|----------------------------------------------------------------|
		|	STACK		S1-|---=============|======================>[ H | E | L | L | O ]					 |
		|------------------|  /				|																 |
		|	HEAP		[]=|=/--------------|-->[ H | A | P | P | Y |   | L | E | A | R | N | I | N | G ]	 |
		|------------------|				|----------------------------------------------------------------|
		|	DATA SECTION   |
		|------------------|
		|	CODE SECTION---|				When you concatenate a second string with the first one, then the 
		[------------------]				String pointer s1 will still point to first string
		
		
		In the previous example, we are concatenating second String with first String. But after concatenating,
		 the stack pointer still points to first String.
		 To solve this problem, we can update first String with concatenated String.
		 
		 public class String_Demo {
		public static void main(String[] args) {
		String s1="Happy";
		System.out.println("Original String is: "+s1);
		s1=s1.concat(" Learning");
		System.out.println("After concatenation String is: "+s1);
		} }  //------------->Output :Original String is: Happy
									After concatenation String is: Happy Learning
									
		
				
																	String Pool
		[------------------]				|----------------------------------------------------------------|
		|	STACK		S1-|---\/-----------|----------------------->[ H | E | L | L | O ]					 |
		|------------------|   /\			|																 |
		|	HEAP		[]=|==/--\==========|==>[ H | A | P | P | Y |   | L | E | A | R | N | I | N | G ]	 |
		|------------------|				|----------------------------------------------------------------|
		|	DATA SECTION   |
		|------------------|
		|	CODE SECTION---|				 
		[------------------]	
		
		
		
		Demo - String Operations
						//Length of string
		1.length()=====>String s1=new String("Hello World"); 		It returns the length of the String
					    System.out.println(s1.length());
									||
									\/	Output
									11
									
						//substring
		2.substring()==>String sub=new String("Welcome"); 			It returns the substring from specified beginning index
						System.out.println(sub.substring(2));
									||					 |
									\/Output			  ----->Substring beginning index
								 	Icome
						//String Comparison
		3.compareTo()==>String s1="Hello";							It compares the given string with current string
						String s2="Heldo";
						System.out.println(sl.compareTo(s2));
									||
									\/	Output
									8	---->When we compare s2 with s1, then in s2 "L" from s1 is replaced with "d",
									 			so the difference between these 2 alphabets is 8 (s1-s2)
						//IsEmpty
		4.isEmpty()====>String s4="";								This method checks whether the String is empty or not. 
						System.out.println(s4.isEmpty());			If the Java String is Empty, it returns true else false
									||
									\/	Output
									true
						//toLowerCase
	    5.toLowerCase()==>String s1="Hello";
	    				  System.out.println(sl.toLowerCase());		It converts all the characters of the String to lower case
									||
									\/	Output
								  hello
						//toUpperCase
	 	6.toUpperCase()==>String s1="Hello"; 
	 					  System.out.println(s1.toUpperCase());		It converts all the characters of the String to upper case
									||
									\/	Output
								  HELLO						
		7.valueOf()======>int a=50;									It converts different data types into string
						  String s=String.valueOf(a);
						  System.out.println(s);
									||
									\/	Output
									50
						  //replace
		8.replace()======>String s2="Heldo"; 						It returns a string, replacing all the old characters to new characters
						  String replace=s2.replace('d', 'l'); 
						  System.out.println(replace);
									||
									\/	Output
								  Hello
						  //contains
		9.contains()=====>String s2="Heldo";						It searches the sequence of characters in the string.
						 String replace=s2.replace('d'.'l');		If the sequences of characters are found, then it returns true
						 System.out.println(replace.contains("d")); otherwise returns false (Java is a case-sensitive language)
									||
									\/	Output
								  false
						  //equals
		10.equals()======>String x="Welcome to Edureka";			It compares the two given strings on the basis of the content of the string
						  String y="WeLcOme tO eDurEkA"; 
						  System.out.println(x.equals(y));
									||
									\/	Output
								  false
						  //charAt
		11.charAt()======>String x="Welcome to Edureka";			It returns the character present at given index
						  System.out.println(x.charAt (3));
						  			||
									\/	Output
								  	C
						  //endsWith	
		12.endsWith()====>String p="Happy Learning"; 				It checks if this string ends with the given character or sequence of characters. If it 
						  System.out.println(p.endsWith("u"));		returns with the given character or sequence of characters, it will return true else returns false
						  			||
									\/	Output
								  false
	 */	
	

	 //compareTo example
	
	public static void main(String args[]) {
		String s1="Edureka";
		String s2="Edureka";  //0-->equal;1-->s1>s2;-1-->s2>s1
		
		int i=100;
		System.out.println("Printing equality of strings " +s1.equals(s2));
		System.out.println(String.valueOf(i));
		System.out.println(s1.compareTo(s2));
		System.out.println(s1);
		System.out.println(s1.replace('E', 'e'));
		System.out.println(s1.toUpperCase());
		System.out.println(s1.length());
		System.out.println(s1.substring(2));
	}
	
	
	
	
	
	
	
	
	
	
/*
 * Strings are immutable-->once you write you can't change the value.This is specifially
 * important when we are doing multi-threading.AS strings are immutable i.e their values
 * wont change multiple threads can access at the same time (thread safe),there by 
 * acheiveing MiltiThreading.
 * 
 * caching If we have multiple strings holding the same value,it wont create multiple copies
 * of the string, there will be one value in the string pool which will be acccessed by 
 * all the references
 * 
 * StringBuffer is good for multithreading because all the reads& writes that we do on the
 * string is SYnchronised. SYnchronised->means there will be only one thread that can access
 * a particular method within a class at any given point.SO you won't have multiple 
 * threads going & changing  the value. In stringBuffer we can append but we can't in STrings
 * 
 * we dont have methods to manipulate the String where as in StringBuffer you have 
 * methods to manipulate the string
 * 
 * The capacity of the STrinGBuffer is it reserves 16 charachteers initially & it keeps on
 * incrementing when we declare it.
 * 
 * 
 * STringBuffer disadvantage is Syschronised that is only one thread can go at a time.We have
 * to go with string builder if we knwo that there wont be multiple threads accessing it rather
 * that STring buffer & String builder offfers faster spped then StringBuffer
 * String builder is similar to StringBUffer but its not thread safe
 * 
 * SO if we have multiple threads accessing then go with STringBuffer,but for a single threaded
 * application we should go with StringBuilder
 * 
 * 
 * 
 * 
 * regular expression can be used to check as pattern checker,regular expression is a pattern
 * used for searching & manipulating strings.eg email boxes showing wrong input if we don't 
 * give @gmail.com in last. writing abcd in place of numbers
 */
}
