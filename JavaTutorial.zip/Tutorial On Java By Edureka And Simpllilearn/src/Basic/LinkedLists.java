package Basic;
import java.util.LinkedList;

public class LinkedLists {
/* Linkedlist:order of the element is strictly maintained i.e first element will refer 
 * to the second element,while second will refer to the third element and third element to the 
 * 4th element so on. we cannot randomly access a element in Linkedlist as we could 
 * do in ArrayList. Linkedlist is not syncrhonised-->If multiple threads tries to access
 * linkedlist concurently atleast one of the thread tries to modify, then it must be 
 * synchronised externaly else it gets unpredictable errors.
 * 
 */
	public static void main(String args[]) {
		LinkedList<String> list=new LinkedList<String>();
		
		
		list.add("A");
		list.add("B");
		System.out.println(list);
		
		list.addLast("C");
		System.out.println(list);
		
		list.addFirst("D");
		System.out.println(list);
		
		list.add(2, "E");
		System.out.println(list);
		
		list.remove("B");
		System.out.println(list);
		
		list.remove(3);
		System.out.println(list);
		
		list.removeFirst();
		System.out.println(list);
		
		list.removeLast();
		
		System.out.println(list);
	}
}
