package Basic;
/*
	JAVA STATIC KEYWORD
1.The Static keyword is used for memory management
2.Static is a non access modifier used in Java, applicable for blocks, methods,
class variables
3.Static keyword is used to refer the common properties of an object
4.When the static keyword is used to declare any parameter, then memory is allocated
only once for that parameter
Example:1 
class Employees{
int id;
int salary;
static String company="SRT Traders";   -->company is a Static variable. It allocates memory only once

Employees(int i, int s){
id=i;
salary=s;
}
void display() {
System.out.println(id+" "+salary+" "+company);
}
}
public class StaticKey {
public static void main(String args[]) {
Employees e1=new Employees(25, 25000);
Employees e2=new Employees(30, 3000);
e1.display();
e2.display();
}
} 
			||
		\/	Output
	25 25000 SRT Traders
	30 3000 SRT Traders

												Static Varaiable
|				|				   |				  |  			[ Company="SRT Traders" ]
|				|	/--------------|----|id=25		 ||----------------------------/	
|				|  /			   |	|salary=25000|| 						  /
|				| /				   |				  |	    					 /
|			  e1|/				   |	|id=30		 || 						/
|			  e2|------------------|----|salary=3000 ||------------------------/
Stack Memory 					Heap Memory
In this example, two objects are created. Two object references allocate memory in the Stack. 
But as the company variable is static, memory is allocated only once for it

Example:2
class Employees{
int id;
int salary;
static String company="SRT Traders";   

static void check(){  -->A static method can be invoked without the need for creating instance of a class
company="WIIT";
} 

Employees(int i, int s){
id=i;
salary=s;
}
void display() {
System.out.println(id+" "+salary+" "+company);
}
}
public class StaticKey {
public static void main(String args[]) {
Employees.check();
Employees e1=new Employees(25, 25000);
Employees e2=new Employees(30, 3000);
e1.display();
e2.display();
}
} 
			||
		\/	Output
	25 25000 WIIT
	30 3000 WIIT
	
	
	JAVA THIS KEYWORD
The this keyword is used as reference variable to the current object
1.this can be used to invoke current class method
2.this() can be used to invoke current class constructor
3.This can be passed as an argument in the constructor call
4.this can be passed as an argument in the method call.
The this keyword is mainly used to refer current class instance variable and it 
can also be used to return the current class instance from the method. 

Example :1

class ClassInfo{
int rollno;
String name;
ClassInfo(int rollno,String name){
this.rollno=rollno;
this.name=name;
}
void display() {
System.out.println(rollno+" "+name);
}
}
public class ThisDemo {
public static void main(String args[]) {
ClassInfo c1=new ClassInfo(10, "John");
ClassInfo c2=new ClassInfo(12,"Annie");
c1.display();
c2.display();
}
}
			||
		\/	Output
	10 John
	12 Annie	
If local variables and instance variables are different, there is no need to use 
this keyword

EXAMPLE:2 BELOW CODE

*/
class Message{
	Message(){   //-->1,2
		this("Annie"); //-->3,4
		System.out.println("Welcome to Edureka");//-->4
	}
	Message(String n){ //-->3
		System.out.println(n);//-->3
	}						//-->3
}
public class StaticAndThisKeywords {
public static void main(String args[]) {
	Message m=new Message();  //-->1
}
}
/*Output:
 * 		Annie
		Welcome to Edureka
		
  
  1.The main() function is executed first.
  2.When an object of the class is created,a default constructor is called
  3.The this() calls the parameterized constructor from default constructor
  4.The remaining statements from default constructors gets executed.
 */
