package Basic;
import java.util.Stack;
public class Stacks {
/*
 * Stack represents a LIFO order i.e Last In First Out Order
 */
	public static void main(String args[]) {
		Stack<String> stack=new Stack<String>();
		
		stack.push("America"); //inserting elements on top of the stack
		stack.push("Germany");
		stack.push("India");
		
		System.out.println("Original Stack: "+stack);
		
		String poppedElement=stack.pop();
		System.out.println("Popped Element: "+ poppedElement);
		
		System.out.println("Now the stack looks like: "+stack);
		
		String poppedElement1=stack.peek();
		System.out.println("Top Element: "+ poppedElement1);
		
		System.out.println("Now the stack looks like: "+stack);
	}
}
