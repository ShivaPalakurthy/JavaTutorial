package Basic;

public class PrimitiveDatatypes {
			public static void main(String args[]) {
				char a='A';
				byte b=2;
				short c=22;
				int d=45;
				float e=5.123451f; //you have to write f at the end ->Type mismatch: cannot convert from double to float
				double f=4.68295233535d; //you have to write d at the end
				boolean g=true;
				
				System.out.println("char: "+a);
				System.out.println("byte: "+b);
				System.out.println("short: "+c);
				System.out.println("int: "+d);
				System.out.println("float: "+e);
				System.out.println("double: "+f);
				System.out.println("boolean: "+g);
				
			}
}
/*
 *  DataTypes:Each variable in java has a specific type which determines the size of memory,
 *  the range of the values that can be stores & the set of operations that can be applied
 *  to the variable.
 *  
 *  	DataTypes are of two types:
 *  1.Primitive:-datatype which predefined by the language 
 *  	.byte-number		  ->1 bytes=> -128 to 127
 *  	.short-number		  ->2 bytes=> -32768 to 32767
 *  	.int-number			  ->4 bytes=> -2147483648 to 2147483647
 *  	.long-number		  ->8 bytes=> -9223372036854775808 to 9223372036854775807
 *  	.float-float number	  ->4 bytes=> +- 3.40282347E+38F
 *  	.double-float number  ->8 bytes=> +-1.79769313486231570E+308
 *  	.char-a character     ->2 bytes=> +-0 to 65.536
 *  	.boolean-true or false->1 bit=>   true or false
 *  		Syntax: int num=70;
 *  The equation used to find the range of values that can be stored in a variable is 
 *  -2^(n-1) to 2^(n-1) -1   where n is number of bits
 *  
 *  
 *  2.Non-primitive/reference:Reference variables are created using defined constructors of the class
 *  			These variables are declared to be of a specific type that cannot be changed.
 *  			Objects of various classes Strings & Arrays come under reference dataype
 *  			Reference variable holds bits that represents a way to access an object
 *  			It doesnt hold the object itself, but it holds a reference address to the object
 *  			Refeernce type doesn't have a size or bit range
 *  			eg. String str="Edureka"
 *  				here str is reference
 *  		SYntax: Stundent s1=new Student();
 */
