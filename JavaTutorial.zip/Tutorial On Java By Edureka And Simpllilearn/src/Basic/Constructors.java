package Basic;

public class Constructors {
/*
 * 
 							WHAT IS A CONSTRUCTOR?
   1.Constructor is used in the creation of an object
   2.It is the block of code used to initialize an object
   3.Constructor must have the same name as the class it is in and it does not have
    any return type
   4.Constructor gets executed when an object of a class is being created
   5.Constructors are of two types (a) default constructor (b) parameterized constructor
   
   
   					DIFFERENCE BETWEEN CONSTRUCTOR AND METHOD
   
   			Constructor						|				Method
   1.Constructor must not have return type	| 1.Method must have return type
   2.Constructor name must be same as the	| 2.Method name must not be same as the class
    class name    							|  name
   3.Constructor is used to initialize the	| 3.Method is used to expose the behaviour of 
    state of an object						|	an object
   4.Constructor is invoked implicitly		| 4.Method is not invoked implicitly
   
   
   								HOW DOES CONSTRUCTOR WORK?
   The moment object of a class is created, the constructor of the class is called which
    initializes the class attributes
    
    			new						
    Class------------------------>Object------------------------------->Constructor
    												default
    												
    								
    							TYPES OF CONSTRUCTORS
    1.Default Constructor: The constructor which is created by the compiler without having 
    any parameters
    2.Parameterized Constructor: The constructor which has a specific number of parameters,
     called as Parameterized Constructor
     
     
   1.Default Constructor:
   			The default constructor is used to provide the default values to the object
   			 like 0, NULL depending on type
   	  
   	  
   	  
   	  class StudentInfo{
   	  			int roll;
				String name;
	  void display() {
	  			System.out.println(roll+" "+name);
	  			}
   	  }
   	  public class DefaultConstruct {
   	  public static void main(String[] args) {
   	  			StudentInfo s1=new StudentInfo();
   	  			StudentInfo s2=new StudentInfo();
   	  			 s1.display();
   	  			 s2.display();
   	  }	
   	  }
 					  				||
									\/	Output
							       0 null
							       0 null
							       
							       
   2.Parameterized Constructor:
   The parameterized constructor is used to provide different values to the objects
   
   
   class Employee{ 
   	int id;
    String name;
   Employee(int i, String n){
   id=i;
   name=n;
   }
   void display() { 
   System.out.println(id+" "+name);
   }
   }
   public class ParameterizedConstr{
   public static void main(String[] args) {
   Employee e1=new Employee (2, "Alex");
   Employee e2=new Employee (10, "Annie");
   e1.display();
   e2.display();
   }
   }
 					  				||
									\/	Output
								  2 Alex
								  10 Annie
								  
								  
							CONSTRUCTOR OVERLOADING
   1.Constructor Overloading is just like Method Overloading without return type
   2.Constructor Overloading in Java is a technique of having more than one constructor
    with different parameter list
    
   class Shop {
    int itemid;
    int price;
    String name;
    
    Shop(int a,int b){
  	  itemid=a;
  	  price=b;
  	  name="XYZ";
  	  System.out.println(itemid+" "+price+" "+name);
    }
    Shop(int i,int p,String n){
  	  itemid=i;
  	  price=p;
  	  name=n;
  	  System.out.println(itemid+" "+price+" "+name);
    }
}

public class OverloadConstr {
	public static void main(String args[]) {
		Shop s1=new Shop(1,1000);
		Shop s2=new Shop(10,2500,"Jhon");
	}
}
 					  				||
									\/	Output
   								1 1000 XYZ
								10 2500 Jhon
								
								
						     	CONSTRUCTOR CHAINING
  1.Constructor Chaining is the process of calling one constructor from another
   constructor with respect to the current object				
  2.The real purpose of Constructor Chaining is to pass parameters through a bunch of
   different constructors, but the initialization should be done at single place
  3.Constructor Chaining can be done in two ways: 1. within same class and 2. from base class
  4.Constructor Chaining occurs through Inheritance
  
  
  class Student {
	public String sName;
	public int sMarks;
	
	//default constructor of the class
	public Student(){
		//this will call the constructor with String oaran
		this("Meghan");
	}
	public Student(String name) {
		//call the constructor with (String,int) param
		this(name,70);
	}
	public Student(String name,int marks) {
		this.sName=name;
		this.sMarks=marks;
	}
	void display() {
		System.out.println("Student Name: "+sName);
		System.out.println("Student Marks: "+sMarks);
	}
	public static void main(String args[]) {
		Student s=new Student();
		s.display();
	}
}
 					  				||
									\/	Output
							Student Name: Meghan
							Student Marks: 70	     	
 */
	
	
	
}
