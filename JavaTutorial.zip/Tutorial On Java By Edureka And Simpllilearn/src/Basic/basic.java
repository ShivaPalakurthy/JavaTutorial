package Basic;

public class basic {
/*
 * Java is first released by SUn microsystems in 1995 developed by team led by 
 * James Gosling
 * Features in Java:
 * 					1.Simple-->Its simple especially for API interface
 * 					2.HIgh Performance
 * 					3.Secure-->Java runs inside virtual machine sandbox to prevent any activity
 * 								from untrusted sources.
 * 								NO use of explicit pointers--> it wont give address of any pointer 
 * 								There is no concept of pointers in java so there is no possibility
 * 								of memory/reference leaks in java making it secure
 * 					4.Robust-->Java completely takes care of memory allocation & relasing,
 * 								which makes java more robust.(garbage collector)
 * 					5.Portable-->write once run everywhere (class file)
 * 					6.Distributed-->This feature helps to use java in handling BIG Data.
 * 								RMI(remote Method Invocation),EJB(Enetrprise java beans)etc
 * 								are used for creating ditributed applications using java
 * 								Using this a program can call a method of another program
 * 								running in some other computers in the network
 * 					7.DYnaminc
 * 					8.Multi-threaded--> Thread is a task in a process/program
 * 									Multithreading is multiple tasks running/executing at same time
 * 									This facility is provide by java so that many tasks can be 
 * 									Executed at the same time.
 * 								eg. we have multiple cores in machine like 4 core processor etc,say
 * 								you want to do addition /multiplication of two numbers so we
 * 								don't have to run everything on one core since we have 4 processor
 * 								so we can have addition run on one core/processor and multiplication
 * 								on another core/processor at the smae time ,at the same instance
 * 								we can run them as thread, we dont have to wait for another in sequential
 * 								manner when you're operating on different variables.This what multithreading
 * 								is all about. so we can have different operqations carried out on different
 * 								course in the same instance of time.
 * 					9.Object-Oriented-->Java is an object oriented programming language.
 * 										Everything is performed using "objects".Java can 
 * 										be easily extended 	since it is based on the object model
 * Java Editions:
 * 		1.J2SE->Java Standard Edition
 * 		2.J2EE->java Enterprise Edition
 * 		3.J2ME->Java Micro Edition-->used for embedded /mobile development
 * Java Virtual Machine (JVM):
 * 1.JVM is the virtual machine that runs the java bytecodes(.class files)
 * 2.The JVM doesn't understand the java Source code,that is why you comiple your
 *  *.java files to obtain *.class files that can contain the bytecodes understood by the JVM
 * 3.The same ByteCodes give the smae results makes Java a Platform Independent language
 * 		(Write once run Anywhere)
 * 																				__Windows
 * 																			   |
 *  Java Code(source code.java)-->[Java Compiler]-->[Byte code(.class)]-->JVM--|-- Ubuntu
 *  																		   |		
 *  																		   -- MAc etc
 *  
 *   JRE=JVM+Set of Libraries+other Additional files
 *   
 *   JRE(Java Runtime Environment) does not contain tools and utilites such as compilers
 *   or debuggers for the developing applets & application
 *   
 *   Java Development Kit(JDK)
 *   	JDK is the superset of the JRE, & contains everything that is in the JRE, plus tools such as the
 *   compilers & debbuggers necceessary for developing applets & applications
 *   		JDK=JRE+Development Tools
 *   		JDK=(JVM+Set of Libraries+other Additional files)+Development Tools
 *   
 *   
 *   System.out.println();-->System is a class where as out is an instance variable & println is a method with an out
 */		
	int instanceVariable=30;
	static int staticVariable=700;
	public void nonStatic() {
		System.out.println("Non static method should be called by creating objects");
	}
	
	public static void Static() {
		System.out.println("Static methods can be directly called without creating objects");
	}
	
	public static void main(String args[]) {
		basic obj=new basic();
		System.out.println("Adapt.Improvise.Overcome");
		Static();
		//nonStatic();5
		obj.nonStatic();
		basic obj1=new basic();
		System.out.println(obj.instanceVariable);
		obj.instanceVariable=50;
		System.out.println(obj.instanceVariable);
		System.out.println(obj1.instanceVariable);
		obj1.instanceVariable=90;
		System.out.println(obj1.instanceVariable);
		System.out.println(obj.staticVariable);
		obj.staticVariable=711;
		System.out.println(obj.staticVariable);
		System.out.println(obj1.staticVariable); //we'll get obj value for obj1 also but for instance variables it will be separate for each object
		obj1.staticVariable=712;
		System.out.println(obj.staticVariable);
		System.out.println(obj1.staticVariable);
		basic.staticVariable=900; //we can chane the static value by class name also but we can't chance instance variable by class name
	//	basic.instanceVariable=900;//Cannot make a static reference to the non-static field basic.instanceVariabl
		System.out.println(obj.staticVariable);
		System.out.println(obj1.staticVariable);
		
	}
	
	/*3
	 * public static void main(String args[]){}
	 * 
	 * Public->visible to every one
	 * class-->class is a keyword to declare class in javaa
	 * void->void is th ereturn type of the method.It means it doesn't return any value.
	 * Static->is a keyword, if we declare in any method as static, it is known as static
	 * 			method.The core advantage of static method is that there is no need to create
	 *			object to invoke the static method
	 *String args[]->is used for command line argument
	 *main->represents the startup of the program
	 * System.out.println();-->System is a class where as out is an instance variable & println is a method with an out
	 *	Modifiers are of two typess:1.Acess Modifier
	 *								2.Non-Acess Modifier
	 *1.Acess Control Modifiers:
	 *						i.default->visible to the package
	 *						ii.Private->visible to the class only
	 *						iii.Public->visible to the world
	 *						iv.Protected->visible to the package & all subclases
	 *2.Non Access Modifiers:
	 *					i.static->for calling methods & variables without an object 
	 *								to which it belongs
	 *					ii.final->for finalizing the implementations of classes,methods,
	 *							 and variables
	 *					iii.abstract->for creating abstract classes & methods
	 *					iv.synchronized & volatile->used for threads
	 *							when we use Synchronized, it means only one thread can access at a point 
	 *any other thread has to wait.
	 *							when we use volatile is basically for memory visibility
	 *									
	 * Variables: 1.Local->scope remains to the method ,once cursor moves out of the method,jVm will 
	 * 						use garbage collector to errase it
	 * 			  2.Instance->something that is defined at the instance level.we can change the value
	 * 						for each object as they are non-static
	 * 			  3.Class/Static-->One for calss.if changed for one object the value gets changes for 
	 * 							other object also. can be updated by using class name like
	 * 							 basic.staticVariable=900;  but we can't update instance variable with 
	 * 					class name .basic.instanceVariable=900-->we can't do this
	 * 
	 * 
	 * Types of Variables:
	 * 1.Local: Local variables are declared in methods, constructors or blocks
	 * 			Local variables are created when execution enters a method,constructor or block
	 * 			Access modifiers cannot be used for local variables
	 * 			Local Variables are visible only with in  the declared method,constructor or block
	 * 			Local Variables are implemented at stack level internally
	 * 			There is no default value for local variables, so local variables should be 
	 * 			Declared & an initial value should be assigned before the first use.
	 * 2.Instance:Instance Variables are declared in a class.
	 * 			 When a space is allocated for an object in the heap,a slot for each instance variable
	 * 			value is created.
	 * 			Instance variables are created when an object is created with the use of keyword 'new'
	 * 			& destroyed when the object is destroyed.
	 * 			Access modifiers can be given for instance variables,
	 * 			The instance variables are visible for all methods,constructors & block in the class
	 * 			Instance Variables have default values.FOr numbers,the default value is 0,for Boolean is
	 * 			false,for object reference it is null.
	 * 			Values can be assigned during the declaration or withing the constructor.
	 * 			Instacne variables can be accessed directly by calling the variable name inside the class.However
	 * 			within static methods(when Instance varibales are given accessibility),they should be called using 
	 * 			the fully qualified name 
	 * 							ObjectReference.VariableName
	 * 3.Class/Static:Class Variables are declared with the static keyword inside a class,but it is created outside
	 * 			a method,constructor or a block.
	 * 			Class Variable are declared as constants i.e variables never changer from their initial value
	 * 			Static Variables are stored in the static memory
	 * 			It is rare to use static variables other than declared final & uased as either public or private
	 * 			constants.
	 * 			Static Variables are created when the program starts & destroyed when the program stops
	 * 			Static Variables are declared public since they must be available for users of the class
	 * 			Stativa Variables can be accessed by calling with the class name
	 * 					like--- ClassName.VariableName
	 */
}
