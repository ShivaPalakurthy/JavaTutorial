package Basic;

class OuterClass{
	static int outerstaticMember=10;
	
	 int instanceMember=20;
	
	private static int outerPrivateMember=30;
	
	
	static class StaticNestedClass{
		void display() {
			System.out.println("Static member of outer class = "+outerstaticMember);
			
			System.out.println("private static member of outer calss = "+ outerPrivateMember);
			
	//		System.out.println("Non static member of outer class = "+instanceMember); -->u canot access non static member in static class
 		}
	}
}
public class StaticNestedClassDemo {
	 public static void main(String args[]) {
		//accessing a static nested class
	OuterClass.StaticNestedClass nestedObject=new OuterClass.StaticNestedClass();
	
	nestedObject.display();
	 }
}
