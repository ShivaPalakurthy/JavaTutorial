package Basic;

public class CollectionsInJava {
/*
 * Interface is a generic blueprint of specific class implementation.
 * Abstract class are similar to Interfaces where they provide us a generalisation but also
 * provide a way to write concrete implementation
 * 
 * 
 * sign representation :i.Interface is writen in ()brackets
 * 					   ii.Abstract class is written in [] brackets
 * 					   iii.Classes are written in {}brackets.
 * 
 * 
 			 					-----<---(Set)<--------<--(SortedSet)<--------(NavigableSet)<---------------{TreeSet}
 			 					|				  |												  |
 			 					|				  ----<--[AbstractSet]<------------------------------
 			 					|--<-----(List)<---------[AbstractList]<------<-[AbstractSequentialList]<--------{LinkeList}
 			 					|								 						|
 			 					|								 						|----<----{Arraylist}
 			 					|								 						|
 			 					|								 						|
 			 					|								  						-------<--{Vector}<----{Stack}
 			 					|					 ---<--[AbstractQueue]
 			 					|					 |
 (Iterable)<---<(Collection)<---|---<----(Queue)<----------(Deque)<-----------------------------------------------------------{LinkedList}
 			 					|																					      |
 			 					|								 -----<--[AbstractSet]<---{TreeSet}						  |
 			 					|								 |													      |
 			 					|								 |----<--[AbstractList]<------<-[AbstractSequentialList]<-|
 			 					|								 |						|
 			 					|								 |						|----<----{Arraylist}
 			 					|								 |						|
 			 					|								 |						|
 			 					|								 |						-------<--{Vector}<----{Stack}
 			 					----<----[Abstract Collection]<--------[AbstractQueue]<-------------------{PriorityQueue}


Here:
   ABstractSet points for both Set& AbstractCollection
   AbstractList points for both List & AbstractCollection
   AbstractQueue points for both Queue & AbstractCollection
   TreeSet points for both NavigationSet & AbstractSet
   LinkedSet  points for both Deque & AbstractSequentialList
   Both ArrayList & Vector points & AbstractSrquentialList points for AbstractList.
   
   
Interface:-AN interface is a generic blueprint of specific class implementation.
Abstract Class:Similar to interfaces but also provides a way to write concreate implementation.

  Set:Every element present in the set must be unique ,it wont contain any duplicate element
  List:It is the most linient representation of collection ,it'll store duplicate values,
  		List is basically a index based collection
  Queue:Works with the concept of FIFO. FIFO order is implemented in collection by queue
  Deque:Element can be added & removed from two ways.
   Hashset:stores unique elements without any order.Hashset will not remember /follow the
           order of how elements are inserted to it.The order in which elements are 
           accessed & printed will be different.
   PriorityQueue:we use PriorityQueue when we require FIFO arrangement but at the same time,
   		   there are few elements in the queue which cannot wait to be executed or processed
   		   when there term comes, they want to be executed on priority.
   		   So whenever we want to maintain a FIFO fashion collection, but at the same time
   		   you also want to allow few elements of it to override the fifo arrangement & get
   		   processed ahead.
   Stack: Follows LIFO order
   Vectors : Vectors are very similar to lists , the only one major difference is Vectors 
   			are thread safe while Lists are not thread safe.whenever we have a program,in
   			which we want to access the collection in a thread safe manner where two threads
   			cannot modify the same element at the same time ,then we'll use vectors.
   
   
 * 
 *
 */
}
