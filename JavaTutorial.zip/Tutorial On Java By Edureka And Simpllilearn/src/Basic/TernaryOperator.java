package Basic;

public class TernaryOperator {
/*
 * Can be used only if we have one statement to execute in if block & one statement to
 * execute in else block
 */
	public static void main(String args[]) {
		int a=1;
		int b=2;
		int result;
		result=a<b?a:b;   //here in a:b--> if condition is true a gets executed if condition is false b gets executed
		System.out.println(result);
	}
}
