package Basic;

public class DataTypeConversions {
/*
 * DataType of a particular variable can be converted to other datatypes
 * Need of Type Conversions:
 * 		eg: int a=100;   //Initialised a variable with type integer
 * 			String b ="hello";  //Initialised a variable with type String
 * 			String s=a+b;  //s="100hell0"
 * Here, The datatypes of both the variables are different
 * But to perform any operation we need both the varibales to be of the same datatype
 * so here Integer value is converted to String & gets concatenated with other String 				
 * 
 * There are 2 ways in which we can perform Datatype Conversions
 * 	1.Implicit Conversions:A value of one type is changed to a value of another type
 * 	without any special directive from the programmer
 * eg. A char can be implicitily converted to an int , a long , a float or a double
 * 				char c='a'  //c='a'
 * 				int k=c		//k=97
 * 				flaot f=c   //f=97.0
 * 				long l=c	//l=97
 * 				double d=c  //d=97.0
 * 
 * Implicit value from double to char will give an error,As big value is trying to come 
 * into small value
 * eg => char b=d
 * error: Incompatible types: possibly lossy conversion from double to char  
 * 	2.Explicit Conversions:Explicit conversions are done by Type Casting
			The type to which you want a value converted is given in parentheses,
			 in front of the current value of that
			Casting can be used to convert among any of the primitive types except boolean
			For example: The following code casts a value of type double to a value of type int
  example:double d=45d //d ==> 45.0
			 int i=d
	Error: incompatible types: possible lossy conversion from double to int int i=d;
	mplicit Conversion from double to int will give an error

  so we'll write as
  double d=45d // d ==> 45.0
 	int i=(int)d // i ==> 45
	Explicit Conversion will execute and convert double to int without an error
Note: Casting may lose information
For Example: floating-point values are truncated when they are cast to integers
(e.g. the value of d i.e. 45.5, when converted to int gives the value 45)
i.e	`	double d=45.5; // d ==> 45.5
 		int i= (int)d; //i ==> 45
 		.5 value got truncated

 * byte--->Short--->int--->long--->float--->double
 * 
 * char<--->int
 * 
 * Note:1.The arrow in the diagram shows the possible Implicit Type casting that are 
 * permissible betweeen Primitive DataTypes
 * 2.As the diagram shows int can be converted implicitly to Long,float ,double.
 * 3.For vice versa, they have to be converted explicitly.
 
  Type Conversion - Methods
  1.String to int: Integer.parseInt() -eg. String s="23";  // s ==>"23
  										 int num=Integer.parseInt(s);  // num ==> 23
  2.String into Integer: Integer.valueOf() eg:  String s="2333"; //s ==>"2333"
  											Integer num-Integer.valueOf(s); // num => 2333
 
  3.int to String Integer.toString()  e.g: int i=23; //i ==> 23 
  						or				String s=Integer.toString(i); //s==>"23"
  			String.valueOf() 			String s2=String.valueOf(i);  // s2 ==>"23"
  			
  
  
 */	
}
