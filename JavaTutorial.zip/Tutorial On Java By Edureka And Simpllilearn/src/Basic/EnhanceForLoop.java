package Basic;
/*
 * we use Enhanced FOr Loops for scenarios when ever we have to iterate over collection 
 * of items &array of items
 */
public class EnhanceForLoop {
	public static void main(String args[]) {
		int[] numbers= {1,2,3,4,5,6,7,8,9,10};
		
		for(int item:numbers) {
			System.out.print("Count is: "+numbers); //when you directly call numbers it'll given addreesss
			System.out.println(" count is: "+item);
		}
	}
}
