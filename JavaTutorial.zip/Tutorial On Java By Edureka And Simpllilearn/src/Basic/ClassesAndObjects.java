package Basic;

public class ClassesAndObjects {
/*
 * 				Let's Understand Classes And Objects
 	Java is an Object Oriented and Class based programming language
 	A class is a blue print of an object. object is the instance of the class
 	
 							Dialing/Phonecall <--Class
 							  |
 		-----------------------------------------------
 		|					  |						  |
 	Rotary Phone		Touch Tone Phone		Cellular Phone 		<---Objects
 	
 	A Class is a blueprint which includes all the data. It describes the state and
    behaviour of a specific object
 	An Object is an instance of class which contains variables and methods
 	In this given example, phone is a Class and Rotary Phone, Touch Tone Phone and 
 	Cellular Phone are the Objects of the Class
 	
 	Attributes
 		In computing, an attribute is a specification that defines a property of an 
 		object, element, or file. It may also refer to or set the specific value for
 		a given instance of such.
 		
 	    	Class										Object
 		   Student---------------------------->Student	s=new Student();
 		ID
 		First-name
 		Last-name 
 		Address
 		Contact Number 
 		Grade
 						There are two types of Attributes:
 								Built-in Class Attributes
 								Attributes defined by Users
 								
 								
 								
 								JAVA NAMING CONVENTIONS:
 	1.Class Name: It should start with uppercase letter and it should be a noun.
	2.Interface Name: It should start with uppercase letter and it should be an adjective
 	3.Method Name: It should start with lowercase letter and it should be a verb
 	4.Variable Name: It should start with lowercase letter
 	5.Constant Name: It should start with uppercase letter.
 		
 		
 								TYPES OF VARIABLES
 	1.Local Variables:Local variables are declared within the method of a class
 	2.Instance variables:Instance variable are declared in a class but outside a
 	 					method, constructor or any block.
 	3.Class Variables:Class / static variable has only one copy that is shared by 
 					  all the different objects of a class
 					  
 					  
 					  			DEMO-CLASS AND OBJECTS
 	class Demo{									line 56-61-->class
 	void printMessage()							line 57-60-->Method inside a class
 	{
 		System.out.println("Welcome to the Class");
 	}
 	} 	
 	public class DefClass{
 	public static void main(String[] args) {
 	Demo d=new Demo(); 							line 64--->Creating object of a class
 	d.printMessage();
 	}
 	}				
 					  				||
									\/	Output
							Welcome to the Class
							
							
							
	We can have nested classes as well.eg: kitchen class inside home class
	Nested classes are of two types: i.static nested classes
									 ii.non-static nested classes
	i.Static Nested classes: classes that are declared as static are called static nested classes
	ii.Non-static classes are called inner classes.
	
	WHy we use nested classes?
		1.It is a way of logically grouping classes that are only used in one place.
		2.It increases encapsulation
		3.It can lead to more readable & maintainable code.
 */
}
