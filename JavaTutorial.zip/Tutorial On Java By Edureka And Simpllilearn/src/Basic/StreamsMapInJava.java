package Basic;

public class StreamsMapInJava {
/*
 Streams concept is introduced in Java 8, the reason java introduced the concept of jdk is
 to promote the functional programming paradime.The main function of streams is to help
 us to iterate & manipulate collections.Streams provide a better & optimised way to 
 manipulate,iterate over collections & also change the representation of collection types
 
 Streams can be understand with the concept of youtube streaming, if you want to watch a
 video of 100mb , it won't download 100mb as you stream that video so it will download
 5mb at a time & keeps updtaing as time passes
 */
}
