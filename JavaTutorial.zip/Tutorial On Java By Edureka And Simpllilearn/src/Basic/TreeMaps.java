package Basic;
import java.util.TreeMap;
public class TreeMaps {
/*
 * The main property of the treemap is that we you enter elements into the map then 
 * they naturally be sorted /ordered
 */
	public static void main(String args[]) {
		TreeMap<Integer, String> treemap=new TreeMap<Integer, String>();
		
		treemap.put(3, "A");  //(Key,Value)
		treemap.put(2, "B");
		treemap.put(1, "C");
		
		System.out.println(treemap);
	}
}
