package Basic;

public class ConstructorExampleCuboid{
	int width;
	int height;
	int depth;
	
	ConstructorExampleCuboid(int width,int height,int depth){  //-->When user wants to have all the variable values
		this.width=width; //since both have same name this.width will point to class width where as width will be COnstructor parameter
		this.height=height;
		this.depth=depth;
	}
	ConstructorExampleCuboid(int width,int height ){	//when user want depth as a fixed value
		this.width=width;    
		this.height=height;
		this.depth=10;
	}
	
	ConstructorExampleCuboid(int dimension){		//when user wants to give height ,width & legnth the same values
		width=dimension;
		height=dimension;
		depth=dimension;
	}
	
	ConstructorExampleCuboid(){			//when user wants to give a constant value to all the height width & length2
		this.width=10;
		this.height=10;
		this.depth=10;
	}
	
	int volume() {
		return width*height*depth;
	}
	public static void main(String args[]) {
		int volume;
		
		ConstructorExampleCuboid stdCuboid=new ConstructorExampleCuboid(10,20,15);
		volume=stdCuboid.volume();
		System.out.println("Volume of a Simple Cuboid is :" +volume);
		
		ConstructorExampleCuboid cuboidWithDefaults=new ConstructorExampleCuboid(10,20);
		volume=cuboidWithDefaults.volume();
		System.out.println("Volume of cuboid with default depth is: "+ volume);
		
		ConstructorExampleCuboid cube=new ConstructorExampleCuboid(10);
		volume=cube.volume();
		System.out.println("Volume of cube is: "+volume);
		
		ConstructorExampleCuboid defaultCuboid=new ConstructorExampleCuboid();
		volume=defaultCuboid.volume();
		System.out.println("Volume of the defaultCuboid is: "+ volume);
		
	}
}
