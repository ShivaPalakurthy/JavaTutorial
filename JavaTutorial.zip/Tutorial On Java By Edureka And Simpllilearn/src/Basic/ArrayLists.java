package Basic;
import java.util.*;

public class ArrayLists {
/*
 * Arraylist is an array based implementation of list. It is an index based implemntation
 * by default it is not thread safe, if two threads try to access the same collection at the 
 * same time/modify the same collection we get inconsistence behaviour.
 */
	
	public static void main(String args[]) {
		List<Integer> arrayList1=new ArrayList<>();

		/*
		 * List<Integer> arrayList1=new ArrayList<Integer>(); //-> for import java.util.*;
		 * 					or
		 * List<Integer> arrayList1=new ArrayList<>(5); //->by giving the length to avoid wasting of memory
		 * 
		 * ArrayList<Integer> arrayList1=new ArrayList<>(); //->for import java.util.ArrayList;
		 * 
		 *  ArrayList<Integer> arrayList1=new ArrayList<>(5); //->for import java.util.ArrayList; & giving length
		 */
		for(int i=1;i<=5;i++) {
			arrayList1.add(i);
		}
		//Printing elements
		System.out.println(arrayList1);
		
		//Remove element at index 3
		arrayList1.remove(3);
		
		//displaying the arraylist after deletion
		System.out.println(arrayList1);
		
		//Printing elements one by one
		for(int i=0;i<arrayList1.size();i++) {
			System.out.print(arrayList1.get(i)+" ");
		}
		System.out.println();
		
		//for enhanced loop
		for(int i:arrayList1) {
			System.out.println(i);
		}
	}
}
