package Basic;
import java.util.TreeSet;
public class TreeSets {
/*
 * TreeSet:Main reason is to keep the natural ordering of the elements & it only stores
 * unique value, it is not synchronised so it's not thread safe.
 */ public static void main(String[] args) {
	TreeSet<String> treeset=new TreeSet<String>();
	
	treeset.add("B");  /* Even though B is added first output will be [A, B, C] as
						treeset follow natural ordering of elements.
	 					*/
	treeset.add("A");
	treeset.add("C");
	treeset.add("C");
	
	//REMOVE ,CONTAINS ALL OTHER FUCNTIONS ARE THERE IN TREESET ASWELL
	System.out.println(treeset);
}
}
