package Basic;

public class OperatorsAndControlStatementsAndMethodsInJava {
/*
 * 		Operator Type				Category						Precedence
 * 		Unary						postfix							expr++, expr--
 * 		Unary						prefix							++expr, --expr, +expr, -expr, ~, !
 * 		Arithmetic					multiplicative					*, /, %
 * 		Arithmetic					additive						+,-
 * 		Shift						shift							<<, >>, >>>
 * 		Relational					comparison						<, >, <=,>=, instanceof
 * 		Relational					equality						==,!=
 * 		Bitwise						bitwise AND						&
 * 									bitwise exclusive OR			^
 * 									bitwise inclusive OR			|
 * 		Logical						logical AND						&&
 * 									logical OR						||
 * 		Ternary						ternary							?:
 * 		Assignment					assignment						=,+=,-=,*=,/=,%=, &=, ^=, |=, <<=,
																	>>=,>>>=
															
1.Unary Operators: i. int x=10; //x ==> 10
					x++;
					x;  //x ==> 11
					Post increment changes the value for the next time the variable is used
		ii.Pre-decrement changes the value for the current time the variable is used
				 int a=10; // a ==> 10
				 --a;
				 a;  //a ==> 9
		iii.The ! Operator changes the value from true to false
				boolean a=true;  // a ==> true
				 boolean d=!a; // d ==> false
				 d;   // d ==> false
2.Arithmetic Operators:  int b=20;
						 int d=30;
						 c=b+d;  //c=50
						 e=b*d;	 //e=600
						 f=d/b;  //f=1
						 g=d%b;	//g=10
3.Shift Operators: int a=20;
					a<<2; //80
					 a>>3;//2
					 Left shift Solution: 20" 2^2=20*4=80
					  Right Shift Solution: 20*2^3=20/8=2.5
4.Relational Operators:Relational operators compares the value and returns a Boolean value
5.Assignment Operators:a=20 ;
					    b=40;
					     a+=b;//60
					     a;  //a ==> 60  a+=b=>a=a+b=>a=20+40=60
6.Ternary Operators:int ter=a<b?100:200 
				   ter => 200
			Solution: As the condition is false, ter is assigned the value which is after the ":"
7.Logical Operators: a=40;
					ter=20;
					d=10;
					b=20;
					a<b&&d<b;		// false
				    a>b&&ter<a 		//true
				  Solution:only true && true => true

						CONTROL STATEMENTS	
						  -->Selection/Decision making Statements-->if-else
						 |										 -->switch
		Control Statements- -->Iteration Statements-->for
						 |						 -->while
						 |						 -->do... while
						  -->Jump Statements-->break
						  					-->continue
						  					-->Return
1.if Statement:An if statement consists of a expression, which is checked and returns a
 Boolean value, if true will execute the statements in the if block
 Syntax:if (condition)
			{
			//statements

			}
2.if-else Statement:An if statement can be followed by an optional else statement, which
 executes when the if condition is false
 Syntax:if (condition) {
 		//statements
 		 }else{
 		 //statements
 		 }
 		  
3.Nested if-else Statement:An if statement consists of a expression, which is checked and returns a
 Boolean value, if true will execute the statements in the if block
 if (conditionl) { 
 		//statements
}else{

}
	if (condition2) {
	//statements
}

4.Switch Statement:A switch statement allows a variable to be tested for equality against a 
list of values.
Syntax:
switch (expression) { 
case valuel: //code to be executed 
			break; //optional 
case value2: //code to be executed 
			break; //optional 
 default://code to be executed if all cases are not matched
  }

Iteration Statements 
1.	 for Loop:
		There are three types of for loop in java:i.Simple For Loop
												  ii.Labeled For Loop
												  iii.For-each or Enhanced For Loop.
i.Simple for Loop:We can initialize variable, check condition (repeat if true ) and 
increment/decrement value
Syntax:for (initialization; condition; incr/decr) 
		{ //code to be executed

		}
ii.for-each Loop:It is used to traverse array or collection in java
	It is easier to use than simple for loop because we don't need to increment 
	value and use subscript notation#
Syntax: for (Type var: array) {
 
        //code to be executed

        }
iii.Labelled for Loop:We can have a label of each for loop
	It is useful if we have nested for loop so that we can break/continue a specific for loop
	Normally, break and continue keywords breaks/continues the inner most for loop only
	Syntax:labelname:
	for (initialization; condition; incr/decr)
		{

		//code to be executed

		}
	Example:aa:
			for(int i=0;i<5;i++){
			bb:
			for (int j=0;j<5;j++){
			System.out.println(j);
			break aa;
			} System.out.println(i);
			}
2. while Loop:Types Of while Loop:1.Simple while Loop
								  2.Do...while Loop
								  
i.Simple while Loop:While loop is used to iterate a part of the program several times when 
the number of iterations is not known
 The loop keeps on iterating till the condition returns a False value
 Syntax:while (condition) {
  		//code to be executed
  		 }
 ii.do...while Loop:If the number of iteration is not fixed and you must have to execute 
 		the loop at least once, a do-while loop is used 
 		The Java do-while loop is executed at least once because condition is checked after loop body
Syntax:do {
//code to be executed } while (condition);
 
 3.break Statement:The Java break is used to break loop or switch statement
  		It breaks the current flow of the program at specified condition
  		In case of inner loop it breaks only inner loop
 4.continue Statement:The Java continue statement is used to continue loop
  			It continues the current flow of the program and skips the remaining 
  			code at specified condition
 	
 								METHODS IN JAVA
 What Are Methods?
 	1.A Method has a group of statements
 	2.Re-usability of block of code minimizes redundancy
 	3.A class may have multiple methods
 	4.A method returns a null or a value using the return statement
 	
 	
 Methods - Syntax
				public int edureka(int a,int b)
				{
					System.out.println(a+" "+b);
					return a;
				}
	here:public->Modifier:- It defines the access type of the method
		edureka->Name Of Method - This is the method name
		int->Return Type - Method may return a value
		(int a,int b)->Parameter List (Optional) - The list of parameters, 
						it is the type, order, and number of parameters of a method
		Method body - The method body defines what the method does with the statements
		
What is a return statement?
		The return statement is a control flow statement that terminates the execution of
		 method and return control to its caller
		 When return type of any Method is void, then the Method does not return anything
		 eg:1.Return type is void as work() is not returning anything
		 		public static void work(){
		 		System.out.println("Edureka Welcomes you");
		 		}
		 		public static void main(String[] args) {
		 		work();
		 		}
		 	2.Return type is int, as edureka() returns i, which is of type Integer
		 		public class DemoValue{
		 			public int edureka (int a, int b) {
		 			int i=0;
		 			for (i=a; i<b; i++) {
		 			System.out.println(i);}
		 			return i;}
		 		public static void main(String[] args) {
		 			DemoValue dv=new DemoValue();
		 			int num=dv.edureka (2, 5);
		 			System.out.println(num);
		 			}}
 	Demo - Methods
 			//method demo
 			 
 			 public class Demo_Method {
 			 public int addNumbers (int x, int y) {
 			 int z=x+y;
 			 return z;
 			 }
 			 public static void main(String[] args) {
 			 demo_method b=new Demo_Method(); 
 			  int ans= b.addNumbers (3,4); 
 			  System.out.println("Addition is :"+ans);
 			  }
 			  } 
 			  Outpu: Addition is :7
 			 Steps wise functioning:
 			 1.As we start executing java code,main() function is executed first.
 			 Object of main() is created.
 			 2.Statements within main() are getting executed.As we are calling addNumber() 
 			 function, control of statement execution goes to addnumber() function
 			 3.The Statements within addNumber() function get executed and at the end
 			  control again goes to main() function
			 4.Remaining statements within main() get executed
	
	Ways Of Calling A Method:
		1.Call By Value:In the Call by Value method of passing arguments to a function copies
		 the actual value of an argument into the formal parameter of a function
		 for example:
		 public class DemoValue {
		 int data=50;
		 int operation (int data) {
		 data =data*2/6; 
		 return (data);
		 }
		 public static void main(String args[]) { 
		 DemoValue d = new DemoValue();
		  System.out.println("Before operation value of data is "+d.data);
		  d.operation (500);
		  System.out.println("After operation value of data is "+d.data);
		 }
		 }
		-->Before operation value of data is 50 After operation value of data is 50
		2.Method Overloading:A class may define multiple methods with the same name 
		and return type, but different number of arguments or arguments of different 
		data types. This is called Method Overloading
		
	//Write a program to add two numbers using a Method
 */	
	public Integer add(Integer val1,Integer val2) {  //since in java everything is seen in objects form we can write int with Integer class also
	val1=100;
		Integer result=val1+val2;
		return result;
	}
	public Integer add(Integer val1,Integer val2,Integer val3) { //calling a method by function overloading
		Integer result=val1+val2+val3;
		return result;
	}
	public static void main(String args[]) {
		OperatorsAndControlStatementsAndMethodsInJava cal=new OperatorsAndControlStatementsAndMethodsInJava();
		int arg1=10;
		int arg2=30;
		int arg3=40;
		System.out.println("Printing arg1 before passing it by value "+arg1);
		Integer result=cal.add(arg1, arg2);
		System.out.println("Printing arg1 after passing it by value to add method "+arg1); //call by value method
		System.out.println("Result of addition is " + result);
		Integer resultByUSingMethodOverloading=cal.add(arg1, arg2, arg3);
		System.out.println("Result from new Add method "+resultByUSingMethodOverloading);
	}
}
