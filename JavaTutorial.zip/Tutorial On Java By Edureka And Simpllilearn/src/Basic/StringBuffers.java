package Basic;

public class StringBuffers {
/*
 * Java StringBuffer is used to create mutable string, i.e. Memory allocated to a string
 *  is not fixed, it can change. It is Synchronous in nature i.e. Thread Safe
 *  
 *  
  			StringBuffer s=new StringBuffer("Happy Learning"); 
  			System.out.println(s);
		  			||
					\/	Output
				Happy Learning
				
				
	Demo - StringBuffer
	//Creating StringBuffer and append method 
	StringBuffer s=new StringBuffer("Welcome to edureka!");
	s.append("Happy Learning");				---->The append() method is used to concatenate the given string with an old string
	System.out.println(s);
	
	//insert method							---->The insert() method is used insert given string at given position
	s.insert(0, 'w');	
	System.out.println(s);
		  			||
					\/	Output	 
	 		Welcome to edureka!Happy Learning
		    wWelcome to edureka!Happy Learning
		    
		    
		    
		    
		    
		    
	//replace method
	StringBuffer sb=new StringBuffer("Hello"); 		Output
	sb.replace (0, 2, "hEl"); 				----------------->hElllo------->The replace() method replaces given string from the specified
	System.out.println(sb);													begin index to end index as passed to the method
  
  	//delete method 		 		 		 		Output
  	sb.delete(0, 1);		 				----------------->Elllo------->The delete() method deletes the given string from the specified 
  	System.out.println(sb);													begin index to end index
  	
  	StringBuffer s1=new StringBuffer("edureka"); 	Output
  	System.out.println(sl.reverse());		--------------->akerude------->The reverse() method reverses the given string and capacity() method 
  	System.out.println(s1.capacity());						   23			is used to find out the capacity of the StringBuffer (16+7=23)
 */
	public static void main(String args[]) {
		StringBuffer s1= new StringBuffer("Edureka"); 
		StringBuffer newstring=s1.append("!!!");
		System.out.println(newstring);
		System.out.println(newstring.reverse());

	}
}
