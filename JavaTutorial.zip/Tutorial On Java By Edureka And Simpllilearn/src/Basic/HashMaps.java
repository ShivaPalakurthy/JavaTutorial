package Basic;
import java.util.HashMap;

import java.util.Map.Entry; //-->for the last "for loop-->Entry<String,Integer>"
public class HashMaps {
 /*
  * 				Maps In Java
  *   sign representation :i.Interface is writen in ()brackets
  * 					   ii.Abstract class is written in [] brackets
  * 					   iii.Classes are written in {}brackets.
  
  
  										/------------------------------->[Dictionary]
  									   /
  									  /
  {Properties}----------->{Hashtable}--------------------------------------------------\
  																						\
  																						 \
  																						  \						
  																						   \
  {LinkedHashMap}-------->{HashMap}-------/============================>[AbstractMap]-------\======/=======>>>(Map)
  										 /														  /
  										/														 /
  									   /														/
  									  /														   /		
  						  {TreeMap}------------>[NavigableMap]--------->[SortedMap]-----------/
  						  
  						  
  Map is used to store key value kind of arrangement.The key here is always unique,but 
  the values can be duplicates.Because we want to maintain uniqueness in  the keys part, the
  keys are typically stored as set,because we know that set cannont contain duplicate.so
  the Map uses set class to store the Keys & to store the values it generally stores the
  list class
  
  HashTable is threadsafe i.e it will allow only one thread to access at a particular time
  but hashtable are slower as only one thread can access at a time.
  linkedHashMap: it basically has two properties, it has the property of hashmap where the
  				elements are stored /accessed/displayed in random order And at the sametime
  				it is also providing the linked property of the linkedlist where the
  				sequence is maintained. so if we use a LinkedHashmap we can actually get 
  				the insertion order i.e the way in which we insert the element is the way 
  				the elements are accessed.
  TreeMap:TreeMap will show the sorted arrangement but the sorted arrangement will happen
  			on the keys not on the values.
  			
  
  */
	public static void main(String args[]) {
		HashMap<String, Integer> map=new HashMap<String, Integer>();
		//        key ,Value
		
		/*
		 * Can be written as follows
		 * HashMap<String, Integer> map=new HashMap<>();
		 * Map<String, Integer> map=new HashMap<String, Integer>();  //for-->import java.util.Map;
		 * Map<String, Integer> map=new HashMap<>();
		 */
		map.put("a", 10);
		map.put("b", 20);
		map.put("c", 30);
		
		System.out.println("Size of map is: "+map.size());
		System.out.println(map);
		
		if(map.containsKey("a")) {
			Integer a=map.get("a");
			System.out.println("Value for key"+" \"a\" is :- " +a);
		}
		
		for(String key:map.keySet()) { //map.keySet()-->going to fetch all the keys in a set representation
			System.out.println("Key: "+ key+", value: " +map.get(key));
		}
		
		for(Entry<String,Integer> entry:map.entrySet()) {
			System.out.println("Key -"+entry.getKey()+",value:"+entry.getValue());
		}
	}
}
