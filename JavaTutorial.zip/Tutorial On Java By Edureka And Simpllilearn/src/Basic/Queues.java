package Basic;

import java.util.PriorityQueue;
import java.util.Queue;
public class Queues {
/*
 * It works on FIFO arrangement i.e First In First Out
 */
	public static void main(String args[]) {
		Queue<String> queue=new PriorityQueue<String>();
		
		queue.add("India"); /* output:  [America, India, Germany] technically it has
		to follow FIFO order but since its a PriorityQueue Elements are sent inside it on
		priority basis according to alphabetical order. In practical project we can create
		custom priority cases & we send according to that data.
		*/
		queue.add("Germany");
		queue.add("America");
		
		System.out.println("Original queue: "+queue);/* when you try to print a variable under
		syso its toString(); method is called internally though we need not to write toString()
		but the moment you try print values automatically its toString(); method is called. And
		the interesting part is if you call the toString() method,it will call the abstract collection
		classes toString(); method which doesnot understand sorting. so if we are working
		with priorityqueues if we just try to print the Queue you will not get the natural order, but
		if you try to add,remove , peek the elements then you'll get the natural ordering sequence
		
		*/
		
		queue.remove();
		System.out.println("Queue after removing the head element: "+queue);
		
		String head=queue.peek();
		System.out.println("HEad of the queue:" +head);
		
		head=queue.poll();
		System.out.println("removed head: "+head);
		
		System.out.println("queue now looks like this: "+queue);
	}
}
