package Basic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/*Comparators in Java:
 * we talked about comparable where we said that whenever we want to implement naturally occuring sorting order
 * where we say Collections.sort(obj). we would expect things to work.But what if you have a custom sorting
 * requirement. Let's take a hypothetical scenario where you created an application & your application has a
 * student object & you created a collection of student objects & now you have different consumer applications
 * lets say you have payroll apllicaton,attendance system,examination system,extra-ciricular activity system & all
 * of them want to get the student collection but all of them have different sorting requirements like
 * payroll wants the sorting based on the roll no. , attendance want the sorting on other mechanism,Extra circular
 * activity want sorting on other mechanism so how do you implement custom sorting or multiple sorting logics for 
 * your collection? 
 * 				That's where Comparators comes into the picture.Comparator is again an interface & this interface provides
 * you the flexbility to define your own custom sorting logic  multiple times. so we can create multiple comparator implementations
 *& each comparator implementation will focus on a particular sorting order so that's the basic need of sorting
 *
 * so when ever we want to sort some objects in an order other than natural ordering & when some objects sorting
 * won't implement comparable then we'll use comparators 
 */
 class Student1 implements Comparable<Student1>{ //This class will be same as Students class in comparable
		private int rollNumber;
		private String name;
		private int age;
		public Student1(int rollNumber, String name, int age) { 
			this.rollNumber = rollNumber;
			this.name = name;
			this.age = age;
		}
		public int getRollNumber() {
			return rollNumber;
		}
		public void setRollNumber(int rollNumber) {
			this.rollNumber = rollNumber;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		@Override					//foreign object
		public int compareTo(Student1 student) {
			// TODO Auto-generated method stub
			return this.rollNumber-student.rollNumber;//your implementation based on how you want to sort the elements here based on roll numbers 
			/*this.rollNumber-student.rollNumber;--> current object roll number minus foreign object roll no.
			 * if value is positive  then this.object is going to take priority & if result is negative then Student/foreign
			 * object comes first and current/this object comes second. if it returns Zero then both the objects are 
			 * of same priority so any one of the object can come first.
			 */
		}
 }

 //main code for comparator #custom sorting using age
 
 class AgeComparator implements Comparator<Student1>{

	
/*  //modifying this format down as per the need
	@Override
	public int compare(Student1 o1, Student1 o2) {
		// TODO Auto-generated method stub
		return 0;
	} 
	*/
	 /*  we can modify it further for clear understanding as follows
	 @Override
		public int compare(Student1 student1, Student1 student2) {
			if(student1.getAge()<student2.getAge())return-1;
			if(student1.getAge()>student1.getAge())return 1;
			else return 0;
		}
	  */
	 
	 @Override
		public int compare(Student1 student1, Student1 student2) {
		 //for ascending order
			if(student1.getAge()<student2.getAge()) {
				return-1; 			/*return-1 will maintain natural sorting /ascending sorting so if you want to change
				the sorting to descending order replace return -1 with return 1 & return 1 with return -1
				But usually logic will be whenever first object is less than second object return -1 & whenever first
				object is greater than second object return 1*/
			}
			if(student1.getAge()>student1.getAge()) {
				return 1;
			}
			else {
				return 0;
			}
			
		//	for descending order
			/*
			  if(student1.getAge()<student2.getAge()) {
				return 1; 			 
			}
			if(student1.getAge()>student1.getAge()) {
				return -1;
			}
			else {
				return 0;
			}
			 */
 }
 }
 
 
 
public class ComparatorsInJava {

	public static void main(String args[]) {
		
	
	ArrayList<Student1> list=new ArrayList<Student1>();
	 
	Student1 john=new Student1(3, "John",18);
	Student1 jane=new Student1(1, "Jane",21);
	Student1 tom=new Student1(2, "TOm",17);
	
	list.add(john);
	list.add(jane);
	list.add(tom);
	
	Collections.sort(list);
	
	System.out.println("Students after sorting: ");
	list.forEach(student->System.out.println(student.getName()));
	System.out.println();
	
	//Custom sort-1 based on age
	Collections.sort(list,new AgeComparator());
	System.out.println("Students after AGE sorting: ");
	list.forEach(student -> System.out.println(student.getName()));
	
	System.out.println();
	
	}
}
