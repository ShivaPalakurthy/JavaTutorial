package Basic;

import java.util.Objects;

/*
 * Object Class: class object is the root of class hierarchy.Every class has Object as a superclass.
 * All objects,including arrays,implement the methods of the class.
   Object is a class as well in java & it is super super class of any class we create in java
   
   equals() : equals() method indicates whether some other object is "equal to " this one.
   hashCode(): hashCode() method returns a hash code value for the object.
   
   we know hashset implements uniqueness automatically, it is because of the equals method implementation which it 
   inherits from the object class.This can be acchived to int,float ,String all the classes
   
   But what if you are trying to create a hashset of students object, then java doesn't know how to perform equality 
   on two student objects because student is a custom object & java doesn't know how to run equality. so that's where
   equals() & hashcodes comes into picture. so the contract is when ever you are trying to create your own
   custom objects & you have a need to perform equality on those objects you must override the equals method in your
   own class, if you do not override that then the  two student objects will be compared based on the reference & not based
   on the actual object values.
   whenever we are overriding equals method we have to over ride hashCode method as well, reason is because hashcode is 
   also used in certain collections
 */ 
/*
class Student{
	private int rollNumber;
	private String name;
	private String address;
	
	public Student(int rollNumber, String name, String address) {
		this.rollNumber = rollNumber;
		this.name = name;
		this.address = address;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
public class EqualsAndHashcode {
 
		public static void main(String args[]) {
			Student john=new Student(1, "John", "23 East, Calidornia");
			Student john2=new Student(1, "John", "23 East, Calidornia");
			Student john3=new Student(3, "John", "23 East, Calidornia");
			
			System.out.println(john.equals(john2));  
		} 
}
		*/
		/*
		 * we get false instead of true because the default implementation of equals is being run on comparing the student
		 * objects becuase the java still doesn't know to equate thse two objects(john,john2) we are getting false because 
		 * these two different references are pointing to two different memory locations of the objects. though there values 
		 * are same but there memory locations are different that's why we get false. That brings to hashcode contract.
		 * you need to override the hashcode aswell along with equals to make sure that our equality runs perfectly
		 */
//so let's write the code again

class Student{
	private int rollNumber;
	private String name;
	private String address;
	
	public Student(int rollNumber, String name, String address) {
		this.rollNumber = rollNumber;
		this.name = name;
		this.address = address;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		return this.rollNumber;
	}

	@Override
	public boolean equals(Object obj) {	//we'll give a foreign object
		if (this == obj) 	/*we will compare the foreign object with the current object of the student class which is this 
						so at first we nee to run this particular condition to check are these two object references 
						pointing to the same object or not?		*/ 

			return true;
		if (obj == null ||obj.getClass() != this.getClass()) //getClass() is a method which will tell us the class type here we are check is the obj class obje is of the type student or not?
			return false;
		Student student = (Student) obj; //explicit casting --> casting obj object to the Student  type
		return (student.rollNumber==this.rollNumber);//business logic--> based on which we are going to define uniquesness
		//here even if two students have same details but different roll numbers then there are two different objects in this case & if two
		//two objects have same roll no: even though they have different name & address we gonna say these two objects are duplicate in this object
	}
	
	
}
public class EqualsAndHashcode {
 
		public static void main(String args[]) {
			Student john=new Student(1, "John", "23 East, Calidornia");
			Student john2=new Student(1, "John", "23 East, Calidornia");
			Student john4=new Student(1, "John1", "231 East, Calidornia");
			Student john3=new Student(3, "John", "23 East, Calidornia");
			
			System.out.println(john.equals(john2));  
			System.out.println(john.equals(john4));
		} 
}
//learn about hashcode aswell
