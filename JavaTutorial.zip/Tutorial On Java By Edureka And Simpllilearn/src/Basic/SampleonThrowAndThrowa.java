package Basic;

public class SampleonThrowAndThrowa {
	/*public	int area(int a,int b) throws ArithmeticException{
	 if(b<=0) {
		 throw new ArithmeticException("GOt it b is equal to zero");
	 } 
			return a/b;
		
	}
	  public static void validate(int age) {  
	        if(age<18) {  
	            //throw Arithmetic exception if not eligible to vote  
	            throw new ArithmeticException("Person is not eligible to vote");    
	        }  
	        else {  
	            System.out.println("Person is eligible to vote!!");  
	        }  
	    }  
	
		public static void main (String args[]) {
			
			SampleonThrowAndThrowa obj=new SampleonThrowAndThrowa();
			try{			
			 
			obj.area(10, 0);
			
			}
			catch(Exception e){
				System.out.println("Arithemeic exoression for area ");
			}
			 
			try{			
				validate(13);
				 
				
				}
				catch(Exception e){
					System.out.println("Arithemeic exoression for validate ");
				}
				 
			System.out.println("rest of the code");
		} */
	 public static void checkNum(int num) {  
	        if (num < 1) {  
	            throw new ArithmeticException("\nNumber is negative, cannot calculate square");  
	        }  
	        else {  
	            System.out.println("Square of " + num + " is " + (num*num));  
	        }  
	    }  
	    //main method  
	    public static void main(String[] args) {  
	            SampleonThrowAndThrowa obj = new SampleonThrowAndThrowa();  
	            obj.checkNum(-3);  
	            System.out.println("Rest of the code..");  
	    }  
} 
