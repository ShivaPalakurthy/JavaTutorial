package Basic;

public class Arrays {
/*
 * Arrays:Arrays are used to solve the problem of storing multiple elements of the same Data Type
 *		An Array is a group of like-typed variables, that are referred to by a common name
 *		Specific element in an array is accessed by it's index
 *		Array size is fixed and can not be changed
 
 Here, Arrays will be used to store marks of 4 subjects of a student
 
 						[ 80 | 60 | 70 | 80 ]--->Values of elements
 Every Array starts-->	[  0 |  1 |  2 |  3 ] <---Index of elements
 						---------------------
 								|
 				The elements from array can be accessed using their respective index
 
 Array Declaration:Arrays are created either using the new operator or by array initializer
 			1.new operator
 			int [] a= new int[5];
 			2.array initializer
 			int[] a = {2,4,6,8,10};
 	-->	If the user tries to access index 5 then Java throws ArrayIndexOutOfBoundsException.
 	 That means Java says I do not understand beyond the index 4
   Different ways of declaring Arrays: 1.int a[]=new int[10];
   									   2.int []b=new int[5];
   									   3.int c[]= {1,2,3,4,5};
   									   4.int []d-new int[] {1,2,3,4,5};
  
    -->The length of an array is set, when it is declared
    -->When an array is declared, array index gets initialized
    -->In the following example, we have declared an array. We can check the length of any 
    array using length function
    			int x[]=new int [20]; 
    			System.out.println (x.length);  //Output-->20
  
  Types Of Arrays:
  1.Single Dimensional Array:
   				int[] a = {2,4,6,8,10};
   								|
   								|output
   								|
   						[  2 |  4 |  6 |  8 |  10] <--value
   						[a[0]|a[1]|a[2]|a[3]|a[4]] <--index
   						
   		In this example, we are going to print element present at given index value
   					int[] a ={2,4,6,8,10};
   					System.out.println (a [2]);  //6 is the output
   2.Multi Dimensional Array:
    			int[][] a = new int[5][5];
    					   a [1] [3]
    					   	  |	  |
X value indicates Row number--	   --Y value indicates Column number
				
							Value of Y increases==>
						a[0][0] a[0][1] a[0][2] a[0][3] a[0][4] 
		value of X		a[1][0] a[1][1] a[1][2] a[1][3] a[1][4] 
		increase ||		a[2][0] a[2][1] a[2][2] a[2][3] a[2][4]  
				 ||		a[3][0] a[3][1] a[3][2] a[3][3] a[3][4] 
				 \/		a[4][0] a[4][1] a[4][2] a[4][3] a[4][4]   
				 
Memory Allocation In Arrays:
		Single Dimensional Array		 ||			Multi Dimensional Array
		int[] a new int[5];				 ||  		int[][] a = new int[5][5];
	As we know, integer value requires   ||			Total number of elements in given
	4 Bytes to allocate a variable in	 ||			Multi Dimensional Array= 5*5=25.
	memory. So, to allocate an array 	 ||			 So, 25*4=100 Bytes are required
	 of 5 elements in memory 4*5=20		 ||			to allocate these elements  in memory.
	  Bytes are required
	  
Demo - Arrays:
1.1. We have an array of 5 elements ({2,4,6,8,10}). Write a program to access
 element at a specific index
 1.2. We have multi-dimensional array. Write a code to find the length of row 0
 
 		public class Array_Demo {
 		public static void main(String[] args) {
 		int[] a = {2,4,6,8,10};
 		for (int i=0;i<5; i++) {
 		System.out.println(a[i]);			//code fir 1.1
 		}
 		int[][] b = {
 					{1, 2, 3, 4},
 					{3, 6, 9}
 					 };						//code for 1.2
 		System.out.println("Length of row 1:" + b[0].Length);
 		}
 		}
 		
 		Output: 2
 		 		4
 		 		6
 		 		8
 		 		10
 		 		Length of row 1:4
 */	
	
	public static void main(String args[]) {
		int[] arrayOfIntegers=new int[] {5,6,7};
		int[] array= {2,4,6,8,10};
		//3*2
		int[][] multidimensionalArray= {
				{1,2},{3,4},{5,6}
		};
		System.out.println(array[0]);
		System.out.println(array[1]);
		System.out.println(array[4]);
		System.out.println("size of first array in multidimensional array "+multidimensionalArray[0].length);
		System.out.println(array[5]); /* Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 
		Index 5 out of bounds for length 5 at Basic.Arrays.main(Arrays.java:83)*/
		
	}
	
	/*
	 * 2.Demo
	 * Create an array having many characters. Write a program to copy elements from created array to another 
	 * array and also write a program to delete an element from an array
	 * 
	 * 
	 * we'll do it by copying all the elements from one aray to another array by removing the element we want by
	 * flaging 
	    public class Demo_2 {
	    public static void main(String[] args) {
	    //Creating array of characters
	     char[] source = {'H', 'A', 'P', 'P', 'Y', 'L', 'E', 'A', 'R', 'N', 'I', 'N', 'G'}; 
	     char[] destination = new char[7];
	     
	   	//Copying elements from one array to another 
	   	 System.arraycopy(source, 0, destination, 1, 5);
	   	 System.out.println(new String(destination));
	   	 
	   	 //Deleting element from array
	   	  int flag=3; //element to be deleted 
	   	  for (int i = 0; i < source.length; i++) {
	   	  // Delete Function 
	   	   if (flag == i){
	   	    for (int j = i + 1; i < source.length-1; j++) { 
	   	    source[i] = source[j];
	   	     i++;
	   	     }
	   	      System.out.println(source);
	   	      }
	   	      }
	   	    }
	   	    }
	   	    
	   	  Output:HAPPY HAPYLEARNINGG
	 */
}
