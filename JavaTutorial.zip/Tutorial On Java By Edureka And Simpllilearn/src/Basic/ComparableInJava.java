package Basic;
import java.util.ArrayList;
import java.util.Collections;
 
class Students implements Comparable<Students>{
 
	private int rollNumber;
	private String name;
	private int age;
	public Students(int rollNumber, String name, int age) {
		this.rollNumber = rollNumber;
		this.name = name;
		this.age = age;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override					//foreign object
	public int compareTo(Students student) {
		// TODO Auto-generated method stub
		return this.rollNumber-student.rollNumber;//your implementation based on how you want to sort the elements here based on roll numbers 
		/*this.rollNumber-student.rollNumber;--> current object roll number minus foreign object roll no.
		 * if value is positive  then this.object is going to take priority & if result is negative then Student/foreign
		 * object comes first and current/this object comes second. if it returns Zero then both the objects are 
		 * of same priority so any one of the object can come first.
		 */
	}
	
	
	
}
public class ComparableInJava {
/*
 * Need for Comparable occurs when we have to sort in collections
 */
	public static void main(String args[]) {
		
	
	ArrayList<Students> list=new ArrayList<Students>();
	 
	Students john=new Students(3, "John",21);
	Students jane=new Students(1, "Jane",18);
	Students tom=new Students(2, "TOm",20);
	
	list.add(john);
	list.add(jane);
	list.add(tom);
	
	Collections.sort(list);
	
	System.out.println("Students after sorting: ");
	list.forEach(student->System.out.println(student.getName()));
	
	}
	
/* Output:
 * Students after sorting: 
Jane
TOm
John
 we'll get this output many times no matter how many time we run the program & this is happening because of the
 compare to implementation which we have provided here.	 
 */
	
	
	
}
