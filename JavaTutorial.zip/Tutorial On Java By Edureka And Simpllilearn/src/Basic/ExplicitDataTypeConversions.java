package Basic;

public class ExplicitDataTypeConversions {
		public static void main(String args[]) {
			{
				double a=50.555555555555555;
				System.out.println("Double representation "+a);
				
				float f=(float)a;
				System.out.println("Float representation "+f);
				
				long b=(long)a;
				System.out.println("Long representaion "+b);
				
				int c=(int)b;
				System.out.println("Int representaion "+c);
			}
		}
}

/*public static void main(String args[]) {}
 * 	public-->to make Java run time to access this method
 * static-->we can run this method without creeating object of the class
 * void-->return type of the method here it'll not return anything
 * String args[]-->Used to pass command line arguments
 * 
 */
