package Basic;

public class StringBuilders {
/*
 * The Java StringBuilder class is used to create mutable String. But, StringBuilder 
 * class is non-synchronized i.e. it is not Thread Safe. Therefore StringBuider is faster
 * 
 
 		StringBuilder s=new StringBuilder("Happy Learning");
 		System.out.println(s); 
 					  				||
									\/	Output
    [  H |  a |  p |  p |  y |    |  L |  e |  a |  r |  n |  i |  n |  g |    |    ]
 	[  1 |  2 |  3 |  4 |  5 |  6 |  7 |  8 |  9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 ]
 					  				||
									\/
							By default, the capacity of StringBuilder is 16
	
  	
  	
  	Demo - StringBuilder
  	
  	public class stringBuilder {
  	public static void main(String[] args) { 
  	StringBuilder sb1=new StringBuilder ("Happy");
  	sb1.append("Learning"); 
  	System.out.println(sb1);
  	System.out.println(sb1.delete(0, 1));
  	System.out.println(sb1.insert(1, "Welcome"));
  	System.out.println(sb1.reverse());
  	   }
  	}
 					  				||
									\/	Output
							HappyLearning
							appyLearning 
							aWelcomeppyLearning
							gninraeLyppemocleWa
							
							
							
	StringBuilder sb1=new StringBuilder("Happy"); 
	sb1.append("Learning"); -------------------------------->HappyLearning----->The append() method appends the argument to the given StringBuilder		
	System.out.println(sb1);						Output
	
	System.out.println(sb1.delete(0, 1));------------------->appyLearning------>The delete() method deletes the sub sequence from given StringBuilder
													Output
 	
 	System.out.println(sb1.insert(1, "Welcome"));------------------->aWelcomeppyLearning------>The insert() method inserts the arguments to the given 
													Output 										uStringBuilder at given index value
 
 	System.out.println(sb1.reverse());---------------------->gninraeLyppemocleWa----->The reverse() method reverses the given StringBuilder
													Output 	
													
													
							When To Use Stringbuffer And Stringbuilder?
							
			StringBuffer								   		|					StringBuilder
 	StringBuffer s=new StringBuffer("Happy Learning");	  	    |    StringBuilder s=new StringBuilder("Happy Learning"); 
 	System.out.println(s);                              	    |	 System.out.println(s);
 	StringBuffer can be accessed by multiple threads at a time	|	 Stringbuilder can be accessed by single thread at a time
 	Slower as compared to StringBuilder							|	 Faster than StringBuffer
 */
}
