package ConcurrencyUtilitiesInJava;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
public class FutureDemo {
	public static void main(String args[]) {
		ExecutorService executorService=Executors.newSingleThreadExecutor();//newSingleThreadExecutor()-->uses a single worker thread operating of an unbounded queue 
		
		Future<String> future =executorService.submit(() -> {  //the result of the submit class is going to be future class
			Thread.sleep(10000); //10 sec
			return "Completed";
		});
		
		try {
			while(!future.isDone()) {
				System.out.println("Task still in progress.... wait");
				Thread.sleep(500); //if not done it'll wait for 5sec then it check again, it does this until it gets done
			}
			System.out.println("Task completed");
			/*
			 * when future.isDone() becomes true  12-15 lines task is completed.Now
			 * when we execute a program the execution happens sequentially that after line
			 * 15 the control will automatically flow to 17 & before the control reach line
			 * 17, everyting above line 17 has to be completed That's basically synchronous
			 * program for us. but when we talk about ASYNCHRONOUS programmin using the power
			 * of executor service & future object we can do someting in line 12-15 which will
			 * go into separate thread & then you can continue our execution in line 17-22.so 
			 * line12-15 can be a different method all together where we submit something & 
			 * line 17-21 is basically checking the status of line 12-15 task.
			 *  
			 *  Though it's a sequential execution after line 15 line 17 is getting executed
			 *  but line 17 is not waiting for everything above line 17 to get finished,line 17
			 *  will continue ,that's the power of Asynchronous programming so here
			 *  we're checking once future.isDone() says true  we say Task Completed
			 *  then we'll probably fetch the result of this task(line 12-15) for that
			 *  future provides a method called future.get-->this is going to pick the
			 *  future obeject state & whatever we're returning from there will be returned in
			 *  next lin & we'll print the result. SO if everything went fine the result 
			 *  should say "Completed"
			 */
			String result=future.get(3000,TimeUnit.MILLISECONDS);//that's the future object state
			System.out.println(result);
			
			executorService.shutdown();//Allways remember to shut down your executorservice to release the thread pool we've created
			
		}
		catch(InterruptedException | ExecutionException | TimeoutException e) { //InterruptedException-->as we used thread.sleep(); method
		future.cancel(true);
		future.isDone();
		future.isCancelled();//to check if the user or some other person explicitly cancelled the execution of the submission of the executor service task
		}
	}
	
	
}
