package ConcurrencyUtilitiesInJava;
/*
 * Concurrency: Do multiple things at the same time
 * Concurrency utilities packages provide a powerful,extensible framework of high-performance
 * threading utilities such as thread pools & blocking queues.This package frees the 
 * programmer from the need to craft these utilities by hand,in much the same manner
 * the collections framework did for data structures.Aditionally,these packages provide low-level
 * primitives for advanced concurrent programming.
 * 
 * Executors : Introduced in java 8, it's basically an interface which helps us to define 
 * the sub systems which we woild like to create with the help of threads , may be including
 * threadpools or If we want to do disc reading & writing operation in asynchronous way,
 * to create some sequence of task frameworks as well.Executor will provide a light weight
 * framework to do all of that.specially around thread pooling asynchronous IO is where 
 * it shines more
 * 
 * Asynchronous task-->basically we submitted a particular task but we did not wait for it
 * to be completed.we didnot hang our process/thread for that particular task to be completed
 * e.g we keep milk on stove for boiling & we do other work such as checking mobile or something
 * else as we know boiling milk takes some time we are  utilising this time for checking
 * mobile or to do some other thing this is called asynchronous programming
 * 
 * Executor is a simple standardized interface fro defining custom thread-like subsystems,
 * including thread pools,asynchronous I/O,& lihtweight task frameworks, Depending on which
 *  concrete Executor class is being used,tasks may execute in a newly created thread,an 
 *  existing task-execution thread,or the thread calling execute, & may execute sequentially or
 *  concurrently.
 *  Executor Service provides a more complete asynchronous task execution framework.An
 *  Executor Service manages queing & schedling of tasks, & allows controlled shutdown.
 *  The ScheduledExecutorService subinterface & associated interfaces add support for 
 *  delayed & periodic task execution
 *  ExecutorServices provide methods arranging asynchronous execution of any function
 *  expressed as Callable,the result-bearing analog of Runnable.
 *  
 *  A Future returns the result of a function,allows determination of whether execution
 *  has completed,& provides a means to cancel execution.A RunnableFuture is a Future that
 *  possesses a run method that upon execution,sets its results
 *  
 *  
 *  1.ExecutorService:An Executor that provides methods to manage termination & methods taht
 *  can produce a Future for tracking progress of one or more asynchronous tasks.
 *  2.Future: A Future represents the result of an asynchronous computation.
 *  3.ThreadFactory:An Object that creates new threads on demand
 *  4.TimeUnit:A TimeUnit represents time durations at a given unit of granularity & 
 *  provides utility methods to convert across units & to perform timing and delay operations
 *  in these units
 */
// FOCUS MAIN ON ASYNCHRONOUS PROGRAMMING
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Main {
	
	public static void main(String args[]) {
		executorInvoke();
		executorServiceInvoke();
	}
	
	private static void executorInvoke() {
		Executor executor=new Caller();
		executor.execute(() -> {
			System.out.println("executor example");
		});
	}
	
	private static void executorServiceInvoke() {
		ExecutorService executorService=Executors.newFixedThreadPool(10); //going to create a pool of threads dedicated to itself to do the tasks which ever are return inside here
		executorService.submit(() -> {
			System.out.println("Executor service example");
		});
		
	}
}
