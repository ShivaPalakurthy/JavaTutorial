package SynchronisationInJava;

public class MathUtils {
	//Two threads Thread1 & Thread 2 tries to access the same object of MAthUTils at a time 
	
	void getMultiples(int n) { // write synchronized to allow one thread at a time
		
	//	synchronized (this){
		for(int i=1;i<=5;i++) {
			System.out.println(n*i);
			/*Every time we do the first multiplication we sleep for 400 milliseconds,
			 *when we say sleep,it means the current thread is going to puase its execution
			 *for 400milliseconds& its going to leave the CPU idle & if another thread is 
			 *running currently in the system, that thread will get  the share of the CPU
			 *for that 400 millisecond.After the 400 millisecond , the thread is going to
			 *wake up & it is going to hunt for the idle CPU & start doing it's execution
			 */
			try {
				Thread.sleep(400);
			}catch(Exception e) {
				System.out.println(e);
			}
			
		}
	}
//	}
}
