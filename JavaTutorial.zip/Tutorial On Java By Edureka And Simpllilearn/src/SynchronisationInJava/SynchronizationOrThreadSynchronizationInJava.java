package SynchronisationInJava;

/*
 * What if two threads want to access the same object, if first object accessed the object 
 * & modified the object values but later second thread try to access the object value but
 * it gets modified objects rather than original object values this causes major problem
 * eg. for a bank acc0ount if a person is withdrawing & crediting 500 at the same instance of 
 * time the threads will throw errors as the software get confused to show as 1500/2000/2500 as the 
 * net value after the operation as it  is being accessed at the same instance of time & 
 * the value is modified i.e withdarwing thread & crediting thread accessing the bank
 * at the same instance of time..java provides a solution for it with the concept
 * of Intrinsic Locks & Synchronisation.
 * 	 SO the idea is when a thread tries to work on a particular object,it basically takes
 * lock on the particular object we also call this as an intrinsic lock or monitor lock&
 * it means that particular object becomes completely in accessible to other threads in the
 * system at that particular time
 */
public class SynchronizationOrThreadSynchronizationInJava {
		public static void main(String args[]) {
			MathUtils obj=new MathUtils();
			
			Thread1 t1=new Thread1(obj);
			Thread t2=new Thread(new Thread2(obj));
			t1.start();
			t2.start();
		}
}

/* OUtput
3
2
6
4
6
9
8
12
15
10

since two threads are accessing the same object of MathUtils we get diiferent order , to 
fix this by adding 	synchronized keyword infront of a method which is being accessed by multiple threads.
	so once we put the synchronized keyword in front of the method(getMultiples) which is
	being access by multiple threads at the same time , that whole method (getMultiples)
	gets synchronized now, that means only one thread will execute this method at once, 
	there will never be a scenario where two or more threads are simultaneously accessing it
	
		synchronized void getMultiples(int n) {
		for(int i=1;i<=5;i++) {
			 
			try {
				Thread.sleep(400);
			}catch(Exception e) {
				System.out.println(e);
			}
			
		}
	}
}
							or 
If there is a scenario where you don't want to lock or synchronize the whole method ,you
still want different threads to access the method but there can be a very few lines of code
inside the method which is thread sensitive code & needs to be synchronized. The momment
you want to lock the thread sensitive code but don't want to lock the entire method by putiing
the synchronized block. you can write as below
synchronized (this){
thread sensitive code	} of function void getMultiples(int n){}
 
 like below

  void getMultiples(int n) {
		
		synchronized (this){
		for(int i=1;i<=5;i++) {
			System.out.println(n*i);
			try {
				Thread.sleep(400);
			}catch(Exception e) {
				System.out.println(e);
			}
			
		}
	}
	}
	
	
	74-82 is thread sensitive code written in synchronized block 			
 
 
 
 
 It is necessary to identify which thread needs to be synchronised if we synchronise entire 
 method then it results in latency in execution which reduces overall performanc of the
 website 
*/
