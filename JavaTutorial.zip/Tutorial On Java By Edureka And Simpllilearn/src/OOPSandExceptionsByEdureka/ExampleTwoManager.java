package OOPSandExceptionsByEdureka;
			//Method Overloading
public class ExampleTwoManager {
	long salary;
	public void display (Integer dummyIntValueToBePrinted) { 
		System.out.println("Printing integer value "+dummyIntValueToBePrinted);
	}
	public void display (String dummyStringValueToBePrinted) {
		System.out.println("Printing string value " + dummyStringValueToBePrinted);
	}
	public static void main(String[] args) {
		ExampleTwoManager seniorManagerGrade2= new ExampleTwoManager() ;
		seniorManagerGrade2.display(100);
		seniorManagerGrade2.display ("Senior manager grade 2");
		
		
	}
}
