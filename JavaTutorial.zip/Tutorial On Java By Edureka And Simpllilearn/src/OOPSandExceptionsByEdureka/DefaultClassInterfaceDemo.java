package OOPSandExceptionsByEdureka;
			//Demo: Default Methods In An Interface

interface Welcome{
	// Default method
	default void say(){
		System.out.println("Hello, Welcome to edureka");
	}
	// Abstract method
	void hello(String msg);
}
public class DefaultClassInterfaceDemo implements Welcome{
	public void hello(String msg){// implementation of abstract method
		System.out.println(msg);
	}//The type DefaultClassInterfaceDemo must implement the inherited abstract method Welcome.hello(String)
	public static void main(String[] args) {
		DefaultClassInterfaceDemo out = new DefaultClassInterfaceDemo();
		out.say(); //default method 
		out.hello("Happy Learning"); // calling abstract method
}
}
//Hello, Welcome to edureka  <--Output
//Happy Learning