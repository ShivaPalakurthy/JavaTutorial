package OOPSandExceptionsByEdureka;
import java.util.regex.Matcher; 
import java.util.regex.Pattern;

public class RegularExpressionDemo {
	public static void main(String[] args) {
		String s = "I will be in the room in 10 minutes.";
		//match all words "in"
		Pattern p= Pattern.compile("\\bin\\b");//-->This pattern is used to search the 
		//word "in" in the given String(considering that the word is not at the boundary
		//of any other word)
		Matcher m = p.matcher(s);
		while (m.find()) {
			System.out.println("Pattern matches: " + m.group() +" at "+ m.start());
		}
	}
}
//Output:
//Pattern matches: in at 10  
//Pattern matches: in at 22
