package OOPSandExceptionsByEdureka;

public class MultipleCatchBlock {
		public static void main(String args[]) {
			int denominator=1;
			int[] integerArray= {1,2,3};
			try { 
				System.out.println(29 /denominator);
				System.out.println(integerArray[3]);
			} catch (ArithmeticException exception){ 
	 			System.out.println("Printing any kind of Arthimetic Exception Occured "+exception.getMessage());
			}catch(NullPointerException npe) {
				System.out.println("Null Pointer Exception Handler");
			}catch(ArrayIndexOutOfBoundsException npe1) {
				System.out.println("Array Index Out Of Bounds Exception Handler");
			}catch(Exception e) {    //Keep this above catch block to see the difference
				System.out.println("Generic Exception Handler");
			}
			finally {
				System.out.println("Finally block under execution");
			} 
		}		
	}
//Output:29
//		Array Index Out Of Bounds Exception Handler
//		Finally block under execution
