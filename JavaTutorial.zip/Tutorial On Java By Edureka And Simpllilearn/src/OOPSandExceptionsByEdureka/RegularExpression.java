package OOPSandExceptionsByEdureka;
/*
 				Let's Understand What Is Regular Expression?
Regular Expression:
 • A regular expression is a pattern used for searching and manipulating strings
 • The regular expression either matches the text or fails to match
 • The abbreviation used for regular expression is regex
 
 						The java.util.regex Package
The java.util.regex package of Java is used for pattern matching with regular expression
Pattern Class,Matcher Class,PatternSyntaxException-->Three classes from java.util.regex
 package are used to perform different operations for regular expressions
 
 							Patterns
 Here are some matching patterns used in regular expression
 Patterns	  |				Description
 abc		  |Exactly this sequence should be followed
 [abc]		  |Any one letter a, b or c should match
 [^abc]		  |Any letter except these 3 should be matched
 [a-z]		  |Any one letter from a to z should be present in sequence
 [a-zA-z0-9]  |Any one letter or digit should be in sequence
 .			  |Any one character except line terminator must be in a sequence
 ^			  |To check if any character present at the beginning of a line
 $			  |To check if any character present at the end of a line
 \b			  |To verify whether any character is present at word boundary or not
 \B			  |To verify that any character is not present at word boundary
 \G			  |To check that the character is present at the end of previous match
 
 							Quantifiers
  Patterns	  	|				Description
  *				|Occurs zero or more times
  +				|Occurs one or more times
  ?				|Occurs no or one time
  {X}			|Occurs X number of times
  {X,Y}			|Occurs between X and Y times
  *?			|It tries to find the smallest match. This makes the regular expression
  				 stop at the first match		
  
  					Demo 1 - Regular Expression
import java.util.regex.*;  //Importing regex class from util package

public class RegularExpression {
	public static void main(String[] args) {
		String pattern = "[a-z]+";
		String check = "Happy Learning! Welcome to Edureka";
		//line 44-45-->The pattern and the sentence which is to be matched are given.
		// [a-z] means any character from a to z and + means one or more
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		while (c.find()) {
			System.out.println(check.substring( c.start(), c.end() ) );
		}
		//line 48-52--->The sentence (check) is checked whether it matches the pattern 
		//or not and Strings from the sentence which match the string are printed
	}
}
// Output:-appy
//		 earning
//		 elcome
//		 to
//		 dureka
 
    						Demo - Pattern Checker
 
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternChecker {
		public static void main(String args[]) {
			String pattern="[a-z]+";
			String stringToCheck="Happy Learning!";
			Pattern compiledPattern=Pattern.compile(pattern);
			Matcher matcher=compiledPattern.matcher(stringToCheck);
			while(matcher.find()) {
				System.out.println(stringToCheck.substring(matcher.start(),matcher.end()));
			}			//Output:-appy
		 				//		 earning
			String pattern1="[a-zH]+";
			Pattern compiledPattern1=Pattern.compile(pattern1);
		Matcher matcher1=compiledPattern1.matcher(stringToCheck);
		while(matcher1.find()) {
			System.out.println(stringToCheck.substring(matcher1.start(),matcher1.end()));
		}			//Output:-Happy
	 				//		 earning
		String pattern2="\\bin\\b";
		String stringToCheck2="Happy Learning in Edureka!";
		Pattern compiledPattern2=Pattern.compile(pattern2);
		Matcher matcher2=compiledPattern2.matcher(stringToCheck2);
		while(matcher2.find()) {
			System.out.println(stringToCheck2.substring(matcher2.start(),matcher2.end()));
		}//Output:-in
		
	}
}

						
						Demo 2 - Regular Expression
import java.util.regex.Matcher; 
import java.util.regex.Pattern;

public class RegularExpressionDemo {
	public static void main(String[] args) {
		String s = "I will be in the room in 10 minutes.";
		//match all words "in"
		Pattern p= Pattern.compile("\\bin\\b");//-->This pattern is used to search the 
		//word "in" in the given String(considering that the word is not at the boundary
		//of any other word)
		Matcher m = p.matcher(s);
		while (m.find()) {
			System.out.println("Pattern matches: " + m.group() +" at "+ m.start());
		}
	}
}
//Output:
//Pattern matches: in at 10  
//Pattern matches: in at 22

 */
				//Demo 1 - Regular Expression
import java.util.regex.*;  //Importing regex class from util package

public class RegularExpression {
	public static void main(String[] args) {
		String pattern = "[a-z]+";
		String check = "Happy Learning! Welcome to Edureka";
	// for above two lines pattern ,check-->The pattern and the sentence which is to be
	//matched are given. [a-z] means any character from a to z and + means one or more
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		while (c.find()) {
			System.out.println(check.substring( c.start(), c.end() ) );
		}
	}
	//from p to end of while loop or from Pattern p = Pattern.compile(pattern); to the
	// end of while loop The sentence (check) is checked whether it matches the pattern 
	//or not and Strings from the sentence which match the string are printed
}
// Output:-appy
//		 earning
//		 elcome
//		 to
//		 dureka