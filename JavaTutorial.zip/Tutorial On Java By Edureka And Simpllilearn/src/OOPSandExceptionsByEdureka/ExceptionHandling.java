package OOPSandExceptionsByEdureka;
/*
 	Let's Understand Exception Handling.But, First Let's Understand What Is An Exception
Exception:
 • An Exception is an event, which occurs during the execution of a program, that
   disrupts the normal flow of the program's instruction
 • When an Exception occurs, the JVM creates an exception object to identify the type of
   exception that has occurred
 • An Exception is often to referred as Runtime Error
 Example:
 	Exception in thread "main" java.lang. ArithmeticException: / by zero at
 	 ExceptionDemo.main(ExceptionDemo.java:8)
 	 
 	 						Types Of Exception
Exception types are of 3 types:
1.Checked Exception:
 • Also called as Compile-time Exception
 • It means if a method is throwing a checked exception then it should handle the 
 exception using try-catch block or it should declare the exception using throws
 keyword. otherwise the program will give a compilation error.
2.Unchecked Exception:
 • Also called as Run-time Exception
 • It means if your program is throwing an unchecked exception and even if you didn't
  handle/declare that exception, the program won't give a compilation error. It is up
  to the programmer to judge the conditions in advance, that can cause such exceptions
  and handle them appropriately
3.Error:
 • These are exceptional conditions that are external to the application, and that the
  application usually cannot anticipate or recover from. For example,if a stack overflow
  occurs, an error will arise. They are also ignored at the time of compilation	

								Exception Class
									
									Throwable
									    |
		----------------------------------------------------------------------
		|																	 |
	Error																Exception
	  																		|
		----------------------------------------------------------------------
		|																	 |	 
	Checked Exceptions									 		Unchecked Exceptions
	  |--->IOException													|
	  |--->SQLException												Runtime Exception
	  												ArithmeticException <---|
	  												ArrayStoreException <---|
	  								     			 ClassCastException <---|
	  										   IllegalArgumentException <---|
	  											IllegalMonitorException <---|
	  							   			  IndexOutOfBoundsException <---|
	  											 NegativeArrayException <---|
	  											   NullPointerException <---|
	  												  SecurityException <---|
	  										 Other unchecked exceptions <---|
	  					
	  					Why To Use Exception Handling?
 • When we execute the given program, we will get an Exception
 • Exception Handling is performed in order to get the output
 • Uses of Exception Handling:
 		-Process Exceptions from program components
 		-Handle Exceptions in a uniform manner in a large project
 		
public class ExceptionDemo {
public static void main(String[] args) {
	int a=9;
	int b=0;
	System.out.println(a/b);
	}
}		  ||
		  \/ Output
Exception in thread "main" java.lang.ArithmeticException: / by zero at 
ExceptionDemo.main(ExceptionDemo.java:8)	


	`							Exception Handling
 • When a runtime error occurs, program gets crashed and control comes out of program
 • Exception Handling is done to execute the program, without getting an exception
 • Mainly, try, catch and finally are keywords for exception handling	
 
 
 								Exception Handling - Blocks
1.try Block:Code that could generate an error is written in try block
2.catch Block:If there are any issues or runtime errors, control comes in catch block 
3.finally Block:Whether successful or unsuccessful execution, statements in the finally
 block gets executed
 
 					Demo: 1 Exception Handling Using Try-catch Blocks
public class ExceptionDemo {

	public static void main(String[] args) {
		int a = 9;
		int b = 0;
		try {     //The part of code which could generate an Exception is put into try Block
			System.out.println(a / b);
		} catch (Exception e) { //Code for an exception handling is written in a catch Block
			System.out.println("We can not divide any number by zero. Divide by Zero Exception has occurred");
		}
	}
// Output->We can not divide any number by zero. Divide by Zero Exception has occurred
}
					
					
					Demo: 2 Exception Handling Using Try-catch Blocks
public class ExceptionDemo {

		public static void main(String[] args) {
		try {//The part of code which could generate an Exception is put into try Block
			System.out.println(29 / 0);
		} catch (ArithmeticException exception)
		{//Code for an exception handling is written in a catch Block
 			System.out.println("Printing any kind of Arthimetic Exception Occured "+exception.getMessage());
		}//Output:Printing any kind of Arthimetic Exception Occured / by zero
		finally {
			System.out.println("Finally block under execution");
		}//Output:Printing any kind of Arthimetic Exception Occured / by zero
	}		//Finally block under execution
}	

							Why to use Multiple catch Block?
1.There will be many cases in which different exceptions may occur. So, in such 
 scenarios, one try block can have multiple catch blocks. Depends on the type of
 exception thrown corresponding catch block is invoked
2.Since all the exceptions are derived from Exception, catch (Exception e) should
 be placed at last. It can catch all the exceptions
 
 
 				Demo: 1 Multiple catch Block 
 public class MultipleCatchBlock {
		public static void main(String args[]) {
			int denominator=1;
			int[] integerArray= {1,2,3};
			try { 
				System.out.println(29 /denominator);
				System.out.println(integerArray[3]);
			} catch (ArithmeticException exception){ 
	 			System.out.println("Printing any kind of Arthimetic Exception Occured "+exception.getMessage());
			}catch(NullPointerException npe) {
				System.out.println("Null Pointer Exception Handler");
			}catch(ArrayIndexOutOfBoundsException npe1) {
				System.out.println("Array Index Out Of Bounds Exception Handler");
			}catch(Exception e) {    //Keep this above catch block to see the difference
				System.out.println("Generic Exception Handler");
			}
			finally {
				System.out.println("Finally block under execution");
			} 
		}		
	}
//Output:29
//		Array Index Out Of Bounds Exception Handler
//		Finally block under execution
 
 
 						Demo:2 Multiple catch Block 4

public class MultipleCatchDemo {
	public static void main(String args[]){ 
		try{
			int a=10; // We are considering ArrayIndexOutOfBounds Exception 
			int b=5; 
			int c=a/b;
			int d[]= {1,3,5,7};
			System.out.println(d[10]);//We are trying to access element,which is out of bounds
//			Here, array d has 4 elements (index 0 to index 3), but we are trying to
//			print the element at 10th index. ArrayIndexOutOfBounds Exception occurs
		}
		catch(ArithmeticException e){ 
			System.out.println("Arithmetic Exception has occurred"); 
			}
		catch(ArrayIndexOutOfBoundsException e){ 
			System.out.println("ArrayIndexOutOfBounds exception has occurred");
			}
		catch(Exception e){
			System.out.println("Exception has occurred"); 
			}
	}

}
//Output:ArrayIndexOutOfBounds exception has occurred
 
 						Demo: Nested try Blocks
In many cases it may happen that a part of block may cause an error and the entire block
 may cause another error. In such cases we are going to use Nested try Blocks
 
public class NestedTryDemo {
	 public static void main(String[] args) { 
		 try {
		 try {
			 int a=50;
			 int b=0; 
			 System.out.println("Division is: "+(a/b));
		 }
		 catch(ArithmeticException e) {
			 System.out.println("Arithmetic exception (Divide by zero) has occurred");
			 }
		 try { 
		 int a[]= {1,3,5};
		 System.out.println(a[5]);
		 }
		 catch(ArrayIndexOutOfBoundsException e) {
			 System.out.println("You are trying to access element of array, which is out of bound");
		 }
		 }
		 catch(Exception e) {
			 System.out.println("Exception occurred");  
		 }
		 }
}

//Output:Arithmetic exception (Divide by zero) has occurred
//		You are trying to access element of array, which is out of bound
 
 								Why To Use throw Keyword?
 • The Java throw keyword is used to explicitly to throw an Exception while executing
  the program
 • It can be used to throw Checked or Unchecked Exceptions
 • The java throw keyword is used inside a method

							Demo: throw Keyword
public class ThrowDemo {
	public static void main(String[] args) {
		try {
			int a = 50;
			int b = 0;
			if (b == 0)
				throw new Exception("Divide by zero causes an Exception");
			int c = a / b;
			System.out.println("Result is" + c);
		} catch (Exception e) {
			System.out.println("Exception is" + e);
		}

	}

}
//Output:Exception isjava.lang.Exception: Divide by zero causes an Exception
 
 
 							Why To Use throws Keyword?
 • The Java throws keyword is used to declare an Exception in the program
 • It is mainly used for Checked Exceptions
 • The java throws keyword is used with a method signature
 • Throws keyword used to improve the readability of a code. throws keyword is used
    mostly for user defined exceptions. Instead of using try-catch block multiple times,
    we can write throws
 							Demo: throws Keyword
 	public class ThrowsDemo {
	public static int divide(int a, int b) throws Exception {
		int c;
		c = a / b;
		return c;
	}

	public static void main(String args[]) {
		try {
			ThrowsDemo t = new ThrowsDemo();
			int ans = divide(10, 0);
			System.out.println("Result is: " + ans);

		} catch (Exception e) {
			System.out.println("Exception is: " + e);

		}

	}

}


//Output:-Exception is: java.lang.ArithmeticException: / by zero						


						Difference Between Throw And Throws Keyword
			Throw Keyword					|				Throws Keyword
i.The throw keyword is used to explicitly	|i.The throws keyword is used to declare an 
  throw an Exception						|  Exception
ii.Throw keyword is followed by an instance |ii.Throws keyword is followed by a Throwable 
											|	class
iii.Throw keyword is used within a method	|iii.Throws keyword is used with the method
 											|	signature		
iv.Throw keywordcan throw only one exception|iv.Throws keyword is used to declare multiple
 												exceptions
 						
 						 User-Defined Exceptions Using throws
 • You can create your own exception, it is called as User-Defined Exception or Custom 
 Exception
 • A user-defined exception class can be created by creating a child class of
  java.lang.Exception 
  			
  									Throwable
  										|
  	   --------------------------------------------------------------------
  	   |																   |
 Exception																Error
  |-->IO-Exception											JVM Error<----|
  |-->SQL-Exception											   Memory<----|
  |-->ClassNotFound											Framework<----|
  |-->Run-Time
  		 |-->Arithmetic
  		 |-->NumberFormat
*/	
public class ExceptionHandling {

}
