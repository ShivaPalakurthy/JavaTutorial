package OOPSandExceptionsByEdureka;

public class OOPSConcepts {
	/*
	 * 					//Object Oriented Programming Concepts
	 * Object Oriented Programming:
	 * 							 	1.Inheritance
	 * 								2.Polymorphism
	 * 								3.Abstraction
	 * 								4.Encapsulation
	  1.INHERITANCE:
	   Inheritance is the powerful feature of Object Oriented Programming, through
	   which one object acquires some or all the properties and behaviour of Parent Object
	   								
	   ---------------------------------Vehicle------------------------------------------
	   |						|								|						|
	  Bikes				      Cars						 	  Buses					  Trucks
	   |						|	
	 ----------------		---------------------
	 |				|		|					|   
	R15			   KTM    Alto				 Fortuner 

	IS-A Relationship:Inheritance represents IS-A relationship, also known as Parent-Child
		 relationship
									Inheritance is used in Java for
												|
						----------------------------------------------------
						|													|
				Method Overriding 									Code Reusability
			(To achieve run time polymorphism)
			
										class Subclass extends SuperClass
			Syntax of Inheritance:		{
												//Variables 
												//Methods
										}
										
		Demo-Inheritance
		
class Manager{								//------>super class
	int salary = 100000;
}

class Employee2 extends Manager				//------>child class
{
	int id=15;
	int empSal=25000;
}
 public class InheritDemo{
	public static void main(String args[]) {
		Employee2 e=new Employee2();
		System.out.println("Employee with id "+e.id +" gets "+e.empSal+" every month");
		System.out.println("Managers Salary is "+e.salary); //--->Methods & variables of SuperClass can be accessed by child class
	}
}

output:Employee with id 15 gets 25000 every month
Managers Salary is 100000
							
							
								Types Of Inheritance
1.a: Single Inheritance:					1.b:Hierarchical Inheritance		
	[	A 	]							[	A	]		[	B	]
	    |									\				/
		|									 \			   /	
	[	B	]								  \			  /
											   \		 /
											    \		/
											     \	   /
											     [	 C	]
1.c:Multilevel Inheritance
	[	A	]
		|
		|
	[	B	]
		|
		|
	[	C	]
	
	
1.a :Single Inheritance

class Vehicle{
void property(){
System.out.println("Because it has wheels");
}
class Bike extends Vehicle{
void run()
{System.out.println("Bike is running");}
}
public class SimpleInherit {
public static void main(String[] args) { 
Bike d=new Bike();
d.run();
d.property();			//Output-->Bike is running
}						//		   Because it has wheels
} 				   

1.b :Hierarchical Inheritance
class Vehicle3{
void move(){System.out.println("Vehicle is moving");}
}
class Bikes extends Vehicle3{
void changeGear(){System.out.println("Bike has 2 wheels");}
}
 class Cars extends Vehicle3{ 
  void run(){System.out.println("Car has 4 wheels, so it can get motion to run");}
   }
public class HierInheritance 
 { public static void main(String[] args) 
 {													//Output
  Cars c=new Cars();			//Car has 4 wheels, so it can get motion to run Vehicle is moving
  c.run();
  c.move();
   }
   }
   

1.c:Multilevel Inheritance
	class Vehicle1{
	void run3(){
		System.out.println("Vehicle is the parent class");
		}
}
class Bike1 extends Vehicle1{
	void run2(){
		System.out.println("Bike has some properties of a Vehicle");
	}
}
class Cycle extends Bike1{
	void run1() {
		System.out.println("Cycle has some properties of Bike");
		}
}
public class Multilevelinheritance {
	 public static void main(String[] args) {
		 Cycle c=new Cycle();
		 c.run1(); 
		 c.run2();
		 c.run3();
	 }
}
     //Ouput -->
    // Cycle has some properties of Bike
   //Bike has some properties of a Vehicle
  //Vehicle is the parent class	
   					
   						HAS-A Relationship
 ==>If class has an entity reference, it is known as Aggregation. 
   It represents HAS-A relationship
 ==>A "department" in a College has several "professors". Without existence of 
 "departments" there is good chance for the "professors" to exist. Hence "professors"
  and "department" are loosely associated and this loose association is known as 
  Aggregation

Demo
class Name{ 
	String first, last;
	public Name(String first, String last)
	{
		this.first=first;
		this.last=last;
	}
}

class EmployeeInfo{
	int id;
	Name name;
	
	EmployeeInfo(int id, Name name){
		this.id=id;
		this.name=name;
	}
	void display() {
		System.out.println("Employee id is "+id);
		System.out.println("Name of Employee "+name.first+" "+name.last); 
	}
}
public class HasDemo {
	public static void main(String[] args) {	
		Name name=new Name("Alex","Desouza"); 
		EmployeeInfo ei=new EmployeeInfo(1,name); 
		ei.display();
		} 
}
	 //	ouptut is ==>Employee id is 1
	//				 Name of Employee Alex Desouza


							2.Polymorphism 
When one task is performed by different ways, then it is called as Polymorphism
							
		 --------------------------Person------------------------
		|														|
	Student pay_bill()								Millionare pay_bill()
	
	
	2.a: Method Overloading: Compile-time Polymorphism:
	A class may define multiple methods with the same name and return type, but 
	different number of arguments or arguments of different data types. This is
	called Method Overloading
	
	e.g:Alex wants to write a code, which can be used to find out the area of 
	Triangle as well as of the Circle.
			I want to find area of both the shapes. Here area is the common method.
    So, instead of writing two methods of different names, I will write area as method 
    name for both shapes and I will pass different arguments according to respective 
    shape.
    
    To get the solution of above scenario, we are going to use Method Overloading
    
    public class MethodDemo {
	public void area(int b,int h)
	{
		System.out.println("Area of Triangle: "+(0.5*b*h));
	}	
	public void area(int r)  
	{
		System.out.println("Area of Circle: "+(3.14 *r*r));
	}
	public static void main(String args[]) {
		MethodDemo a=new MethodDemo();
		a.area(4,6); 
		a.area(5);
		
	}
}
//			Output -->Area of Triangle: 12.0
//			Area of Circle: 78.5
  
 Method Overloading does not depend on return type. It is differentiated only by the
  arguments of the method
  
  
 Method Overloading can be done by changing the data type of arguments
 public class MethodOverload {
	public void display(int x) {
		 System.out.println("Welcome to Integers");
	}
	public void display(String y)
	{
		System.out.println("Welcome to Strings");
	}
	public static void main(String[] args) { 
		MethodOverload mo=new MethodOverload(); 
		String s="Hello";
		mo.display(s);
		mo.display(12);
	}
}
//					Output:--->Welcome to Strings
//							   Welcome to Integers

2.b: Method Overridding:
If child class has the same method as declared in the parent class, it is known 
as Method Overriding
	i.Method Overriding must be used in case of Inheritance. It has IS-A relationship.
	ii.Method must have the same name as in parent class.
	iii.Method must have the same parameters as in parent class.
e.g:
	class Man{
	void pay(){
		System.out.println("Paying bill");
		} 
}
class Millionaire extends Man{
	void pay(){
		System.out.println("Millionaire is paying bill and giving tip also");
	}
}
public class PolymorphismDemo {
	public static void main(String[] args) { 
		Man obj = new Millionaire();//Output
		obj.pay(); 					//Millionaire is paying bill and giving tip also
	}
}

							JAVA SUPER KEYWORD:
The super keyword in java is a reference variable that is used to refer parent class
objects.		i.Used to refer immediate parent class instance variable
				ii.Used to invoke parent class method
				iii.Used to invoke parent class constructor
Example:1
class Vehicles{
	String wheels="Vehicle moves because of wheels";
}
class Truck extends Vehicles{
	String wheels="Truck has 4 wheels";
	void printWheel(){
		System.out.println(wheels);//prints wheels of Truck class 
		System.out.println(super.wheels);//prints wheels of Vehicle class
	}
}
public class SuperKeyword {
	public static void main(String[] args) {
		Truck b=new Truck();
		b.printWheel();
	}
}
//Output
//Truck has 4 wheels
//Vehicle moves because of wheels


Example:2
class VehicleMan{
	VehicleMan(){
		System.out.println("Vehicle is Manufactured");
		}
}
class Trucks extends VehicleMan{
	Trucks(){
		System.out.println("Truck is created");
	}
}
public class SuperKeywordAnotherExample {
	public static void main(String[] args) {
		Trucks t=new Trucks();
	}
}
//In this example, super() is provided by compiler implicitly
//Output
//Vehicle is Manufactured
//Truck is created
							
							JAVA FINAL KEYWORD
Java final is a non-access modifier applicable only to a variable, a method or a class.
final can be:-- i.Variable
				ii.Method
				iii.Class
Final modifier can be applied to: Class
								  Method
								  Instance Variable
								  Class Variables (static)
								  Local Variable
								  Method parameters
• Final variable is used to create constant variables
• Final methods is used to prevent method overriding
• Final classes is used to prevent inheritance
If a class is declared as "final", then child classes cannot be created for that. A
 final class cannot be given after "extends" keyword.
 
 Some examples of final class is String class, System class in java.lang package
• If a method is declared as "final", then that method cannot be overridden in the child class.
• If a variable (instance variable, local variable, class variable, method parameter) is
  declared as "final" then the value of that variable cannot be changed or that cannot be 
  assigned (-constant variables).
• A constructor cannot be declared as "final"
• A blank final variable should be initialized in the constructor
		 final int age; //blank final variable
Example:-1
class Vehicless{
	final void run(){
		System.out.println("Vehicle is running");
	}
}
class Bus extends Vehicless{
	void run(){  //If you make any method as final, you cannot override that method
		System.out.println("Bus is running safely with 100kmph");
	}
}
public class FinalDemo {
	public static void main(String[] args) {
		Bus bus=new Bus(); 
		bus.run();
		}
}
//Output---->Compile Time Error
  
 Example:2
 final class Bike{
	
}
class Cycle extends Bikes{		//If you declare any class as final, you cannot override that class
	void changeGear(){
		System.out.println("running safely with 100kmph");
	}
}
public class FinalKeyDemo {
	public static void main(String[] args) { 
		Cycle c= new Cycle(); 
		c.changeGear(); 
		}
}
//Output: Compile Time Error
  
 							DYNAMIC BINDING
 Connecting a method call to the method body is known as Binding
 The binding can be Static or Dynamic
 In Dynamic Binding, type of object is determined at run-time.
 Example:
 class Vehicle{
void run(){
	System.out.println("Vehicle is running");
	}
}
class Bus extends Vehicle{
	void run(){
		System.out.println("Bus is running safely");
	}
}
public class PolymorphismDemo {
	public static void main(String[] args) {
		Vehicle obj = new Vehicle();
		obj.run();
	}
}
//Output :Vehicle is running


					3.ABSTRACTION
Abstraction is a mechanism of hiding the implementation details from the user and only
 providing the functionality to the user
When you get a call, you only get to know the number who is calling you, but not the
 operations performed at the backend
 Abstraction lets you focus on what the object does instead of how it does it. There
 are two ways to achieve abstraction in Java
1. Abstract class (0 to 100% abstraction)
2. Interface (100% abstraction)
  
Abstract Class and Abstract Method:
i.An abstract method is a method that is declared without an implementation
ii.Any class that contains one or more abstract methods. must also be declared with 
abstract keyword
iii.An abstract class is a class that is declared with abstract keyword
iv.An abstract class may or may not have all abstract methods
v.Abstract class is mostly used for inheritance

Example:
abstract class Mobile{
	Mobile () {System.out.println("Mobile is the base class");}  //--->2 The default constructor of Mobile Class gets executed
	abstract void run();
	void dialNumber() {System.out.println("Numbers are dialled from Nokia mobile");} //---->4 At last dailNumber() method gets executed
}
class Nokia extends Mobile{void run() {System.out.println("Nokia is the derived class");}} //--->3 As we are calling run() method, but in Mobile class run()is an abstract method. So, run() method from Nokia class gets executed
public class AbstDemo {
	public static void main(String[] args) {
		Mobile obj = new Nokia();   //---->1 The main() gets executed first. Object of Mobile Class is created
		obj.run(); //---->3 point value here
		obj.dialNumber();
	}
}

//Output:Mobile is the base class
//		 Nokia is the derived class
//		 Numbers are dialled from Nokia mobile

								4.ENCAPSULATION
Encapsulation is the methodology of binding code and data together into single unit

To achieve encapsulation in Java:
	i.Declare the variables of a class as private.
	ii.Provide public setter and getter methods to modify and view the variables values
Advantages Of Encapsulation:
	i.Data Hiding: The user will have no idea about the inner implementation of class
	ii.Increased Flexibility: We can make variables and methods read-only or write-only as per requirement
	iii.Reusability: Easy to reuse and easy to change with new requirements
	iv.Testing is easy
	
	Example:
	class Employee1{ 
	private String name;
	public String getName(){
		return name;
	}
	public void setName(String name){ 
		this.name=name;
	}
}
public class DemoEncaps {
	public static void main(String[] args) {
		Employee1 e=new Employee1();
		e.setName("Alex"); 
		System.out.println(e.getName()); //Ouptut:Alex
	}
}

								//LET'S UNDERSTAND INTERFACES
What Is An Interface?
Every remote whether it is a TV remote or gaming remote or AC remote, needs to have a
 common design pattern. For example power button, directional buttons etc. which are
 common to every remote
 Hence, an interface contains all these specification and can be used while creating a
 new remote
	
	An Interface contains variables and methods, but the methods declared inside 
Interface are by default abstract methods.
i.An interface is used to achieve Abstraction
ii.we can achieve multiple inheritance
iii.It is also used to achieve loose coupling
iv.Java interface represents IS-A relationship

						Difference Between Interface And Class
			Interface						|				Class
i. An interface can never be instantiated   |i. A class is instantiated to create objects
ii.An interface should contain abstract 	|ii.A class should contain only concrete methods 
   methods									|
iii.The members of an interface are always 	|iii.The members of a class can be private, 
	public									|	public, protected
iv.An interface can never have a constructor|iv.A class can have constructor to initialize
 											|	the variables
v."implements"keyword isused for inheritance|v."extends" keyword is used for inheritance
vi.after extends keyword any number of 		|vi.after extends keyword only once class 
	interfaces can be given					|	can be given
vii.cannot contain instance fields.The only |vii.can contains instance fields
	fields that can appear in an interface 	|
	must be declared both static and final	|
					 
					 
					 
					 Difference Between Class And Abstract Class
			Class							|			Abstract Class
i.Classes have implementation				|i.Abstract classes have no implementations
ii.Concrete classes are instantiated to 	|ii.Abstract classes can not be instantiated
create objects								|
iii.A concrete class can be final			|iii.An abstract class can never be final, as 
											|	 it has no defined functions.
																		
																		
				
						Difference Between Abstract Class And Interfaces
			Abstract Class					|			Interface
i.An abstract class can be extended to a 	|i.An interface can be implemented to a class
class using keyword "extends".				|	 using keyword "implements".
ii.An abstract class can extend only one 	|ii.An interface can extend any number of 
class at a time.							|	interfaces at a time
iii.Abstract class can have private,default,|iii.Interface members (member data) are
 protected and public members.				|	 public by default.
iv.In abstract class, keyword 'abstract' is	|iv.In an interface, keyword 'abstract' is
mandatory to declare a method as an abstract|	 optional to declare a method as an  
method.										| 	abstract method.
v.Abstract classes are to achieve 0% to 100%|v.Interfaces are used for achieving 100% 
 abstraction.								|  abstraction.
vi.An abstract class can have constructors.	|vi.An interface cannot have constructors
vii.Abstract class can have abstract and	|vii.Interface can have only abstract methods.
 non-abstract methods.						| From Java 8, it can have default and static
 											|  methods also.
 											
 											
 											
 								Class-Interface Relationship
 • A class extends another class, while implements an interface
 • An interface extends another interface
  class					interface				interface
   /\						/\						/\
   || extends				||implements			||extends	
   ||						||						||
  class					  class					interface
  
  A class can not extend multiple classes, but can implement multiple interfaces.
  
    class			interface				 
   /\				  /\					 
   || extends		  ||implements
   ||				  ||			 
   ||	 extends	  ||	implements					 
  class====X======>	class===============>interface
  				
  					
  						Internal Addition After Compilation
  When any interface gets compiled, compiler automatically adds access modifiers to the members


Interface Demo{								  Interface Demo{
 int count=10;     ------->(compiler)-------->	public static final int count=10;
 void output();									public abstract void output();
}											   }
	Demo.java										Demo.class
	
	
		Demo - Interface
		
		
//Interface declaration
interface Money{ 
	void Operation();
}
//Implementation
class Debit implements Money{ 
	public void Operation(){
		System.out.println("Debiting the money from the account");
		}
}
class Credit implements Money{
	public void Operation(){
		System.out.println("Crediting the money to the account");
		}
	}   // Crediting the money to the account<---Output
//Using interface
public class InterfaceDemo {
	public static void main(String args[]) {
		Money d=new Credit();
		d.Operation();
	}
}


				Demo: Extend An Interface With Another Interface

interface Walkable{ 
	void walk();
}

interface Runnable extends Walkable{
	void run();
}
public class InterfaceExtend implements Runnable{
	public void walk(){
		System.out.println("Interface: Walkable");
		} 
	public void run(){
		System.out.println("Interface: Runnable");
		}	
public static void main(String[] args) {
	InterfaceExtend obj = new InterfaceExtend(); 
	obj.walk();
	obj.run();
}
} 

//Output:-	Interface: Walkable
//			Interface: Runnable


		Demo: A Class Extending One Class And Implementing More Than One Interface
interface Walk{
	void walk();
}

interface Run{ 
	void run();
}
class Animal implements Walk,Run{
	public void walk(){
		System.out.println("Walkable interface is getting executed");
		}
	public void run() {
		System.out.println("Runnable interface is getting executed");
		}
	}
class Human extends Animal {
}
public class OneClassMultipleImplement {
public static void main(String[] args) {
	Walk h1=new Human();
	Run h2=new Human();
	h1.walk();
	h2.run(); 
	}
}

// Output:Walkable interface is getting executed
//		 Runnable interface is getting executed

					Demo: Default Methods In An Interface
Prior to Java 8, interfaces cannot not have method definition.
From Java 8 onwards we can add default implementation for interface methods
interface Welcome{
	// Default method
	default void say(){
		System.out.println("Hello, Welcome to edureka");
	}
	// Abstract method
	void hello(String msg);
}
public class DefaultClassInterfaceDemo implements Welcome{
	public void hello(String msg){// implementation of abstract method
		System.out.println(msg);
	}//The type DefaultClassInterfaceDemo must implement the inherited abstract method Welcome.hello(String)
	public static void main(String[] args) {
		DefaultClassInterfaceDemo out = new DefaultClassInterfaceDemo();
		out.say(); //default method 
		out.hello("Happy Learning"); // calling abstract method
}
}
//Hello, Welcome to edureka  <--Output
//Happy Learning
 
 
 				Rules For Using Private Methods In Interfaces
Following are the rules for using Private Methods in Interfaces:
 • Private interface method cannot be abstract.
 • Private method can be used only inside interface
 • Private static method can be called from other static and non-static interface methods
 • Private non-static methods cannot be called from private static methods

					Demo: Private Methods In An Interface
interface Welcomes{ 
	default void say() { 
		sayhello();
	}
	//Private method
	private void sayhello(){
		System.out.println("Hello... I'm private method. Welcome to edureka");
	}
}
public class PrivateMethodInterfaceDemo implements Welcomes{
	public static void main(String[] args) {
		Welcomes s = new PrivateMethodInterfaceDemo();
		s.say();
	}

}

//Output:--> Hello... I'm private method. Welcome to edureka
 
 
 					Demo: Static Methods In An Interface
interface Inter1{
	int a = 10;
	static void display() {
		System.out.println("static method in Interface");
	}
}
//A class that implements interface.
public class InterImpl implements Inter1 {
	public static void main(String[] args) {
		Inter1.display();
	}
}
//Output:--->static method in Interface
 
 				Interface Features For Different JDK versions
In JDK 1.0 to 1.7 - an interface can have:
			• Constant static variables
			• Abstract methods
In Java 8, an interface can have:-
 		    • Constant static variables
 		    • Abstract methods
 		    • Default methods
 		    • Static methods
In Java 9 and later versions, an interface can have:
 		    • Constant static variables
 		    • Abstract methods
 		    • Default methods
 		    • Static methods
 		    • Private methods
 		    • Private Static methods			
*/	
}
