package OOPSandExceptionsByEdureka;
		//Inheritence Example
public class ExampleOneEmployee extends  ExampleOneManager {
	public static void main(String args[]) {
		ExampleOneEmployee emp=new ExampleOneEmployee();
		emp.salary=100000;
		System.out.println("Salary of Employee is "+emp.salary);
		
		ExampleOneManager manager=new ExampleOneManager();
		manager.salary=10000;
		System.out.println("Salary of manager is "+manager.salary);
	}
}
