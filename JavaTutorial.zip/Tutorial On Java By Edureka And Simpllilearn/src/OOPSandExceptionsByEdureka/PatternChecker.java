package OOPSandExceptionsByEdureka;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternChecker {
		public static void main(String args[]) {
			String pattern="[a-z]+";
			String stringToCheck="Happy Learning!";
			Pattern compiledPattern=Pattern.compile(pattern);
			Matcher matcher=compiledPattern.matcher(stringToCheck);
			while(matcher.find()) {
				System.out.println(stringToCheck.substring(matcher.start(),matcher.end()));
			}			//Output:-appy
		 				//		 earning
			String pattern1="[a-zH]+";
			Pattern compiledPattern1=Pattern.compile(pattern1);
		Matcher matcher1=compiledPattern1.matcher(stringToCheck);
		while(matcher1.find()) {
			System.out.println(stringToCheck.substring(matcher1.start(),matcher1.end()));
		}			//Output:-Happy
	 				//		 earning
		String pattern2="\\bin\\b";
		String stringToCheck2="Happy Learning in Edureka!";
		Pattern compiledPattern2=Pattern.compile(pattern2);
		Matcher matcher2=compiledPattern2.matcher(stringToCheck2);
		while(matcher2.find()) {
			System.out.println(stringToCheck2.substring(matcher2.start(),matcher2.end()));
		}//Output:-in
		
	}
}
