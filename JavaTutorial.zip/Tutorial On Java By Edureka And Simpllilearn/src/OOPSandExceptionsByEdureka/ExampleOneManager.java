package OOPSandExceptionsByEdureka;

public class ExampleOneManager {
	long salary;
}
