package OOPSandExceptionsByEdureka;
/*
 • The access modifiers in java specifies accessibility (scope) of a data member, 
 method, constructor or class
 • There are 4 Access Modifiers:
 							 	 • Public Modifier
 							 	 • Protected Modifier
 							 	 • Private Modifier
 							 	 • Default Modifier
Access Modifiers Public -
 • When an attribute of method is declared as public then it can be accessed anywhere
 • Any package, any class accessibility is available	
 
 |			edureka.pack2		|		|			edureka.pack1		|
 |		[Class 5]<--------------|-------|-------[Class 1 Public members]|
 |								|		|	    /	|			 	  /	|
 |	[Class 4 Extends Class 1]<--|-------|------/     -->[Class 3]    /  |
 |								|		|				[Class 2]<--/	|
 
Access Modifiers Protected -
 • When an attribute of a method is declared as protected then it is visible to all the
classes in the same package and all subclasses in different package.

 |			edureka.pack2		|		|			edureka.pack1			|
 |		[Class 5] 				|		|		[Class 1 Protected members]	|
 |								|		|	    /	|			 	  /		|
 |	[Class 4 Extends Class 1]<--|-------|------/     -->[Class 3]    / 		|
 |								|		|				[Class 2]<--/		|

Access Modifiers Private-
 • If a Method,Variable or Constructor is defined as private then it can only be 
 accessed within the declared class itself
 • Access is not available outside the class
 
 |			edureka.pack2		|		|			edureka.pack1		 |
 |		[Class 5] 				|	    |		[Class 1 Private members]|
 |								|		|	      	  			 	  	 |
 |	[Class 4 Extends Class 1] 	| 		|       [Class 3]  			     |
 |								|		|				[Class 2] 		 |
 
 Access Modifiers - Default
 • When no access modifier is defined then it is said to have default access modifier
 • This attribute/method is used only in the given package
 • It is not accessible outside the package
 
 |			edureka.pack2		|		|			edureka.pack1		 |
 |		[Class 5] 				|	    |		[Class 1 Private members]|
 |								|		|	      	  		 /	 	  /	 |
 |	[Class 4 Extends Class 1] 	| 		|       [Class 3]<--/  		 /	 |
 |								|		|				[Class 2]<--/ 	 |
 
  							Access Levels
 The table shows the access we will get for classes, packages and subclasses
 
  		Modifier	|	Class	|	 Package 	|	Subclass	|	World
  		Public 	 	|	Yes		|	  Yes		|	Yes			|	Yes
  		Protected	|	Yes		|	  Yes		|	Yes			|	No
		No modifier |	Yes		|	  Yes		|	No			|	No
		private	 	|	Yes		|	 No			|	No			|	No
		
		
					Demo: Access Package From Another Package
package Demo;
public class PackDemo { 
public void msg(int i, int j){
System.out.println("Sum of 2 numbers : "+(i+j));
}}
There are three ways to access the package from outside the package:

1. import package.*;						2.import package.classname;
import Demo.*;								 import Demo.PackDemo;
public class PackageDemo {					 public class PackageDemo {
public static void main(String[] args) { 		public static void main(String[] args){
 PackDemo pd=new PackDemo();								PackDemo pd=new PackDemo();
  pd.msg(2,3);												pd.msg(2,3);
  }}												}}
  				3.fully qualified name
  				public class PackageDemo {
  				public static void main(String[] args) { 
  				Demo.PackDemo pd=new Demo.PackDemo(); 
  				pd.msg(2.3);
  				}}
 Output will be the same for all three ways:-
 <terminated> PackageDemo [Java Application] C:\Program Files\Java\jdk-9.0.1\bin\javaw.exe
  Sum of 2 numbers : 5
 */
public class AccessModifiers {

}
