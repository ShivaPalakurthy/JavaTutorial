package OOPSandExceptionsByEdureka;

public class MultipleCatchDemo {
	public static void main(String args[]){ 
		try{
			int a=10; // We are considering ArrayIndexOutOfBounds Exception 
			int b=5; 
			int c=a/b;
			int d[]= {1,3,5,7};
			System.out.println(d[10]);//We are trying to access element,which is out of bounds
//			Here, array d has 4 elements (index 0 to index 3), but we are trying to
//			print the element at 10th index. ArrayIndexOutOfBounds Exception occurs
		}
		catch(ArithmeticException e){ 
			System.out.println("Arithmetic Exception has occurred"); 
			}
		catch(ArrayIndexOutOfBoundsException e){ 
			System.out.println("ArrayIndexOutOfBounds exception has occurred");
			}
		catch(Exception e){
			System.out.println("Exception has occurred"); 
			}
	}

}
//Output:ArrayIndexOutOfBounds exception has occurred