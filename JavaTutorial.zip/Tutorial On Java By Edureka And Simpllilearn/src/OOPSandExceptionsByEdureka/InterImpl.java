package OOPSandExceptionsByEdureka;
		//Demo: Static Methods In An Interface
interface Inter1{
	int a = 10;
	static void display() {
		System.out.println("static method in Interface");
	}
}
//A class that implements interface.
public class InterImpl implements Inter1 {
	public static void main(String[] args) {
		Inter1.display();
	}
}
//Output:--->static method in Interface