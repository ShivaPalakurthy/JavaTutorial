package OOPSandExceptionsByEdureka;

public class ExceptionDemo {

	public static void main(String[] args) {
		try {//The part of code which could generate an Exception is put into try Block
			System.out.println(29 / 0);
		} catch (ArithmeticException exception)
		{//Code for an exception handling is written in a catch Block
 			System.out.println("Printing any kind of Arthimetic Exception Occured "+exception.getMessage());
		}//Output:Printing any kind of Arthimetic Exception Occured / by zero
		finally {
			System.out.println("Finally block under execution");
		}//Output:Printing any kind of Arthimetic Exception Occured / by zero
	}		//Finally block under execution
}	 

