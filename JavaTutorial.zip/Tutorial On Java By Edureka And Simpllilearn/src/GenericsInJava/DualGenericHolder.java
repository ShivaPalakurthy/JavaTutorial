package GenericsInJava;
/*
 * There might be use casses where you have to create a class whhich can accept 
 * multiple types of generic class.
 * Example lets say Hashmap we have key & value.Key can be of anytype & value can also be of
 * any datatype including custon datatype
 */
public class DualGenericHolder<T,U > { //you can have muliple generics also DualGenericHolder<T,U,V,M,K,...>
	T obj1;
	U obj2;
	
	DualGenericHolder(T obj1,U obj2) {
		 this.obj1=obj1;
		 this.obj2=obj2;
	}
	public void display() {
		System.out.println(obj1);
		System.out.println(obj2);
	}
	public static void main(String args[]) {
		DualGenericHolder<String, Integer> obj=new DualGenericHolder<String, Integer>("Shiva Palakurthy", 22);
		obj.display();
	}
}
