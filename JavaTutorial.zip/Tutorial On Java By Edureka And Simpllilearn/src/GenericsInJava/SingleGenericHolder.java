package GenericsInJava;

/*
 * Java checks the types of the variables ,methods & classes at compile time that is why
 * java is called a strong type checking language
 * 
 * If there is a login functionality which should allow a person to login & we should also 
 * allow an application to login, then these are the two different use cases but there 
 * functionalities are same. so how would the login functionality allow both of the types of entities
 * be it user or application to get or log in into the consumer application. Thats lead 
 * to the creation of Generics.Generics helps to reuse the same code with different type
 * of inputs
 * Code that use generics has many benefits over non-generic code:
 * 1.Strong type checks at compile time: A java compiler applies strong type checking to
 * generic code & issues errors if the code violates type safety.Fixing compile-time 
 * errors is easier than fixing runn time errors, which can be difficult to find.
 * 2.Elimination of Cast: we don't have to explicitly cast them
 * e.g the following code snippet without generics requires casting:
 * 			List list=new ArrayList();
	list.add("hello");
	String s=(String)list.get(0);
	
	when re-Written to use generics, the code doesnot require casting:
		
		List<String> list=new ArrayList<String>();
		   //Generic
		list.add("hello");
		String s=list.get(0);		//no cast
 *  */
public class SingleGenericHolder <T>{ /*if your class has a functionality which
 should be reused by many different types,then one of the way to not repeat the code or repeat the
 class or not repeat the functionality is to make that class use the Generic Signature. you
 can do this by adding <ANyName> infront of the class as shown SingleGenericHolder <T>. After
 placing this now who ever calls this class or initialises this class will have to supply the
 type of the class on which this functionality  (line 37-43)is going to get executed
*/
	T obj;  //reference of T inside the class
	 SingleGenericHolder(T obj) { //constructor
		 this.obj=obj;
	}
	 public T getObject() {
		 return this.obj;
	 }
	 
	 public static void main(String args[]) {
		SingleGenericHolder<Integer> iObj=new SingleGenericHolder<Integer>(10); //here T type is of Interger , it can be of any type even our Student class or an other class can also be a type
		System.out.println(iObj.getObject());
		
		SingleGenericHolder<String> sObj=new SingleGenericHolder<String>("Adapt.Improvise.Overcome");//here  T type is of String by using the same class we can execute both String & Integer as it is a generic
		System.out.println(sObj.getObject());
	}
}
