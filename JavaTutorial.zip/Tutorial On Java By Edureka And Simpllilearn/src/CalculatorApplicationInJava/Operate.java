package CalculatorApplicationInJava;

public interface Operate {
	Double getResult(Double... numbers);
}
/*Interface Operate has a single method called getResult  which is accepting a variable argument array
 *  ...-->var arg array / expression 
 *  which mean in (Double... numbers)-->this numbers will be an array of arbitary length. it is going to be fixed length
 *  array but the length is going to be dependent upon how much argument we supplyy to method
 */