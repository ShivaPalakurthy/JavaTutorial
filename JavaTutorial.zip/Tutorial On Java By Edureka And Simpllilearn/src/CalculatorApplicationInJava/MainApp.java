package CalculatorApplicationInJava;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class MainApp {
	public static void main(String args[]) {
		final String inputExp=ReadInput.read();
		
		Queue<String> operations;
		Queue<String> numbers;
//4+5*3/2 --> in bottom we are splitting numbers & operators		
		String numbersArr[]=inputExp.split("[-+*/]");//returns A numbers array which gets based on the expression i.e 4532
		String operArr[]=inputExp.split("[0-9]+");// returns mathematical operators & no numbers here +*/
		/*
		 * Split method of the String API(class) & this split method is going to split the numbers & operators into
		 * two different String arrays
		 */
		numbers=new LinkedList<String>(Arrays.asList(numbersArr));/*Arrays.asList(numbersArr)--> converting String arrays 
		into queue by converting numbersArr array into a list by calling  Arrays.asList(numbersArr) & then converting this
		normal(generic) list to a linked list by  LinkedList<String>(Arrays.asList(numbersArr) Then we store this 
		linkedlist into a Queue of numbers . Same will be done for operations aswell
		 */
		operations=new LinkedList<String>(Arrays.asList(operArr));
		
		Double res=Double.parseDouble(numbers.poll()); /* poll method is used when we want to fetch the first front element
		of the queue.so whichever element is siting at the head of the queue is taken out of the queue, the movement we call
		the poll method. so we fetch the first number form the numbers queue
		*/
		
		while(!numbers.isEmpty()){
			String opr=operations.poll();
			
			Operate operate; /*we defined reference of Operate here & each of this switch case block , we are assigning
			the object type to this interface reference. So we are using the concept of  Dynamic Binding
			*/
			switch(opr) {
			case "+":
				operate=new Add();
				break;
			case "-":
				operate=new Subtract();
				break;
			case "*":
				operate=new Multiply();
				break;
			case "/":
				operate=new Divide();
				break;
			default:
				continue;
			
			}
			Double num=Double.parseDouble(numbers.poll());
			/*
			 * first we'll do poll at line 33 then we'll check the operand then we'll do second poll are line 55
			 * then we'll do operation in 65  , this getResult will be called based on the expression we encounter 
			 * in switch case.so looking at the example the first expression we encountered is plus so the operate type
			 * object is of ADD type then we'll call operate.getResult then getResult method of Add class will be invoked
			 * & gives value in res. so 4 at top ,+ in switch case then 5 at bottom 55 , result , * in case,3 at 55, result,
			 * / at switch case, 2 at line 55 so on 
			 */
			
			res=operate.getResult(res,num);
		}
		System.out.println(res);
	}
}
