package com.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightManager {

	public static void main(String args[]) {
		SpringApplication.run(FlightManager.class, args);
	}
}
